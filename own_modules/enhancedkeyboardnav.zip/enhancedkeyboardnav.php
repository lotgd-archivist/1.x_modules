<?php
/*
"Enhanced Keyboard Navigation" module.
Author: IonSprite
License: Creative Commons BY-NCA-SA 4.0
https://creativecommons.org/licenses/by-nc-sa/4.0/
*/

function enhancedkeyboardnav_getmoduleinfo(){
	$info = array(
		"name"=>"Enhanced Keyboard Navigation",
		"version"=> "0.5",
		"author"=> "`VIon`vSprite",
		"category"=> "Navigation",
		"download"=> "https://raw.githubusercontent.com/lotgd-archivist/1.x_modules/main/own_modules/enhancedkeyboardnav.zip",
		"prefs"=>array(
            "Keyboard navigation settings,title",
            "user_arrowkeynav_on"=> "Enable navigation via arrowkey?,bool|0",
			"user_escape_unfocus" => "Pressing escape to unfocus current textbox?,bool|0",
        ),
	);
	return $info;
}

function enhancedkeyboardnav_install(){
	module_addhook("everyfooter");
	return true;
}

function enhancedkeyboardnav_uninstall(){
	return true;
}

function enhancedkeyboardnav_dohook($hookname,$args){
	if (get_module_pref("user_arrowkeynav_on")) {
		rawoutput("<script language='JavaScript' src='modules/enhancedkeyboardnav/arrowkeyNav.js'></script>");
	}
	if (get_module_pref("user_escape_unfocus")) {
		rawoutput("<script language='JavaScript' src='modules/enhancedkeyboardnav/escapeUnfocus.js'></script>");
	}
	return $args;
}

?>