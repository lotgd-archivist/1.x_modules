/*
Part of the "Enhanced Keyboard Navigation" module.
Author: IonSprite
License: Creative Commons BY-NCA-SA 4.0
https://creativecommons.org/licenses/by-nc-sa/4.0/
*/

document.onkeydown = (event) => {
	if (event.key == "Escape") {
		if (event.target && ["INPUT", "TEXTAREA"].includes(event.target.tagName)) {
			event.target.blur();
		}
		return;
	}
};