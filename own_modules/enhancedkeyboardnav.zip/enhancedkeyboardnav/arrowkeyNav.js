/*
Part of the "Enhanced Keyboard Navigation" module.
Author: IonSprite
License: Creative Commons BY-NCA-SA 4.0
https://creativecommons.org/licenses/by-nc-sa/4.0/
*/

document.addEventListener('DOMContentLoaded', function(){ 
	const getNavTree = () => {
		const categories = [];
		let currentCategory = -1;
		const navParent = document.querySelectorAll("a.nav")[0].parentElement;
		[...navParent.children].filter(e => e.tagName == "A" || e.tagName == "SPAN").forEach((e, index) => {
			if (e.tagName === "SPAN") {
				currentCategory++;
				categories.push({
					id: currentCategory,
					items: [],
					count: 0,
				});
			} else {
				if (index == 0) {
					currentCategory++;
					categories.push({
						id: currentCategory,
						items: [],
						count: 0,
					});
				}
				categories[currentCategory].items.push(e);
				categories[currentCategory].count++;
			}
		});
		return categories;
	}

	let navFocus = -1;
	let navCategoryFocus = 0;
	let navTree = getNavTree();

	function handleArrowKeys(event) {
		if (event.key === "ArrowRight") {
			navCategoryFocus++;
			navFocus = 0;
		}
		if (event.key === "ArrowLeft") {
			navCategoryFocus--;
			navFocus = 0;
		}
		if (event.key === "ArrowDown") {
			navFocus++;
			if (navFocus > navTree[navCategoryFocus].count - 1) {
				navCategoryFocus++;
				navFocus = 0;
			}
		}
		if (event.key === "ArrowUp") {
			navFocus--;
			if (navFocus < 0) {
				navCategoryFocus--;
				if (navCategoryFocus < 0) {
					navCategoryFocus = navTree.length - 1;
				}
				navFocus = navTree[navCategoryFocus].count - 1;
			}
		}

		if (navCategoryFocus >= navTree.length) {
			navCategoryFocus = 0;
		}
		if (navCategoryFocus < 0) {
			navCategoryFocus = navTree.length - 1;
		}
		if (navCategoryFocus > -1) {
			navTree[navCategoryFocus].items[navFocus].focus();
		}
	}

	document.onkeydown = (event) => {
		if (event.key === "ArrowUp" || event.key === "ArrowDown" || event.key === "ArrowLeft" || event.key === "ArrowRight") {
			if (event.target && ["INPUT", "TEXTAREA"].includes(event.target.tagName)) {
				return;
			}
			if (!event.altKey) {
				handleArrowKeys(event);
				event.preventDefault();
			}
			return;
		}
		if (event.ctrlKey || event.metaKey || event.altKey) {
			return;
		}

		if (["input", "textarea", "select"].includes(event.target.nodeName.toLowerCase())) {
			return;
		}
		let link = document.querySelector("a.nav[accessKey='" + event.key.toUpperCase() + "']");
		if (!link) {
			link = document.querySelector("a.nav[accessKey='" + event.key.toLowerCase() + "']");
		}
		if (link) {
			link.click();
		}
	}
}, false);