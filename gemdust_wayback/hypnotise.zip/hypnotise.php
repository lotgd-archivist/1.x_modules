<?php


function hypnotise_getmoduleinfo(){
	$info = array(
		"name"=>"Hypnosis",
		"version"=>"1.0",
		"author"=>"Shannon Brown",
		"category"=>"Tournament",
		"prefs"=>array(
			"Hypnosis Event User Preferences,title",
			"seentoday"=>"Has the user seen her already today?,bool|0",
		),
	);
	return $info;
}

function hypnotise_test(){
	global $session;
	$dks = $session['user']['dragonkills'];
	if (is_module_active("tourneylock") && $dks == 0 && get_module_setting("tourneyon","tourneylock") == 1) {
		$chance = 100;
	} else {
		$chance = 0;
	}
	return($chance);
}


function hypnotise_install(){
	module_addeventhook("forest", "require_once(\"modules/hypnotise.php\"); return hypnotise_test();");
	module_addhook("newday");
    return true;
}

function hypnotise_uninstall(){
	return true;
}

function hypnotise_dohook($hookname,$args){
	switch($hookname){
	case "newday":
		set_module_pref("seentoday",0);
	break;
	}
	return $args;
}

function hypnotise_runevent($type) {
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:hypnotise";

	$op = httpget('op');
	if ($op==""){
		output("`%You're minding your own business when suddenly you encounter a brownie in the forest.");
		output("\"`^I have something for you!!`%\" she shrieks.");
		output("\"`^You are one of THEM! One of the competitors trying to win! I can help you win!`%\" she yells.`n`n");
		output("`%She holds out a vial of blue liquid and points to a blanket on the forest floor nearby.`n`n");
		output("\"`^If you want to let me help you advance, drink this and lie down!`%\" she says.");
		output("\"`^I will hypnotise you and make you strong!`%\"`n`n");
		output("Brownies around these parts are generally safe to trust, but the idea of memories being implanted in your brain is a little unsettling. What do you do?");
		addnav("Drink the liquid", $from."op=agree");
		addnav("Run away", $from."op=dont");
	}elseif ($op=="agree"){
		output("`%You take the vial and upend it into your mouth.");
		output("Within seconds, your eyesight begins to fade.");
		output("She is yelling again, and dragging you by the hand to the blanket. Wearily you stumble towards it and sink to your knees. She pushes you over until you fall, unconscious.");
		set_module_pref("seentoday",1);
		addnav("Wake up", $from."op=wake");
	}elseif ($op=="wake"){
		output("`%You've no idea whether you were asleep for minutes or hours, but when you awaken, you are alone.");
		output("You rub your eyes and look around you.");
		output("As you gather your wits, you feel more conscious of the creatures around you than you were before. You struggle to your feet, pick up your %s, and realise that it feels more comfortable to wield than before.`n`n",$session['user']['weapon']);
		output("You have clear memories of having slain creatures that you have never encountered.");
		$session['user']['experience']+=50;
		$session['user']['experience']*=1.5;
		output("`^You have gained experience!");
		$session['user']['specialinc'] = "";
	}else{
		output("`%There's no way you want some crazy brownie messing with your brain.`0");
		output("`%You turn your back on her and walk away.`0");
		$session['user']['specialinc'] = "";
		}
}

function hypnotise_run(){
}

?>