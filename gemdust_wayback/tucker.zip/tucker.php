<?php

// This is a simple food and drink module requiring players
// to spend turns at the beginning of their days, to avoid
// stat penalties.

// It's useful if you feel the players have too many turns or
// are advancing too fast but you do not want to reduce the
// number of forest fights per day.

// DO NOT use this module if you have any of these installed:

// chow
// bladder
// kitchen of DOOM

// I don't think it would break anything, BUT, the continuity 
// would be broken because you may be accused of being hungry
// by one module after having eaten at the other, etc.

/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 14 June 2006 */

require_once("lib/http.php");
require_once("lib/villagenav.php");

function tucker_getmoduleinfo(){
	$info = array(
		"name"=>"Food Module for LoGD",
		"version"=>"1.0",
		"author"=>"Shannon Brown",
		"category"=>"Village",
		"settings"=>array(
			"addpercent"=>"Percent to add to attack after eating,range,1,25,1|10",
			"turncost"=>"Number of turns required to eat,range,1,5,1|1",
			"tuckerloc"=>"Where does the tucker appear,location|".getsetting("villagename", LOCATION_FIELDS)
		),
		"prefs"=>array(
			"eatentoday"=>"Has player eaten today,int|0",
			"drinktoday"=>"Has player drunk today,int|0",
			"ingred"=>"Has player collected food today,int|0",
			"weak"=>"How weak is the player,int|0"
		)
	);
	return $info;
}

function tucker_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
	return true;
}

function tucker_uninstall(){
	return true;
}

function tucker_dobuff() {
	$addpercent = get_module_setting("addpercent");
	$weak = get_module_pref("weak");
	if ($weak < -1) {
		$buffmod = (100 + $addpercent) / 100;
		apply_buff('tucker',array(
			"name"=>"`^Excellent Health","rounds"=>-1,"atkmod"=>$buffmod,"schema"=>"module-tucker")
		);
	} elseif ($weak < 0) {
		$buffmod = (100 + ($addpercent/2)) / 100;
		apply_buff('tucker',array(
			"name"=>"`@Good Health","rounds"=>-1,"atkmod"=>$buffmod,"schema"=>"module-tucker")
		);
	} elseif ($weak < 1) {
		apply_buff('tucker',array(
			"name"=>"`2Health","rounds"=>-1,"atkmod"=>1,"schema"=>"module-tucker")
		);
	} elseif ($weak < 2) {
		$buffmod = (100 - ($addpercent)) / 100;
		apply_buff('tucker',array(
			"name"=>"`4Poor Health","rounds"=>-1,"atkmod"=>$buffmod,"roundmsg"=>"`4Your legs shake.","schema"=>"module-tucker")
		);
	} else {
		$buffmod = (100 - (2 * $addpercent)) / 100;
		apply_buff('tucker',array(
			"name"=>"`qWeakness",
			"rounds"=>-1,
			"atkmod"=>$buffmod,
			"roundmsg"=>"`4You feel close to collapse and can barely lift your arms.",
			"schema"=>"module-tucker")
		);
	}
	return true;
}

function tucker_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("tuckerloc")) {
				set_module_setting("tuckerloc", $args['new']);
			}
		}
		break;
	case "village":
		if ($session['user']['location'] == get_module_setting("tuckerloc")) {
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
			tlschema();
			addnav("Picnic Area","runmodule.php?module=tucker");
		}
		break;
	case "newday":
		$addpercent = get_module_setting("addpercent");
		$weak = get_module_pref("weak");
		if ($weak < 2) $weak+=0.66;
		set_module_pref("weak",$weak);
		set_module_pref("drinktoday",0);
		set_module_pref("eatentoday",0);
		set_module_pref("ingred",0);
		$thirstmod = (100 - 2*$addpercent) / 100;
		apply_buff('tthirst',array(
			"name"=>"`3Thirst",
			"rounds"=>-1,
			"defmod"=>$thirstmod,
			"schema"=>"module-tucker")
		);
		tucker_dobuff();
		break;
	}
	return $args;
}

function tucker_run(){
	global $session;
	$op = httpget("op");

	$eatentoday = get_module_pref("eatentoday");
	$drinktoday = get_module_pref("drinktoday");
	$addpercent = get_module_setting("addpercent");
	$turncost = get_module_setting("turncost");
	$ingred = get_module_pref("ingred");
	$weak = get_module_pref("weak");

	page_header("Picnic Area");

	output("`&`c`bThe Picnic Area`b`c`n");

	if ($op=="" && $eatentoday == 0){
		output("`7You wander towards the picnic area, following the well-worn trail through the semi-cleared area. Warriors have spent time in this area for many years, each one planting a few vegetables, pulling a few weeds, and tipping a jug or two of water to keep the place thriving. As you get to the large clearing in the middle, you see a few creatures cooking assorted items on small fires.");
		output("`7One of them spots you and waves.`n`n");

		if ($drinktoday == 1) {
			output("`7The well holds no real interest to you.");
		} else {
			output("`7Your forehead is hot and your skin feels dry. You think you should probably fetch some water from the well.`n`n");
		}
		if ($weak > 0 && $eatentoday == 0) {
			output("`7You can't believe how weak you feel, and you think you should probably eat something.`n`n");
		} elseif ($eatentoday == 0) {
			output("`7You glance at the food the other families are eating, and your mouth waters.");
		}
	} elseif ($op=="" && $eatentoday == 1) {
		output("`7You really aren't hungry.");
	} elseif ($op=="well") {
		output("`7Walking across to the well, you take a moment to stare into its depths, before lowering the bucket into the darkness. You wind the handle until it re-emerges, then take a nearby jug and fill it from the bucket. You carry your precious cargo back to the camp area, then drink a huge swallow, sighing with relief.");
		if ($eatentoday == 0) output("`7Your stomach growls, and you begin to think about food.");
		set_module_pref("drinktoday",1);
		$session['user']['turns'] -= $turncost;
		strip_buff("tthirst");
	} elseif ($op=="soup") {
		output("`7Travelling a small distance from the fires, you begin to look for something worth eating.");
		if (e_rand(1,10) == 10) {
			output("`7Before you can go very far, your foot lands in a hole and you wrench your knee hard. White-hot pain shoots from your toes to your thigh and you fall to the ground. It is some time before you can pick yourself up and hobble painfully to the clearing to rest.");
			apply_buff('ktucker',array(
				"name"=>"`\$Wrenched Knee","rounds"=>100,"atkmod"=>0.9,"survivenewday"=>1,"roundmsg"=>"`4Your knee burns.","schema"=>"module-tucker")
			);
		} else {
			output("`7After a moment, you see the telltale leaves of a potato plant, and pull it up for your meal.");
			if (e_rand(1,3) == 3) output("`7You spot a bunch of green blades, so you pull them up, finding an onion.");
			if (e_rand(1,3) == 3) output("`7You sigh when you realise you've come to some turnips growing. They've never been your favourite, but they fill the stomach, so you take some.");
			if (e_rand(1,3) == 3) output("`7A couple of minutes later, a tomato plant comes into view, and you take a couple to put into the food you'll cook.");
			if (e_rand(1,3) == 3) output("`7Just when you think your meal will be boring, a patch of carrot stalks come into view. You yank some up for your meal.");
			if (e_rand(1,3) == 3) output("`7A mess of leaves seem to be just weeds, until you spot the pods. You pick plenty of the peas to take with you.");
			if (e_rand(1,3) == 3) output("`7On your way back to camp, you spot a pumpkin vine with one large pumpkin sitting in the middle, which you hastily grab.");
			if (e_rand(1,3) == 3) output("`7Close to the trail back, you pass another adventurer. He's carrying a handful of different vegetables that he has collected, just like you have. The two of you eye each other for a moment before greeting one another, and agreeing to exchange some items to make your meals more interesting.`n`n");
			output("`7Your stomach growls more insistently,");
			if ($drinktoday == 0) output("but you could really do with some water for the soup.");
			if ($drinktoday == 1) output("and you start looking for a good place to build your fire.");
			set_module_pref("ingred",1);
		}
		$session['user']['turns'] -= $turncost;
	} elseif ($op=="cook") {
		output("`7You collect a few twigs and logs and start your fire. It isn't long before you've cut all the vegetables up with your %s and thrown them into a small pot of water over the flames.",$session['user']['weapon']);
		output("`7The other warriors sing and laugh merrily as their meals cook. Yours finally looks edible, and you down it with ferocious hunger.`n`n");
		output("`7You pour water over the flames, careful to extinguish them completely. You refill the jug and take it to a nearby patch of carrots, wetting the thirsty plants.`n`n");
		output("`qYou feel satisfied. Hearty meals like this could well keep a %s healthy!",$session['user']['race']);
		$weak--;
		$session['user']['turns'] -= $turncost;
		$eatentoday++;
		set_module_pref("weak",$weak);
		set_module_pref("eatentoday",$eatentoday);
		tucker_dobuff();
	} elseif ($op=="fruit") {
		$fruitbowl = array("tall apple tree","robust orange tree","cherry tree","blackberry bush","banana tree","pear tree","mandarin tree","passionfruit vine","grape vine");
		$fruitbowl = translate_inline($fruitbowl);
		$fruit = $fruitbowl[e_rand(0, count($fruitbowl)-1)];
		output("`7You wander towards a grove of fruit trees and start looking for any ripe fruit. Finding a %s, you put your %s to good use and place the fruit into your pack.",$fruit,$session['user']['weapon']);
		output("`7You know you'll need to keep looking until you have enough for the day, so you keep moving, filling your pack as you go. Eventually, you think you've collected enough.`n`n");
		output("`7The other warriors sing and laugh merrily as their meals cook. You barely hear them as you shovel fruit into your mouth.`n`n");
		if ($drinktoday == 1) output("`7When you are finished, you take your water jug and pour some water at the base of a cherry tree.`n`n");
		output("`qYou feel satisfied. Good fruit like this could well keep a %s healthy!",$session['user']['race']);
		$weak--;
		$session['user']['turns'] -= $turncost * 3;
		$eatentoday++;
		set_module_pref("weak",$weak);
		set_module_pref("eatentoday",$eatentoday);
		tucker_dobuff();
	}

	$eatentoday = get_module_pref("eatentoday");
	$drinktoday = get_module_pref("drinktoday");
	$addpercent = get_module_setting("addpercent");
	$droppercent = get_module_setting("droppercent");
	$turncost = get_module_setting("turncost");
	$ingred = get_module_pref("ingred");
	$water = get_module_pref("water");

	if ($drinktoday == 0 && $session['user']['turns'] >= $turncost) addnav(array("F?Fetch Water (`^%s turns`0)",$turncost),"runmodule.php?module=tucker&op=well");
	if ($eatentoday == 0 && $ingred == 0 && $session['user']['turns'] >= $turncost) addnav(array("G?Gather Soup Ingredients (`^%s turns`0)",$turncost), "runmodule.php?module=tucker&op=soup");
	if ($eatentoday == 0 && $drinktoday == 1 && $ingred == 1 && $session['user']['turns'] >= $turncost) addnav(array("C?Cook Ingredients (`^%s turns`0)",$turncost),"runmodule.php?module=tucker&op=cook");
	if ($eatentoday == 0 && $session['user']['turns'] >= $turncost) addnav(array("F?Pick Fruit (`^%s turns`0)",$turncost*3),"runmodule.php?module=tucker&op=fruit");

	villagenav();
	page_footer();
}

?>