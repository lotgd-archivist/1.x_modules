<?php

function revive_getmoduleinfo(){
	$info = array(
		"name"=>"Revive Serum",
		"author"=>"Shannon Brown",
		"version"=>"1.0",
		"category"=>"Lodge",
		"download"=>"http://gemdust.com/module_download",
		"requires"=>array(
			"tourneylock"=>"1.0|By Shannon Brown",
		),
		"settings"=>array(
			"Revive Serum Module Settings,title",
			"serumcost"=>"Serum cost in points?,int|100",
		),
		"prefs"=>array(
			"Revive Serum User Preferences,title",
			"serum"=>"Does a player own one?,bool|0",
			"serumcount"=>"Total number bought,int|0",
		),
	);
	return $info;
}

function revive_install(){
	module_addhook("lodge");
	module_addhook("pointsdesc");
	module_addhook("shades");
	return true;
}
function revive_uninstall(){
	return true;
}

function revive_dohook($hookname,$args){
	global $session;
	$serumcost = get_module_setting("serumcost");
	switch($hookname){
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("A vial of Revive Serum costs %s points, and will grant you another chance, if you find yourself in the Shades unexpectedly. You can only carry one at a time and you can use a maximum of five in a tournament.",$serumcost);
		$str = sprintf($str, $serumcost);
		output($format, $str, true);
		break;
	case "lodge":
		addnav(array("Revive Serum (%s points)", $serumcost),"runmodule.php?module=revive&op=purchase");
		break;
	case "shades":
		if (get_module_pref("serum") == 1) addnav("U?Use Revive Serum","runmodule.php?module=revive&op=use");
		break;
	}
	return $args;
}

function revive_runevent() {
}

function revive_run(){
	global $session;
	$op = httpget("op");

	$cost = get_module_setting("cost");
	if ($op == "use") {
		page_header("Revive Serum");
		output("`%Your skeletal hands remove the cork from the vial of revive serum and you sniff the vapour.");
		output("As you do, you feel a searing pain within your those bones, your skin materializes with a zing, and you reawaken into life!`n`n`^");
		set_module_pref("serum",0);
		debuglog("used revive serum");
		addnav("It is a new day!","newday.php");
		blocknav("lodge.php");
	} elseif ($op=="purchase" && get_module_pref("serumcount") < 5){
		page_header("Hunter's Lodge");
		output("`7The hunter regards you with interest. \"`&Each vial of Revive Serum costs %s points,`7\" he says.  \"`&Is this what you want to buy?`7\"`n`n", $serumcost);
		addnav("Confirm Purchase");
		addnav("Purchase", "runmodule.php?module=revive&op=confirm");
	} elseif ($op=="purchase"){
		page_header("Hunter's Lodge");
		output("`7The hunter regards you with a shake of his head. \"`&Sorry, you have already bought the maximum number for this tournament`7\"`n`n");
	} elseif ($op=="confirm"){
		page_header("Hunter's Lodge");
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if($pointsavailable >= $serumcost && get_module_pref("serum")==0){
			output("`7J. C. Petersen hands you a yellow vial of Revive Serum.");
			$serumcount = get_module_pref("serumcount");
			$serumcount++;
			set_module_pref("serumcount",$serumcount);
			set_module_pref("serum",1);
			$session['user']['donationspent'] += $serumcost;
		} elseif(get_module_pref("serum")==1){
			output("`7J. C. Petersen points at the serum you already carry, and explains that you can't have another at this point.");
		} else {
			if ($pointsavailable < $serumcost) {
				output("`7J. C. Petersen looks down his nose at you. \"`&You need enough points to buy this stuff. It's too valuable to give away.`7\"", $serumcost);
			}
		}
	}
	addnav("L?Return to the Lodge","lodge.php");
	page_footer();
}
?>
