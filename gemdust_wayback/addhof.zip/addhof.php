<?php

function addhof_getmoduleinfo(){
	$info = array(
		"name"=>"Add HOF",
		"version"=>"1.0",
		"author"=>"Shannon Brown",
		"category"=>"General",
		"download"=>"http://gemdust.com/module_download"			
	);
	return $info;
}

function addhof_install(){
	module_addhook("graveyard");
	module_addhook("village");
	module_addhook("shades");
	return true;
}

function addhof_uninstall(){
	return true;
}

function addhof_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village":
		case "shades":
		case "graveyard":
			addnav("Hall of Fame","hof.php");
		break;
	}
	return $args;
}

function addhof_run(){
}

?>