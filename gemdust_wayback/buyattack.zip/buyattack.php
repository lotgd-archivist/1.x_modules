<?php

// Buy Attack module for the lodge
// By Shannon Brown 21st April 2006
// SaucyWench -at- gmail -dot- com
//
// I personally believe this is unbalancing and don't recommend you
// install it! 
// However, you downloaded this because you wanted it, so if you're
// determined to install something unbalancing it might as well be
// written by someone who can code cleanly ;)
//
// set_module_setting("ego",0);


function buyattack_getmoduleinfo(){
	$info = array(
		"name"=>"Buy Attack",
		"author"=>"Shannon Brown",
		"version"=>"1.0",
		"category"=>"Lodge",
		"download"=>"http://gemdust.com/module_download",
		"settings"=>array(
			"Buy Attack Module Settings,title",
			"attcost"=>"Attack point cost in points?,int|500",
		),
		"prefs"=>array(
			"Buy Attack User Preferences,title",
			"attcount"=>"Total number bought,int|0"
		),
	);
	return $info;
}

function buyattack_install(){
	module_addhook("lodge");
	module_addhook("pointsdesc");
	module_addhook("dragonkill");
	return true;
}
function buyattack_uninstall(){
	return true;
}

function buyattack_dohook($hookname,$args){
	global $session;
	$attcost = get_module_setting("attcost");
	switch($hookname){
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("For the low cost of %s, JCP will sell you the booster potion that Bluspring herself recommends to build muscle. It will last until you kill the dragon and grant you one extra attack point. You may purchase a maximum of five per dragon kill.",$attcost);
		$str = sprintf($str, $attcost);
		output($format, $str, true);
		break;
	case "lodge":
		addnav(array("Attack Booster Potion (%s points)", $attcost),"runmodule.php?module=buyattack");
		break;
	case "dragonkill":
		set_module_setting("attcount",0);
		break;
	}
	return $args;
}

function buyattack_runevent() {
}

function buyattack_run(){
	global $session;
	$op = httpget("op");
	$attcost = get_module_setting("attcost");
	if (get_module_pref("attcount") < 5 && $op==""){
		page_header("Hunter's Lodge");
		output("`7JCP regards you with a smile. \"`&Each vial of Booster Potion costs %s points,`7\" he says.  \"`&Is this what you want to buy?`7\"`n`n", $attcost);
		if (is_module_active("heidi")) output("`7One should also remember that burning an orange candle will send your boost to the wind...`7\"`n`n`QYou realise that the boost will disappear if you burn an orange candle.");
		addnav("Confirm Purchase");
		addnav("Purchase", "runmodule.php?module=buyattack&op=confirm");
	} elseif ($op=="confirm"){
		page_header("Hunter's Lodge");
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if($pointsavailable >= $attcost){
			output("`7J. C. Petersen hands you a yellow vial of booster potion and you drink it with excitement.");
			$attcount = get_module_pref("attcount");
			$attcount++;
			set_module_pref("attcount",$attcount);
			$session['user']['donationspent'] += $attcost;
			$session['user']['attack']++;
		} else {
			if ($pointsavailable < $attcost) {
				output("`7J. C. Petersen looks down his nose at you. \"`&You need enough points to buy this stuff. It's too valuable to give away.`7\"", $attcost);
			}
		}
	} else {
		page_header("Hunter's Lodge");
		output("`7The hunter regards you with a shake of his head. \"`&Sorry, you have already bought the maximum number for this dragon kill.`7\"`n`n");
	} 
	addnav("L?Return to the Lodge","lodge.php");
	page_footer();
}

?>