<?php

/* Holy Man */
/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 29th July 2005 */

/* ver 1.1 1st Sept 2005 minor cleanups */

require_once("lib/http.php");

function holyman_getmoduleinfo(){
    $info = array(
        "name"=>"Holy Man",
        "version"=>"1.1",
        "author"=>"Shannon Brown",
        "category"=>"Graveyard Specials",
        "download"=>"http://gemdust.com/module_download",
        "settings"=>array(
            "Holy Man - Settings,title",
			"favourloss"=>"Amount of favour to lose,range,1,30,1|20"
        )
    );
    return $info;
}

function holyman_install(){
	module_addeventhook("graveyard", "return 100;");
    return true;
}

function holyman_uninstall(){
    return true;
}

function holyman_dohook($hookname,$args){
    return $args;
}

function holyman_runevent($type)
{
	global $session;
	output("`^As you are looking for souls to torment, a white creature moves towards you.");
	output("Thinking you have found your target, you prepare to torment him.`n`n");
	output("To your horror, it is a holy man, thrusting a talisman in your direction, chanting hurried words, and utterly unafraid of your tormenting moans.`n`n");
	output("As you stand there in shock, you feel the burn of ugly purity within your brittle bones, and you know that Ramius must be very displeased!`n`n");
	if ($session['user']['dragonkills'] >= 1) {
		if ($session['user']['gravefights'] > 0) $session['user']['gravefights']--;
		output("`&Your soul feels as if its capacity for torment has been decreased.`n");
		$favourloss = get_module_setting("favourloss");
		if ($session['user']['deathpower'] >= $favourloss) {
			$session['user']['deathpower'] -= $favourloss;
		} else {
			$session['user']['deathpower'] = 0;
		}
		output("`&You feel that Ramius is very displeased!`n`0");
	} else {
		output("`&Fortunately, you somehow summon the energy to run, before any damage is done.`n");
	}
}

function holyman_run(){
}
?>