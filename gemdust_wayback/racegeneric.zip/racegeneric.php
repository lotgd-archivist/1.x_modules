<?php

// 26th July 2006
// SaucyWench -at- gmail *dot* com

// Written for servers that do not wish to have races.
// The character will have "Human" set, but it will not be shown
// in the character stats.

// Make sure you disable Cedrik's Transmutation potion in the Inn
// and uninstall all other races before you begin.

// Some areas will still list the race as "human". It is not
// possible to know all the modules and files that display the race.
// Home City defaults to Degolburg. If you have renamed your
// Capital, change the setting in this file to the new name.

// uses some code from racefelyne and racehuman, by Eric Stevens

function racegeneric_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Generic Human",
		"version"=>"1.0",
		"author"=>"Shannon Brown",
		"category"=>"Theming",
		"download"=>"http://gemdust.com/module_download/",
		"settings"=>array(
			"Generic Race Settings,title",
			"minedeathchance"=>"Percent chance for Generic Humans to die in the mine,range,0,100,1|40"
		),
	);
	return $info;
}

function racegeneric_install(){
	module_addhook("racenames");
	module_addhook("raceminedeath");
	module_addhook("chooserace");
	module_addhook("newday");
	return true;
}

function racegeneric_uninstall(){
	global $session;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Human'";
	db_query($sql);
	if ($session['user']['race'] == 'Human')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racegeneric_dohook($hookname,$args){
	global $session,$resline;
	$city = getsetting("villagename", LOCATION_FIELDS);
	$race = "Human";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Fortunately you make it out in time.`n";
			$args['schema']="module-racegeneric";
		}
		break;
	case "chooserace":
		$session['user']['race']="Human";		
		redirect("newday.php");		
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racegeneric_checkcity();
		}
		break;
	}
	return $args;
}

function racegeneric_checkcity(){
	global $session;
	$race="Human";
	$city = getsetting("villagename", LOCATION_FIELDS);
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){ 
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racegeneric_run(){
}

?>