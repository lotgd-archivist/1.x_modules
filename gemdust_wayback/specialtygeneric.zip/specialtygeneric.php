<?php

// 26th July 2006
// SaucyWench -at- gmail *dot* com

// Written for servers that do not wish to have specialties.
// The character will have "Standard" set, but it will not be shown
// in the character stats. There will be no specialty uses in the
// forest fights.

// Make sure you disable Cedrik's Forgetfulness potion in the Inn
// and uninstall all other specialties before you begin.
// UNINSTALL any specials that add to the specialty. You will get
// errors if you do not. For example, the old man, forest fairy, 
// foilwench.

// Some areas will still list the specialty. It is not
// possible to know all the modules and files that display it.

// If you do not want it displayed in the bio, use the translator
// tool to remove it.

// uses some code from specialtydarkarts, by Eric Stevens

function specialtygeneric_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Generic",
		"author" => "Shannon Brown",
		"version" => "1.0",
		"category"=>"Theming",
		"download"=>"http://gemdust.com/module_download/"
	);
	return $info;
}

function specialtygeneric_install(){
	$sql = "DESCRIBE " . db_prefix("accounts");
	$result = db_query($sql);
	$specialty="DA";
	while($row = db_fetch_assoc($result)) {
		// Convert the user over
		if ($row['Field'] == "standard") {
			debug("Migrating standard field");
			$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtystandard', 'skill', acctid, standard FROM " . db_prefix("accounts");
			db_query($sql);
			debug("Dropping standard field from accounts table");
			$sql = "ALTER TABLE " . db_prefix("accounts") . " DROP standard";
			db_query($sql);
		} elseif ($row['Field']=="standarduses") {
			debug("Migrating standard uses field");
			$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtystandard', 'uses', acctid, standarduses FROM " . db_prefix("accounts");
			db_query($sql);
			debug("Dropping standarduses field from accounts table");
			$sql = "ALTER TABLE " . db_prefix("accounts") . " DROP standarduses";
			db_query($sql);
		}
	}
	debug("Migrating standard Specialty");
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='$specialty' WHERE specialty='1'";
	db_query($sql);

	module_addhook("choose-specialty");
	module_addhook("specialtynames");
	module_addhook("specialtymodules");
	return true;
}

function specialtygeneric_uninstall(){
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='DA'";
	db_query($sql);
	return true;
}

function specialtygeneric_dohook($hookname,$args){
	global $session,$resline;
	switch ($hookname) {
	case "choose-specialty":
		$session['user']['specialty']="Standard";		
		redirect("newday.php");
		break;
	case "specialtynames":
		$args[$spec] = translate_inline($name);
		break;
	case "specialtymodules":
		$args[$spec] = "specialtystandard";
		break;
	}
	return $args;
}

function specialtygeneric_run(){
}

?>