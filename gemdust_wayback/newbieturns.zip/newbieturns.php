<?php

function newbieturns_getmoduleinfo(){
    $info = array(
        "name"=>"Newbie Turns",
        "version"=>"1.0",
        "author"=>"Shannon Brown",
        "category"=>"Village",
		"download"=>"http://gemdust.com/module_download",
        "settings"=>array(
            "Newbie Turns - Settings,title",
			"extraturns"=>"How many extra turns per day?,int|20",
			"extradays"=>"For how many days?,int|10"
        ),
        "prefs"=>array(
            "Newbie Turns - User Preferences,title",
			"yesterday"=>"How many turns were granted yestoday?,int|1000",
        )
    );
    return $info;
}

function newbieturns_install(){
	module_addhook("newday");
    return true;
}

function newbieturns_uninstall(){
    return true;
}

function newbieturns_dohook($hookname,$args){
    global $session;
    switch($hookname){
   	case "newday":
		$yesterday = get_module_pref("yesterday");
		if ($yesterday == 0 || $extraturns > 500) break;
		$extradays = get_module_setting("extradays");
		if ($session['user']['days'] > $extradays) break;
		$extraturns = get_module_setting("extraturns");
		$turnadd = floor($yesterday - ($extraturns / 10));
		set_module_pref("yesterday",$yesterday);
		$session['user']['turns']+=$yesterday;
		if ($yesterday != 0) output("`nAs you are a new player, you gain %s extra turns for today.",$yesterday);
	break;
	}
    return $args;
}

function newbieturns_run() {
}

?>