<?php

// translator ready
// addnews ready
// mail ready

/* Calle Trader */
/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 17th September 2004 */

/* ver 1.1 includes pendant */

/*
 * This is the ticket seller for the Caravan Module and also the calle
 * shell trader, for access to the highcity module.
 * You do not need both of those modules installed.
 */

/*
 * The sell rate will automatically be set to at least one more than the
 * buy rate if you do not set them that way.
 */

require_once("lib/http.php");
require_once("lib/villagenav.php");

function calletrader_getmoduleinfo(){
    $info = array(
        "name"=>"Calle Trader",
        "version"=>"1.0",
        "author"=>"Shannon Brown",
        "category"=>"Village",
		"download"=>"http://gemdust.com/module_download",
		"settings"=>array(
            "Calle Trader - Settings,title",
			"allowall"=>"Have trader appear in all villages?,bool|0",
			"buyrate"=>"Amount of gems offered to player for five calle shells,range,2,50,1|11",
			"sellrate"=>"Amount of gems player needs to buy five calle shells,range,3,51,1|14",
			"allowall"=>"Have trader appear in all villages?,bool|0",
			"traderloc"=>"Where does the trader appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "Pendant - Settings,title",
			"pendant"=>"Activate the rune pendant?,bool|0",
			"runetol"=>"Rune tolerence,range,1,15,1|10",
			"firstscore"=>"First score,int|100000",
			"secondscore"=>"Second score,int|100000",
		),
        "prefs"=>array(
            "Calle Trader User Preferences,title",
            "callecount"=>"How many shells does the player have?,int|0",
            "hashad"=>"Has the player already bought a rune pendant?,bool|0",
            "triedlately"=>"Has the player tried recently?,int|0",
        )
    );
    return $info;
}

function calletrader_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
    return true;
}

function calletrader_uninstall(){
    return true;
}

function calletrader_dohook($hookname,$args){
    global $session;
	switch($hookname){
	case "village":			
		$allowall=get_module_setting("allowall");
		if ($session['user']['location'] == get_module_setting("traderloc") ||
				$allowall) {
            tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
            tlschema();
			addnav("V?Vernon's Trade Stall","runmodule.php?module=calletrader");
		}
		break;
	case "newday":			
		$triedlately = get_module_pref("triedlately");
		$triedlately -- ;
		set_module_pref("triedlately",$triedlately);
		break;
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("traderloc")) {
				set_module_setting("traderloc", $args['new']);
			}
		}
		break;
	}
	return $args;
}

function calletrader_run() {
    global $session;
    $op=httpget("op");
    $sellrate=get_module_setting("sellrate");
    $buyrate=get_module_setting("buyrate");
    $callecount=get_module_pref("callecount");
	$runetol = get_module_setting("runetol");
	$firstscore = get_module_setting("firstscore");
	$secondscore = get_module_setting("secondscore");
	$curscore = ($session['user']['dragonkills']*15) + ($session['user']['level']);

	if ($sellrate<=$buyrate) {
		$sellrate = $buyrate+1;
		set_module_setting("sellrate",$sellrate);
	}

	page_header("Vernon's Trade Stall");
	if ($op == ""){
		output("`&`c`bVernon, the Trader`b`c");
        output("`7You walk up to Vernon's stall, to see what he has to offer today.");
		output("He smiles and asks, `&\"And how can I be of assistance?\"`n`n");

		$sellsomething = 0;

		if (is_module_active("highcity")) {
			output("`7Gems and calle shells are arranged neatly under a glass cover.`n`n");
			// these are from Vernon's perspective... he is selling
			output("`&\"I'm buying five calle at the rate of %s gems, and selling for %s gems.\"",$buyrate,$sellrate);
			// these are from the player's perspective. They are buying
			addnav(array("B?Buy 5 Calle Shells (`5%s gems`0)",$sellrate),"runmodule.php?module=calletrader&op=buy");
			addnav(array("S?Sell 5 Calle Shells (`5%s gems`0)",$buyrate),"runmodule.php?module=calletrader&op=sell");
			$sellsomething = 1;
		}
		if ((get_module_setting("pendant")==1) && (get_module_pref("hashad") == 0) && (get_module_pref("triedlately") <= 0)) {
			output("`7An assortment of odd items sit in his display cabinet.`n`n");
			output("`&\"Maybe something in here interests you,\" `7he suggests.");
			addnav("L?Look in the cabinet","runmodule.php?module=calletrader&op=cabinet");
			$sellsomething = 1;
		}
		if ((get_module_pref("hashad") != 0) || (get_module_pref("triedlately") != 0)) {
			set_module_setting("firstscore",$secondscore);
			set_module_setting("secondscore",$curscore);
		}
		if (is_module_active("caravan") && is_module_active("ghosttown") &&
				get_module_setting("canvisit", "caravan")) {
			$vname = get_module_setting("villagename", "ghosttown");
			$ticketcost=get_module_setting("ticketcost", "caravan");
			output("`7Travel tickets to %s are in a small pile to his left.`n`n", $vname);
			addnav(array("T?Buy Ticket to %s (`^%s gold`0)", $vname,
						$ticketcost),
					"runmodule.php?module=calletrader&op=ticket");
			$sellsomething = 1;
		}
		if (is_module_active("icecaravan") && is_module_active("icetown") &&
				get_module_setting("canvisit", "icecaravan")) {
			$vname = get_module_setting("villagename", "icetown");
			$ticketcost=get_module_setting("ticketcost", "icecaravan");
			output("`7Travel tickets to %s are in a small pile to his right.`n`n", $vname);
			addnav(array("T?Buy Ticket to %s (`^%s gold`0)", $vname,
						$ticketcost),
					"runmodule.php?module=calletrader&op=iceticket");
			$sellsomething = 1;
		}

		if (!$sellsomething) {
			output("`n`n`7Vernon shrugs, `&\"I don't seem to have anything you need today!\"");
		}
	}elseif ($op == "sell" && $callecount>=5){
        output("`7You place five calle shells onto the glass, and Vernon inspects them carefully.");
        output("`7Satisfied, he hands you %s gems.",$buyrate);
		$callecount-=5;
		set_module_pref("callecount",$callecount);
		$session['user']['gems']+=$buyrate;
		debuglog("gained $buyrate gems selling 5 calle shells");
	}elseif ($op == "buy" && $session['user']['gems']>=$sellrate){
        output("`7You hand over your %s gems, and Vernon places five calle shells into your palm.",$sellrate);
		$callecount+=5;
		set_module_pref("callecount",$callecount);
		$session['user']['gems']-=$sellrate;
		debuglog("spent $sellrate gems on 5 calle shells");
	} elseif ($op == "iceticket" && is_module_active("icecaravan")) {
		$ticketcost=get_module_setting("ticketcost", "icecaravan");
		$hasticket=get_module_pref("hasticket","icecaravan");
		output("`7You announce that you'd like to buy one travel ticket, and you open your purse.");
		output("\"`&Certainly! One ticket. That will be %s gold, thank you.\"`n`n",$ticketcost);
		if ($session['user']['gold']<$ticketcost){
			// you don't have enough money.
			output("`7Vernon smiles.");
			output("\"Perhaps you'll return when you have enough gold to buy the ticket?\"");
			output("`7 You survey your purse sadly, and resolve to come back when you have more gold.");
		}elseif ($hasticket>0){
			// you already have a ticket.
			output("`7Vernon stops, then looks into your purse carefully.");
			output("\"`&Isn't that a ticket you have there already?");
			output("Ye don't be needing two!\"`n`n");
			output("`7You realize he is right!");
		}else{
			output("`7You hand over the gold and take the ticket eagerly.");
			$session['user']['gold']-=$ticketcost;
			set_module_pref("hasticket",1,"icecaravan");
			debuglog("spent $ticketcost gold on a travel ticket");
		}
	}elseif ($op == "ticket" && is_module_active("caravan")) {
		$ticketcost=get_module_setting("ticketcost", "caravan");
		$hasticket=get_module_pref("hasticket","caravan");
		output("`7You announce that you'd like to buy one travel ticket, and you open your purse.");
		output("\"`&Certainly! One ticket. That will be %s gold, thank you.\"`n`n",$ticketcost);
		if ($session['user']['gold']<$ticketcost){
			// you don't have enough money.
			output("`7Vernon smiles.");
			output("\"Perhaps you'll return when you have enough gold to buy the ticket?\"");
			output("`7 You survey your purse sadly, and resolve to come back when you have more gold.");
		}elseif ($hasticket>0){
			// you already have a ticket.
			output("`7Vernon stops, then looks into your purse carefully.");
			output("\"`&Isn't that a ticket you have there already?");
			output("Ye don't be needing two!\"`n`n");
			output("`7You realize he is right!");
		}else{
			output("`7You hand over the gold and take the ticket eagerly.");
			$session['user']['gold']-=$ticketcost;
			set_module_pref("hasticket",1,"caravan");
			debuglog("spent $ticketcost gold on a travel ticket");
		}
	}elseif ($op == "sell" || $op == "buy"){
        // you don't have enough
		output("`7You triumphantly dump your purse contents onto the glass and announce that his prices sound great.`n`n");
		output("Vernon eyes you carefully.");
        output("`&\"There seems to be a problem with that there arithmetic!\" `7he exclaims.");
		output("`7You decide to check his prices and count the contents of your purse again.");
		if ($op == "sell") addnav(array("B?Buy 5 Calle Shells (`5%s gems`0)",$sellrate),"runmodule.php?module=calletrader&op=buy");
		if ($op == "buy") 	addnav(array("S?Sell 5 Calle Shells (`5%s gems`0)",$buyrate),"runmodule.php?module=calletrader&op=sell");	
	}elseif ($op == "cabinet"){
        output("`7You step towards the cabinet and look inside.");
        output("`7On a battered hanger, a leather cord carries a small, dirty rune pendant, its insignia a mark you do not recognize.");
        output("`7It has a pricetag reading `^2 gems`7.");
		output("Vernon sees the item that has captured your interest, and hesitates.");
        output("`&\"I'm told it posesses some kind of power, but I don't know what it does,\" `7he admits.`n`n");
        output("`&\"I honestly don't know if I should sell it to you after all.\"");
		addnav("C?Try to convince him?","runmodule.php?module=calletrader&op=convince");	
	}elseif ($op == "convince"){
		$runetol += 1; // makes it a percentage over 100 that we can use
		$av = ($firstscore + $secondscore)/2;
		if (($curscore <= $av * $runetol) && $session['user']['gems'] > 1) { // go ahead
			output("`7You eye the rune pendant with what you hope is suitable nonchalance.");
			output("`&\"I'm sure that it wouldn't help me anyway, if I don't know what it does,\" `7you tell him, `&\"but it's kind of interesting in a hideous kind of way, so I'm happy to give you the gems, just for curiosity's sake.\"`n`n");
			output("`7Vernon finally nods, accepts your 2 gems, and hands you the pendant, which you put on, trying to hide your excitement.");
			output("`7It tingles against your skin, and you feel rather peculiar!");
			apply_buff('pendant',array("name"=>'`QPendant Buzz',"rounds"=>100,"activate"=>"defense","survivenewday"=>1,"defmod"=>1.2, "schema"=>"module-calletrader"));
			set_module_pref("triedlately",10);
			set_module_pref("hashad",1);
			$session['user']['gems'] -= 2;
			set_module_setting("firstscore",$secondscore);
			set_module_setting("secondscore",$curscore);
		} elseif (($curscore > $av * $runetol) || e_rand(1,3) == 1) { // you don't deserve it, you are too strong already, or you're not lucky today
			output("`7Vernon shakes his head.");
			output("`&\"I'm sorry, I think I should keep it until I know what it does, but if you do find out what that symbol is, maybe you could let me know.\"`n`n");
			set_module_pref("triedlately",5);
			output("`7You realise he won't be swayed, so you wander off for now.");
		} else {
			output("`7You realise he won't be swayed, so you wander off for now.");
		} 	
	}
	villagenav();
	page_footer();
}

?>