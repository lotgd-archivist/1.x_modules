<?php

/* The Sneeze */
/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 17th July 2005 */

/* ver 1.1 1st Sept 2005 minor cleanups */

require_once("lib/villagenav.php");
require_once("lib/http.php");

function sneeze_getmoduleinfo(){
    $info = array(
        "name"=>"Sneeze",
        "version"=>"1.1",
        "author"=>"Shannon Brown",
        "category"=>"Inn Specials",
        "download"=>"http://gemdust.com/module_download",
        "settings"=>array(
            "Sneeze - Settings,title",
			"dkprot"=>"Protect users under this many DKs,int|0",
			"ffprot"=>"Protect users with more than this many remaining fights,int|10",
			"dayprot"=>"Protect users that were sneezed on in the last few days (set zero not to space the days out),range,0,10,1|5"
        ),
		"prefs"=>array(
            "Sneeze - User Preferences,title",
			"lastsneeze"=>"Days since player last got sneezed on,int|0"
        )
    );
    return $info;
}

function sneeze_chktest(){
	global $session;
	$dks = $session['user']['dragonkills'];
	$ffs = $session['user']['turns'];
	$dkprot = get_module_setting("dkprot","sneeze");
	$lastnseeze = get_module_pref("lastsneeze","sneeze");
	$dayprot = get_module_setting("dayprot","sneeze");
	$ffprot = get_module_setting("ffprot","sneeze");
	if ($dks < $dkprot || $lastnseeze <= $dayprot || $ffs > $ffprot) {
		$chance = 0;
	} else {
		$chance = 100;
	}
	return($chance);
}

function sneeze_install(){
	module_addeventhook("inn", "require_once(\"modules/sneeze.php\"); return sneeze_chktest();");
	module_addhook("newday");
    return true;
}

function sneeze_uninstall(){
    return true;
}

function sneeze_dohook($hookname,$args){
    global $session;
    switch($hookname){
		case "newday":
			$lastsneeze = get_module_pref("lastsneeze");
			$lastsneeze++;
			set_module_pref("lastsneeze",$lastsneeze);
			if ($lastsneeze == 0) {
				output("`n`7Looks like that guy in the bar was sick - you've come down with a cold and you feel weary!`n");				
				apply_buff('sneeze',array("name"=>"Common Cold","rounds"=>200,"defmod"=>0.85));
			}
		break;
	}
    return $args;
}


function sneeze_runevent($type) {
    global $session;
	$from = "inn.php?";
	$op = httpget('op');
    if ($op == "") {
    	$session['user']['specialinc'] = "module:sneeze";
		set_module_pref("lastsneeze",-1);
		output("`7As you're making your way through the crowded bar, a patron sniffles, then sneezes all over you!`n`n");
		output("`7You feel absolutely disgusted, and you're sure that man cannot be healthy!`n`n");

		$session['user']['specialinc'] = "";
    }
}
?>