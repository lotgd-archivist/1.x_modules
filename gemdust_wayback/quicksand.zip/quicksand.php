<?php

/* Quicksand */
/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 17th July 2005 */

/* ver 1.1 1st Sept 2005 minor cleanups */

require_once("lib/villagenav.php");
require_once("lib/http.php");

function quicksand_getmoduleinfo(){
    $info = array(
        "name"=>"Quicksand",
        "version"=>"1.1",
        "author"=>"Shannon Brown",
        "category"=>"Forest Specials",
        "download"=>"http://gemdust.com/module_download",
        "settings"=>array(
            "Quicksand - Settings,title",
			"dkprot"=>"Protect users under this many DKs,int|0",
			"ffprot"=>"Protect users with more than this many remaining fights,int|10",
			"dayprot"=>"Protect users that fell into the quicksand in the last few days (set zero not to space the days out),range,0,10,1|5"
        ),
		"prefs"=>array(
            "Quicksand - User Preferences,title",
			"lastsink"=>"Days since player last fell in,int|0",
			"tcount"=>"Turns they have panicked for,int|0"
        )
    );
    return $info;
}

function quicksand_sinktest(){
	global $session;
	$dks = $session['user']['dragonkills'];
	$ffs = $session['user']['turns'];
	$dkprot = get_module_setting("dkprot","quicksand");
	$lastnseeze = get_module_pref("lastsink","quicksand");
	$dayprot = get_module_setting("dayprot","quicksand");
	$ffprot = get_module_setting("ffprot","quicksand");
	if ($dks < $dkprot || $lastnseeze <= $dayprot || $ffs > $ffprot) {
		$chance = 0;
	} else {
		$chance = 100;
	}
	return($chance);
}


function quicksand_install(){
	module_addeventhook("forest", "require_once(\"modules/quicksand.php\"); return quicksand_sinktest();");
	module_addhook("newday");
    return true;
}

function quicksand_uninstall(){
    return true;
}

function quicksand_dohook($hookname,$args){
    global $session;
    switch($hookname){
		case "newday":
			$lastsink = get_module_pref("lastsink");
			$lastsink++;
			set_module_pref("lastsink",$lastsink);
			set_module_pref("tcount",0);
		break;
	}
    return $args;
}


function quicksand_runevent($type) {
    global $session;
	$from = "forest.php?";
	$tcount = get_module_pref("tcount");
	$op = httpget('op');
	if ($session['user']['turns'] >= 1) $session['user']['turns']--;
    if ($op == "") {
    	$session['user']['specialinc'] = "module:quicksand";
		set_module_pref("lastsink",0);
		output("`7As you're exploring the forest, you feel the ground become soft beneath your feet, and before you can blink, you realize you've stumbled into some quicksand!`n`n");
	}
	if ($op == "" || $op == "yell" || $op == "wade") {
    	$session['user']['specialinc'] = "module:quicksand";
		if ((e_rand(1,5) == 1 && $session['user']['turns'] <= get_module_setting("ffprot")) || get_module_pref("tcount") > 1 || $op == "yell" || $op == "wade") {
			if ($op == "" || $op == "yell") output("In a blind frenzy you flail your arms ineffectually, screaming and thrashing about in the filthy mud.");
			output("Memories of your dragon-hunting days tumble through your panicked mind.`n`n");
			if ($op == "wade" && $tcount == 0) {
				output("With determination in your mind, you set out to try to save yourself.");
				output("It takes you only a moment to realize that you have sealed your fate, as you feel the mud rise around you.");
				output("Memories of your dragon-hunting days tumble through your panicked mind.`n`n");
				set_module_pref("tcount",2);
			}
			if (get_module_pref("tcount") < 3){
				$tcount++;
				set_module_pref("tcount",$tcount);
				addnav("Quicksand!");
			}
			if (get_module_pref("tcount") == 1) {
				output("As the mud rises, you desperately crane your neck to keep your mouth and nose high enough to breathe.`n`n");
				output("Will anyone hear your cries?");
				addnav("Quicksand!");
				addnav("HELP!",$from."op=".$op);
			}
			if (get_module_pref("tcount") == 2) {
				output("Your movements sink you further and further towards your doom.");
				output("It's a pity you never wrote your will.");
				addnav("Quicksand!");
				addnav("SAVE ME!",$from."op=".$op);
			}
			if (get_module_pref("tcount") == 3) {
				output("You desperately wonder why the forest is so quiet apart from your screams.`n`n");
				output("Just as the level nears your nose and all hope fades, a passing traveller finds you and throws you a length of rope.`n`n");
				output("You manage to drag yourself free, but your energy is almost completely depleted, and you fall the the ground in a stupor.");
				$session['user']['hitpoints'] = 1;
				$session['user']['specialinc'] = "";
			}
		} else {
			output("Your heart races as you desperately try to figure out what to do.");
			output("Should you scream for help, try to get out, or stay still and hope another adventurer saves you?");
			addnav("Quicksand!");
			addnav("Y?Try Yelling for Help",$from."op=yell");
			addnav("W?Try To Wade Out",$from."op=wade");
			addnav("S?Stay Perfectly Still",$from."op=still");
		} 
	} elseif ($op=="still"){
		output("Miraculously, you are able to avoid panic, and you make a determined effort to remain perfectly still.`n`n");
		require_once("lib/mountname.php");
		list($mountname, $lcmountname) = getmountname();
		if ($lcmountname != "your ") {
			output("In a feat of amazing bravery, %s sees your predicament and runs off to find help.",$lcmountname);
			output("Just as the level nears your nose and all hope fades, %s returns with a passing traveller who throws you a length of rope.",$lcmountname);
			if (e_rand(1,20) == 1) {
				output("As you use all your remaining energy to drag yourself free, %s loses its footing and ends up in the mire.`n`n",$lcmountname);
				output("To your horror, it is unable to grasp the ropes you throw towards it, and with a sickening feeling you watch it sink to its death.`n`n");
				global $playermount;
				$debugmount = $playermount['mountname'];
				debuglog("lost their mount, a $debugmount, in quicksand.");
				$session['user']['hashorse'] = 0;
				if(isset($session['bufflist']['mount'])) strip_buff("mount");
			} else {
				output("You manage to drag yourself free, but your energy is almost completely depleted, and you fall the the ground in a stupor.");
			}
			$session['user']['hitpoints'] = 1;
			$session['user']['specialinc'] = "";
		} else {
			output("Just as the level nears your nose and all hope fades, a passing traveller finds you and throws you a length of rope.`n`n");
			output("You manage to drag yourself free, but your energy is almost completely depleted, and you fall the the ground in a stupor.");
			$session['user']['hitpoints'] = 1;
			$session['user']['specialinc'] = "";
		}
    }
}
?>