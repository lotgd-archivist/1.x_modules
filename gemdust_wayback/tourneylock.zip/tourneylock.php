<?php

// v1.1 rejevenate not new day
// v1.2 reset seen master to 0
// v1.3 farmies PvP blocked

/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 12 June 2005 */
/* tourneylock module */

// v1.1 rejevenate not new day
// v1.2 reset seen master to 0
// v1.3 23 November 2004 admin-settable ending text (I don't think other 
// servers want to direct players to keep an eye on GemDust.com)
// v1.4 12 June 2006 no PvP for farmies, no access to tattoos
// v1.5 22 August 2006 Rejuv button available for last 5 days before start date

function tourneylock_getmoduleinfo(){
	$info = array(
		"name"=>"Tourney Lock Module",
		"version"=>"1.5",
		"author"=>"Shannon Brown",
		"category"=>"Administrative",
		"settings"=>array(
			"Tourney Lock Settings,title",
			"begin"=>"Start date for tourney (mm-dd-yyyy)|06-17-2005",
			"dateinwords"=>"Start date in words|June 17",
			"tourneylength"=>"How many days will it be open for?,int|10",
			"tourneyon"=>"Is tourney running?,bool|0",
			"presentday"=>"What day of the tourney is it? 0 is not started yet,int|0",
		),
		"prefs"=>array(
			"Tourney Lock User Prefs,title",
			"alreadyset"=>"Has the user already had gems and charm reset?,bool|0",
		)
			
	);
	return $info;
}

function tourneylock_install(){
	module_addhook("newday");
	module_addhook("header-inn");
	module_addhook("header-news");
	module_addhook("graveyard");
	module_addhook("village");
	module_addhook("newday-runonce");
	module_addhook("forest");
	module_addhook("lodge");
	module_addhook("shades");
	return true;
}

function tourneylock_uninstall(){
	return true;
}

function tourneylock_dohook($hookname,$args){
	global $session;

	blocknav("gardens.php");

	$tourneyon = get_module_setting("tourneyon");
	$tourneylength = get_module_setting("tourneylength");
	$presentday = get_module_setting("presentday");
	$dateinwords = get_module_setting("dateinwords");
	$begin = get_module_setting("begin");
	$begin = str_replace("-", "/", $begin);
	$htime = strtotime($begin);
	$daystillstart = ceil(($htime - time())/86400);
	$timetillstart = $htime - time(); 
	$timecheck = time();

	switch($hookname){
		case "newday":
			if ($presentday == 0) {
				// not started yet!
				output("`n`b`^This tournament starts on %s. You can log in now and play up to level 15, but the dragon will not be in the cave until the tourney starts.`b",$dateinwords);
			} elseif ($presentday > $tourneylength) {
				// it's finished
				output("`n`b`^This Tournament is now finished. Keep an eye on the GemDust.com home page to see the Hall of Fame results or to join a new tourney.`b");
				if ($session['user']['acctid'] != 1) {
					$session['user']['alive'] = false;
					$session['user']['deathpower'] = 0;
					$session['user']['hitpoints'] = 0;
					$session['user']['gravefights'] = 0;
				}
			} else {
				set_module_setting("tourneyon",1);
				output("`n`b`^The tourney runs for %s game days. It is now day %s.`n`nIf you have not yet killed the dragon you have a Rejuvemination link to enable you to catch up quickly, so it's not too late to join!`b",$tourneylength,$presentday);
			}
		break;
		case "header-inn":
			if ($session['user']['dragonkills'] == 0) {
				blocknav("inn.php?op=bartender&act=listupstairs");
			}
		break;
		case "village":
			$setcheck = get_module_pref("alreadyset");
			if ($daystillstart <= 5 && $session['user']['dragonkills'] == 0) {
				if ($session['user']['turns'] == 0) {
					tlschema($args['schemas']['othernav']);
					addnav($args['othernav']);
					tlschema();
					addnav("Rejuveminate","runmodule.php?module=tourneylock");
				}
				blocknav("runmodule.php?module=petra");
				blocknav("stables.php");
				blocknav("pvp.php");
			} elseif ($tourneyon == 0) {
				blocknav("runmodule.php?module=petra");
				blocknav("stables.php");
				blocknav("pvp.php");
			}
			if ($tourneyon == 1 && $session['user']['dragonkills'] == 1 && $setcheck == 0) {
				// reset gems and charm
				$session['user']['gems'] = 5;
				$session['user']['charm'] = 0;
				$session['user']['maxhitpoints'] = ($session['user']['level'] * 10);
				while(list($key,$val)=each($session['user']['dragonpoints'])){
					if ($val=="hp") $session['user']['maxhitpoints']+=5;
				}
				$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
				set_module_pref("alreadyset",1);
				output("As the tourney has now started, your charm has been reset to zero, your hitpoints to base, and your gems to 5. Good luck!");
				debug(" dks ".$session['user']['dragonkills']);
				debug(" set ".get_module_pref("alreadyset"));
				debug(" gems ".$session['user']['gems']);
				$setcheck = get_module_pref("alreadyset");
				debug("is it already set? ".$setcheck);
			}
		break;
		case "shades":
		case "header-news":
			if ($daystillstart <= 5 && $session['user']['dragonkills'] == 0) {			
				if ($session['user']['gravefights'] == 0) {
					tlschema($args['schemas']['othernav']);
					addnav($args['othernav']);
					tlschema();
					addnav("Magically Gain Torments","runmodule.php?module=tourneylock&op=favor");
				}
			}
			if ($tourneyon == 0 && $presentday >= $tourneylength) {	// tourney over		
				tlschema($args['schemas']['othernav']);
				addnav($args['othernav']);
				tlschema();
				addnav("`^Why Am I Dead?","runmodule.php?module=tourneylock&op=why");
			}
			addnav("Hall of Fame","hof.php");
			if ($tourneyon == 0 && $presentday >= $tourneylength) blocknav("graveyard.php");
		break;
		case "graveyard":
			if ($tourneyon == 1 && $session['user']['dragonkills'] == 0) blocknav("graveyard.php?op=haunt");
			if ($tourneyon == 0 && $presentday >= $tourneylength) {	// tourney over		
				tlschema($args['schemas']['othernav']);
				addnav($args['othernav']);
				tlschema();
				addnav("`^Why Am I Dead?","runmodule.php?module=tourneylock&op=why");
			}
			addnav("Hall of Fame","hof.php");
		break;
		case "lodge":
			output("`n`n`\$Please spend carefully. Donation buys can ONLY be used in THIS tournament and can't be refunded.");
		break;
		case "forest":
			if ($tourneyon != 1) blocknav("forest.php?op=dragon");
		break;
		case "newday-runonce":
			if ($timetillstart < 600 && $timetillstart > -600) { // 10 minute tolerance
				// start today. set tourney on.
				set_module_setting("tourneyon",1);
				set_module_setting("presentday",1);
			} elseif ($timetillstart > 0) {
				// not started yet!
				set_module_setting("tourneyon",0);
			} elseif ($presentday > $tourneylength) {
				// it's finished
				set_module_setting("tourneyon",0);
			} else {
				// in progress
				get_module_setting("presentday");
				$presentday ++;
				set_module_setting("presentday",$presentday);
			}
		break;
	}
	return $args;
}

function tourneylock_run(){
    global $session;
	$op = httpget("op");
	if ($op == "" && $session['user']['turns']==0){
		page_header("Mystical Rejuvemination");
		output("`&`c`bMystical Rejuvemination`b`c");
		output("`#Icewater runs through your veins.");
		output("Through the magic of magickness, and with much mystical mystery, you miraculously seem to have gained ten turns.");
		output("`)If you lost to your master today, you can now challenge him again.");
		$session['user']['turns']+=10;
		$session['user']['seenmaster'] = 0;
	} elseif ($op == "why"){
		page_header("Why Am I Dead?");
		output("`&`c`bWhy Am I Dead?`b`c");
		output("`n`#The tournament is finished.`n`n");
		output("It is normal to be dead. Even if you get a new day or come back tomorrow, you'll still be dead. Saucy has only let you in here so that you can see the Hall of Fame or read YOMs for a few days. After that, the server gets deleted.");
		output("`n`nCheck out the GemDust.com home page for more tournaments. And thanks for playing.");
		$session['user']['turns']+=10;
		$session['user']['seenmaster'] = 0;
	} else {
		page_header("Mystical Favor");
		output("`&`c`bMystical Favor`b`c");
		output("`#Icewater runs through your veins.");
		if ($session['user']['deathpower'] < 10) $session['user']['deathpower']=10;
		if ($session['user']['deathpower'] <= 100) {
			$session['user']['gravefights']+=10;
			output("Through the magic of magickness, and with much mystical mystery, you miraculously seem to have gained ten torments and possibly, ten favor.");
		} else {
			output("`4Ramius is calling you to resurrect!");
		}
	}
	villagenav();
	page_footer();
}

?>