<?php

function confront_getmoduleinfo(){
   $info = array(
       "name"=>"Confront",
       "version"=>"1.0",
       "author"=>"Shannon Brown",
       "category"=>"Forest Specials",
       "download"=>"http://gemdust.com/module_download"
   );
   return $info;
}

function confront_install(){
	module_addeventhook("forest", "return 100;");
	module_addeventhook("travel", "return 100;");
   return true;
}

function confront_uninstall(){
   return true;
}

function confront_dohook($hookname,$args){
   return $args;
}

function confront_runevent($type,$link) {
	global $session;
	output("`5`nAs you're searching for creatures and minding your own business, you're suddenly face-to-face with MightyE himself.`n`n");
	if (e_rand(1,2)== 1 && $session['user']['turns'] > 1) {
		output("`@\"RAHAHA!!!\" `5he bellows.`0`n`n");
		output("`@\"Don't you know I'm teh head dude of this game? Duh. Duh duh duh.\" `5He chuckles and pulls a silly face.`0`n`n");
		output("`@\"I'm bored!\" `5he says.`0`n`n");
		output("`5He ties you to a tree and wanders off, whistling some happy tune.`n`n");
		output("`5By the time you've untied yourself, quite a few minutes have passed and you've lost time for a fight. Or two.`n`n");
		$session['user']['turns']--;
		if ($session['user']['turns'] > 0) $session['user']['turns']--;
	} else {
		output("`@\"Hello!\" `5he says.`0`n`n");
		if (e_rand(1,4)== 1) {
			output("`@\"I'm bored!\" `5he says.`0");
			output("`@\"Here, have a turn.\"`0`n`n");
			$session['user']['turns']++;
			output("`5You gain a turn!`n`n");
		}
		output("`5He wanders off, whistling some happy tune.`n`n");
	}
	$session['user']['specialinc'] = "";
}

function confront_run(){
}

?>