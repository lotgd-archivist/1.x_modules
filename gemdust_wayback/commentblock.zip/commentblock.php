<?php

// Originally intended for use with TourneyLock module, however,
// reduces the moderation work on any small server.
// Removes commentary areas in the Inn, Grassy Field and Dark Horse
// Tavern, removes the Curious Rock, removes Clans (switchable)

/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 12 June 2005 */
/* commentblock module */

/* v1.1 24th November 2005 - clan blocking made switchable  */



function commentblock_getmoduleinfo(){
	$info = array(
		"name"=>"commentblock Module",
		"version"=>"1.1",
		"author"=>"Shannon Brown",
		"category"=>"Administrative",
		"download"=>"http://gemdust.com/module_download/",
		"settings"=>array(
			"Comment Block Settings,title",
			"clanblock"=>"Block Clans Nav?,bool|1"
		),
	);
	return $info;
}

function commentblock_install(){
	module_addhook("village");
	module_addhook("inn");
	module_addhook("blockcommentarea");
	return true;
}

function commentblock_uninstall(){
	return true;
}

function commentblock_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "inn":
			if (get_module_setting("clanblock") == 1) blocknav("inn.php?op=converse");
		break;
		case "village": 
			blocknav("rock.php");
			blocknav("clan.php");
		break;
		case "blockcommentarea":
		if ($args['section'] == 'grassyfield') $args['block'] = 'yes';
		if ($args['section'] == 'darkhorse') $args['block'] = 'yes';
			break;
	}
	return $args;
}

function commentblock_run(){
	return true;
}

?>