<?php

// Music for Login v1.0
/* ver 1.0 by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* 22 June 2006 */

// simple module for adding music to your login page.
// This page can be adapted to say, hook village instead (to have
// music in all villages) or for the gardens, etc

// THINK CAREFULLY about what you use and where you decide to use
// it. Make the file small to conserve bandwidth. Loud and
// intrusive music tends to annoy players, and I don't recommend
// you install music in too many areas lest it become a pain in
// the backside.

function background_music_getmoduleinfo(){
    $info = array(
        "name"=>"Background Music",
        "version"=>"1.0",
        "author"=>"Shannon Brown",
        "category"=>"General",
		"download"=>"http://gemdust.com/module_download",
		"settings"=>array(
			"trackname"=>"Name of the music,|",
			"trackurl"=>"URL of the embedded file: http://,|"
		)
    );
    return $info;
}

function background_music_install(){
	module_addhook("index");
    return true;
}

function background_music_uninstall(){
    return true;
}

function background_music_dohook($hookname,$args){
	switch($hookname){
	case "index":
		$trackname = get_module_setting("trackname");
		$trackurl = get_module_setting("trackurl");
		rawoutput("<CENTER><embed src='http://".$trackurl."' loop=true height='15px'><BR>Login Page Background Music:<BR>");
		output("%s",$trackname);
		rawoutput("</CENTER><BR><BR>");
		break;
	}
	return $args;
}

function background_music_run() {
}

?>