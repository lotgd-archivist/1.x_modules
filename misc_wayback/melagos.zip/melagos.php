<?php
/*
Melagos the Smith
File:	melagos.php
Author:	Chris Vorndran (Sichae)
Date:	9/17/2004
Version:1.1 (9/20/2004)

Melagos the Smith came to me after a Farbory asked for a smith in the city.
I must've complied ^.^
So, I wrote this module, in hopes to satisfy the little booger.
He enjoyed it. ^.^

v0.8
A Farmie on my Server asked if I would make a module...so I did.

v0.9
Divided up the Text/Story, Transalation ready and cities.php ready

v1.0
Finalized Text/Story, Fixed Grammar and Syntax

v1.1
Now able to change the cost in gold and gems for the reforging. Thanks Jim for the suggestion!
*/
require_once("lib/http.php");
require_once("lib/villagenav.php");
function melagos_getmoduleinfo() {
	$info = array(
		"name"=>"Melagos the Smith",
		"author"=>"Chris Vorndran",
		"version"=>"1.42",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/Sichae/melagos.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows a user to be able to upgrade their weapon/armor for a customizable Gem Cost.",
		"settings"=>array(
			"Melagos Settings,title",
   			"gemcost"=>"Cost in gems for Melagos' Services,int|3",
			"Melagos Location,title",
   			"smithloc"=>"Where does the smith appear,location|".getsetting("villagename", LOCATION_FIELDS)
			),
		"prefs"=>array(
			"Melagos Prefences,title",
			"armorup"=>"Has Armor been upgraded,bool|0",
			"weaponup"=>"Has Weapon been upgraded,bool|0",
			)
		);
	return $info;
}
function melagos_install(){
	module_addhook("village");
	module_addhook("dragonkilltext");
	module_addhook("changesetting");
	return true;
}
function melagos_uninstall(){
	return true;
}
function melagos_dohook($hookname,$args){
	global $session;
	$upgraded=get_module_pref("upgraded");
	switch($hookname){
	case "changesetting":
    if ($args['setting'] == "villagename") {
    if ($args['old'] == get_module_setting("smithloc")) {
       set_module_setting("smithloc", $args['new']);
       }
    }
    break;
  	case "village":
		if ($session['user']['location'] == get_module_setting("smithloc")) {
		tlschema($args['schemas']['marketnav']);
        addnav($args['marketnav']);
		tlschema();
        addnav("Melagos the Smith","runmodule.php?module=melagos&op=enter");
	}
    break;
	case "dragonkilltext":
		if (get_module_pref("weaponup") || get_module_pref("armorup")){
		output("`n`n`2Since you have discarded your weapons and armor, you have lost the re-forges and your `@Melagos `2account has been renewed.");
		set_module_pref("weaponup",0);
		set_module_pref("armorup",0);
	}
		break;
	}
	return $args;
}
function melagos_run(){
	global $session;

   	$weaponup = get_module_pref("weaponup");
   	$armorup = get_module_pref("armorup");
   	$gemcost = get_module_setting("gemcost");
   	$weapon = $session['user']['weapon'];
   	$armor = $session['user']['armor'];
   	$theygems = $session['user']['gems'];
   	$op = httpget("op");
   	
   	page_header("Melagos the Smith");
   	
   	if($op=="enter"){
			output("`2You barge into the shop and `@Melagos `2looks at you strangely.");
			output(" He looks at your dinged up `6%s`n`n",$weapon);
			output("\"`@You be wantin' that fixed right der?`2\" He asks you in a gruff voice.");
			output(" You cock your head to the side");
			output("`n`n`2You start to get a little disgruntled.");
			output(" \"`3No you imbecile, I want something better.");
			output(" Re-forge it or something.`2\"");
			output("`2You look ahead and `@Melagos `2has disappeared.");
			output(" You notice that your `^%s `2and your `^%s `2have been set on the counter.",$weapon,$armor);
		if ($weaponup == 0 && $armorup == 0){
			output("`n`n`@Melagos `2reappears and says, \"`@It'll cost `5%s gems`@. Still want yer gull dern re-forge?\"",$gemcost);
		}else{
			output("`n`n`@Melagos `2runs to the door and slams it on your face.");
			output("You can see a small ledger he has and it looks as if it has been filled with your re-forges already.");
			output("`@\"Come back when you do something of grand note.\"");
		}
		addnav("Reforgings");
	   	if ($weaponup == 0) addnav("Reforge Weapon","runmodule.php?module=melagos&op=weap");
	   	if ($armorup == 0) addnav("Reforge Armor","runmodule.php?module=melagos&op=armor");
		addnav("Leave");
	   	villagenav();
	}elseif ($theygems<$gemcost){
		output("`@Melagos `2looks at you.");
		output(" \"`2I am so sorry, but you need `5%s gems `@to purchase a re-forging.`2\"",$gemcost);
		villagenav();
	}elseif($op=="weap"){
		output("`2After weighing all of the critical factors, you decided to upgrade your `^%s.",$weapon);
		output(" `@Melagos `2nods and grabs your `^%s`2.",$weapon);
		output(" You sit in a chair and begin to read a fascinating article in \"`\$LOTGD Today`2\".`n`n");
		output("`&A couple of hours pass...`n`n");
		output("`@Melagos `2walks back out and hands you your newly forged `^%s.",$weapon);
		output(" `2You smile as he hands it back to you.");
		output("`2\"`@I hope ye are happy.");
		output(" It took me nearly 3 hours just to figure out what the heck to do...`2\" You stare blankly at `@Melagos.");
		output("`2He begins to laugh and says, \"`@Nah, I am just kiddin' ye. Now go on and have fun.`2\"");
		debuglog("lost $gemcost gems for plus 1 attack at Melagos");
		$session['user']['weapon'] = $session['user']['weapon']." +";
		$session['user']['attack']+=1;
		$session['user']['weapondmg']+=1;
		$session['user']['gems']-=$gemcost;
		$weaponup++;
        set_module_pref("weaponup",$weaponup);
		if ($armorup == 0) addnav("Return to Storefront","runmodule.php?module=melagos&op=enter");
		villagenav();
	}elseif($op=="armor"){
		output("`2You look back and forth from your `^%s `2to your `^%s`2.",$weapon,$armor);
		output(" You finally decide on your `^%s`2.",$armor);
		output(" `@Melagos `2nods and picks up your `^%s`2.",$armor);
		output(" You sit in a chair and begin to read a tiny book.");
		output("It is so small, you can barely make out the print.`n`n");
		output("`&A few hours pass...`n`n");
		output("`@Melagos `2walks back in, holding your shiny new `^%s`2.",$armor);
		output(" You gladly pay the man and try on your new equipment.");
		output("`@Melagos `2thumbs through all his earnings and laughs heartily, \"`@Didn't think I woulda made this much money...`2\"");
		debuglog("lost $gemcost gems for plus 1 defense at Melagos");
		$session['user']['armor'] = $session['user']['armor']." +";
		$session['user']['defense']+=1;
		$session['user']['armordef']+=1;
		$session['user']['gems']-=$gemcost;
		$armorup++;
        set_module_pref("armorup",$armorup);
		if ($weaponup == 0) addnav("Return to Storefront","runmodule.php?module=melagos&op=enter");
		villagenav();
	
}
page_footer();
}	
?>		 	