Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a specialty module for LotGD 0.9.8.
It contains a ranger.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy all files within this zip into your modules
directory, except this one.

Login to the Superuser Grotto and Install / Activate it.