<?php
/*
Details:
 * This allows users to buy death door potions, to exit the underworld
History Log:
 * Version 1.0
  o Seems Stable
 * Version 1.1:
  o Didn't show the cost correctly
 * Version 1.2:
  o Now uses the 'potionshop' module
*/
require_once("lib/commentary.php");
require_once("lib/villagenav.php");

function deathdoorpotion_getmoduleinfo(){
	$info = array(
		"name"=>"Death Door Potions",
		"version"=>"1.2",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/deathdoorpotion.zip",
		"settings"=>array(
			"Death Door Potions - Settings,title",
			"detbuy"=>"Allow users to buy Death Door potions?,bool|1",
			"pCost"=>"Cost of Death Door potions?,int|15000",
			"adminPotion"=>"Admin have unlimited access to Death Door potions?,bool|1",
			"(admin are those that can edit users),note",
			"Recharge Potions - Location Settings,title",
			"detbuyloc"=>"Allow users to buy Death Door potions from ALL cities?,bool|1",
			"detbuylocw"=>"If no- then which one?,location|".getsetting("villagename", LOCATION_FIELDS),
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"detPot"=>"Death Door potions?,int|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
		),
	);
	return $info;
}

function deathdoorpotion_install(){
	if (!is_module_active('deathdoorpotion')) {
		output("`n`Q`b`cInstalling Death Door Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Death Door Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("pre-newday");
	module_addhook("potionshop-list");
	module_addhook("footer-shades");
	module_addhook("footer-graveyard");
	return true;
}

function deathdoorpotion_uninstall(){
	output("`n`Q`b`cUninstalling Death Door Potions Module.`c`b`n");
	return true;
}

function deathdoorpotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('detPot')>0) {
					output("`n`^You have `@%s`^ Death Door Potions...`n",get_module_pref('detPot'));
				}
			}
		break;
		case "pre-newday":
			global $resurrection,$spirits;
			if (httpget('dpotion')=='true') {
				$args['resurrection']=false;
				$resurrection="false";
				httpset('resurrection',"false");
				addnews("`&%s`& has been resurrected with a `%Death's Door Potion`&.",$session['user']['name']);
				$spirits=-6;
			}
		break;
		case "potionshop-list":
			if (get_module_setting('detbuyloc')==0&&get_module_setting('hook','potionshop')==1) set_module_setting('detbuyloc',0);
			if (get_module_setting('detbuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$det=array();
				$det['gold']=$price;
				$det['name']=translate_inline("Death's Door Potions");
				if (get_module_setting('detbuy')==1&&get_module_setting('detbuyloc')==1||get_module_setting('detbuy')==1&&get_module_setting('detbuyloc')==1&&$session['user']['location']==get_module_setting('detbuylocw')) {
					$det['link']="runmodule.php?module=deathdoorpotion&op=shop";
					$det['avail']=translate_inline("In Stock");
				} else {
					$det['avail']=translate_inline("Only available in %s..");
					$det['avail']=str_replace('%s',get_module_setting('detbuylocw'),$det['avail']);
					$det['link']="";
				}
				$det['nav']=translate_inline("Buy a `\$Death's Door`0 Potion");
				$det['effects']=translate_inline("Opens a door from death, to the realm of the living.");
				$args[]=$det;
			}
		break;
		default:
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
				set_module_pref('detPot',1);
			}
			if (get_module_pref('detPot')>0) {
				global $battle;
				$potion="<br>";
				output("`n`n`4`bDeath's Door Potions:`b");
				$x = get_module_pref('detPot');
				$y = 0;
				while ($x>0) {
					$y++;
					$x--;
					if ($battle!==true) {
						$c = translate_inline("Drink the Death's Door Potion...");
						$potion.="<a style='border:0;' border='0'  onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=deathdoorpotion&op=use\">";
						$potion.="<img style='border:0;' border='0' src=\"./images/deathdoorpotion/potion.gif\" title=\"$c\" alt=\"$c\">";
						$potion.="</a>";
						addnav("","runmodule.php?module=deathdoorpotion&op=use");
					} else {
						$c = translate_inline("Potions cannot be used in Battle!");
						$potion.="<img src=\"./images/deathdoorpotion/potionclear.gif\" style='border:0;' border='0'  title=\"$c\" alt=\"$c\">";
					}
					if ($y>=6) {
						$y=0;
						$potion.="\n<br/>";
					}
				}
				rawoutput($potion);
			}
		break;
	}
	return $args;
}

function deathdoorpotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			require_once('lib/increment_specialty.php');
			page_header("You swig a potion..");
			set_module_pref('detPot',get_module_pref('detPot')-1);
			output("`@The ethereal potion seems yet more real down here... how so, you do not know.. drinking it, light burns you, and your flesh solidifies...");
			$session['user']['restorepage']="news.php?c=1";
			addnav("Follow the Light","newday.php?dpotion=true&resurrection=true");
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('detPot',get_module_pref('detPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing a %s gold to %s, he hands you an Ethereal looking Death's Door Potion... as you place it in your %s`@ it seems somewhat Ethereal..",$price,"`n`#CortalUX`@",$session['user']['armor']);
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("movepotion-navs");
		break;
	}
	page_footer();
}
?>