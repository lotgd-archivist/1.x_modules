<?php
require_once("lib/villagenav.php");
function superslots_getmoduleinfo(){
	$info = array(
		"name"=>"Super Dragon Slots",
		"version"=>"1.06",
		"author"=>"RPGSL",
		"category"=>"RPGSL",
		"download"=>"http://rpgsl.com/lotgd/superslots.zip",
		"vertxtloc"=>"http://www.rpdragon.com/",
		"settings"=>array(
			"Super Dragon Slots,title",
			"cost"=>"Cost to play,int|16",
			"jackpot"=>"What is the jackpot?,int|100000",
			"basejackpot"=>"Jackpot reset to after win?,int|100000",
			"minijackpot"=>"What is the base mini jackpot?,int|5000",
			"baseminijackpot"=>"Mini-jackpot reset to after win?,int|5000",
			"dragongems"=>"How many gems won if three dragons in a row?,int|5",
		),
		
		"prefs"=>array(
			"Super Dragon Slots - Prefs,title",
			"gemswon"=>"Number of Gems Won|0",
			"goldwon"=>"Total amount of gold won or lost|0",
			"spins"=>"Total number of spins|0",	
		),
		
		"requires"=>array(
			"pqcasino"=>"1.02|`#Lonny Luberts, http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=13",
		),
	);
	return $info;
}

function superslots_install(){
	if (is_module_active('pqcasino')){
		if (!is_module_active('superslots')){
			output("Installing Super Slots Module.`n");
		}else{
			output("Updating Super Slots Module.`n");
		}
		}else{
			output("Casino Module Not Installed NOT Hooking!`n");
		}
	module_addhook("pqcasino");
	return true;
}

function superslots_uninstall(){
	output("Un-Installing Super Slots Module.`n");
	return true;
}

function superslots_dohook($hookname,$args){
	addnav(array("Super Dragon Slots (%s gold)",get_module_setting("cost")),"runmodule.php?module=superslots&op=begin");
	output("`c`&Super Dragon Slots Jackpot is at %s.`0`c",get_module_setting("jackpot"));
	return $args;
}

function superslots_run(){
	global $session;
	$op = httpget("op");
	$dragongems = get_module_setting("dragongems");
	$minijackpot = get_module_setting("minijackpot");
	$jackpot = get_module_setting("jackpot");
	$basejackpot = get_module_setting("basejackpot");
	$baseminijackpot = get_module_setting("baseminijackpot");
	$cost = get_module_setting("cost");
	$gemswon = get_module_pref("gemswon");
	$goldwon = get_module_pref("goldwon");
	$spins = get_module_pref("spins");
	page_header("Super Dragon Slots");
	rawoutput("<center>");

//Resets
	
	if ($op=="resetgold"){
		$goldwon=0;
	}
	
	if ($op=="resetgems"){
		$gemswon=0;
	}
	
	if ($op=="resetspins"){
		$spins=0;
	}
	
	if ($op=="resetall"){
		$goldwon=0;
		$gemswon=0;
		$spins=0;
	}	


//Begin

	if ($op=="begin"){
		output("`n`cThe cost to play is %s gold. Please pull the lever if you would like to play.`c`n",$cost);
	}
	
	if ($op=="mybet"){
		if ($cost> $session['user']['gold']){
			output("You do not have %s gold.`n",$cost);
			addnav("Continue","runmodule.php?module=pqcasino");
		}else{
			$session['user']['gold']-=$cost;
			$op="pull";
	}
	
//Pull

	if ($op=="pull"){
		$spins++;
		$dragonx=0;
		$goldwon-=$cost;
		$s1 = e_rand(1,10000);
		$s2 = e_rand(1,10000);
		$s3 = e_rand(1,10000);
		$s4 = e_rand(1,10000);
		$s5 = e_rand(1,10000);
		$s6 = e_rand(1,10000);
		$s7 = e_rand(1,10000);
		$s8 = e_rand(1,10000);
		$s9 = e_rand(1,10000);

//Create slot tiles

	//Slot Tile 1
	
		if ($s1>0){
			$sx1=1;}
		if ($s1>4359){
			$sx1=2;}
		if ($s1>5553){
			$sx1=3;}
		if ($s1>6583){
			$sx1=4;}
		if ($s1>7446){
			$sx1=5;}
		if ($s1>8309){
			$sx1=6;}
		if ($s1>9000){
			$sx1=7;}
		if ($s1>9535){
			$sx1=8;}
		if ($s1>9805){
			$sx1=9;}
		if ($s1>9941){
			$sx1=10;}

	//Slot Tile 2

		if ($s2>0){
			$sx2=1;}
		if ($s2>5769){
			$sx2=2;}
		if ($s2>6632){
			$sx2=3;}
		if ($s2>7168){
			$sx2=4;}
		if ($s2>7704){
			$sx2=5;}
		if ($s2>8217){
			$sx2=6;}
		if ($s2>8730){
			$sx2=7;}
		if ($s2>9132){
			$sx2=8;}
		if ($s2>9653){
			$sx2=9;}
		if ($s2>9913){
			$sx2=10;}

	//Slot Tile 3

		if ($s3>0){
			$sx3=1;}
		if ($s3>6551){
			$sx3=2;}
		if ($s3>7414){
			$sx3=3;}
		if ($s3>8277){
			$sx3=4;}
		if ($s3>8812){
			$sx3=5;}
		if ($s3>9214){
			$sx3=6;}
		if ($s3>9482){
			$sx3=7;}
		if ($s3>9616){
			$sx3=8;}
		if ($s3>9865){
			$sx3=9;}
		if ($s3>9972){
			$sx3=10;}

	//Slot Tile 4

		if ($s4>0){
			$sx4=1;}
		if ($s4>4359){
			$sx4=2;}
		if ($s4>5553){
			$sx4=3;}
		if ($s4>6583){
			$sx4=4;}
		if ($s4>7446){
			$sx4=5;}
		if ($s4>8309){
			$sx4=6;}
		if ($s4>9000){
			$sx4=7;}
		if ($s4>9535){
			$sx4=8;}
		if ($s4>9805){
			$sx4=9;}
		if ($s4>9941){
			$sx4=10;}

	//Slot Tile 5

		if ($s5>0){
			$sx5=1;}
		if ($s5>5769){
			$sx5=2;}
		if ($s5>6632){
			$sx5=3;}
		if ($s5>47168){
			$sx5=4;}
		if ($s5>7704){
			$sx5=5;}
		if ($s5>8217){
			$sx5=6;}
		if ($s5>8730){
			$sx5=7;}
		if ($s5>9132){
			$sx5=8;}
		if ($s5>9653){
			$sx5=9;}
		if ($s5>9913){
			$sx5=10;}
			
	//Slot Tile 6

		if ($s6>0){
			$sx6=1;}
		if ($s6>6551){
			$sx6=2;}
		if ($s6>7414){
			$sx6=3;}
		if ($s6>8277){
			$sx6=4;}
		if ($s6>8812){
			$sx6=5;}
		if ($s6>9214){
			$sx6=6;}
		if ($s6>9482){
			$sx6=7;}
		if ($s6>9616){
			$sx6=8;}
		if ($s6>9865){
			$sx6=9;}
		if ($s6>9972){
			$sx6=10;}

	//Slot Tile 7

		
		if ($s7>0){
			$sx7=1;}
		if ($s7>4359){
			$sx7=2;}
		if ($s7>5553){
			$sx7=3;}
		if ($s7>6583){
			$sx7=4;}
		if ($s7>7446){
			$sx7=5;}
		if ($s7>8309){
			$sx7=6;}
		if ($s7>9000){
			$sx7=7;}
		if ($s7>9535){
			$sx7=8;}
		if ($s7>9805){
			$sx7=9;}
		if ($s7>9941){
			$sx7=10;}

	//Slot Tile 8

		if ($s8>0){
			$sx8=1;}
		if ($s8>5769){
			$sx8=2;}
		if ($s8>6632){
			$sx8=3;}
		if ($s8>7168){
			$sx8=4;}
		if ($s8>7704){
			$sx8=5;}
		if ($s8>8217){
			$sx8=6;}
		if ($s8>8730){
			$sx8=7;}
		if ($s8>9132){
			$sx8=8;}
		if ($s8>9653){
			$sx8=9;}
		if ($s8>9913){
			$sx8=10;}
	//Slot Tile 9

		if ($s9>0){
			$sx9=1;}
		if ($s9>6551){
			$sx9=2;}
		if ($s9>7414){
			$sx9=3;}
		if ($s9>8277){
			$sx9=4;}
		if ($s9>8812){
			$sx9=5;}
		if ($s9>9214){
			$sx9=6;}
		if ($s9>9482){
			$sx9=7;}
		if ($s9>9616){
			$sx9=8;}
		if ($s9>9865){
			$sx9=9;}
		if ($s9>9972){
			$sx9=10;}
	
//Count Dragons

		if ($sx1==7){
			$dragonx++;}
		if ($sx2==7){
			$dragonx++;}			
		if ($sx3==7){
			$dragonx++;}		
		if ($sx4==7){
			$dragonx++;}
		if ($sx5==7){
			$dragonx++;}
		if ($sx6==7){
			$dragonx++;}
		if ($sx7==7){
			$dragonx++;}
		if ($sx8==7){
			$dragonx++;}
		if ($sx9==7){
			$dragonx++;}
			
//Winning Check

	//3 Dragons in a Row

		if ($sx1==7 && $sx2==7 && $sx3==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx4==7 && $sx5==7 && $sx6==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx7==7 && $sx8==7 && $sx9==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx1==7 && $sx4==7 && $sx7==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx2==7 && $sx5==7 && $sx8==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx3==7 && $sx6==7 && $sx9==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx1==7 && $sx5==7 && $sx9==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;
		}if ($sx7==7 && $sx5==7 && $sx3==7){
			output("Three Dragons! You win %s gems!`n`n",$dragongems);
			$session['user']['gems']+=$dragongems;
			$gemswon+=$dragongems;}

//Shields	

	//Three Shields

		if ($sx1==6 && $sx2==6 && $sx3==6){
			output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx4==6 && $sx5==6 && $sx6==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx7==6 && $sx8==6 && $sx9==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx1==6 && $sx4==6 && $sx7==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx2==6 && $sx5==6 && $sx8==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx3==6 && $sx6==6 && $sx9==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx1==6 && $sx5==6 && $sx9==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}
		if ($sx7==6 && $sx5==6 && $sx3==6){
				output("Three Shields! You win %s gold!`n`n",$cost*125);
				$session['user']['gold']+=$cost*125;
				$goldwon+=$cost*125;
		}

	//Two Shields

		if ($sx1==6 && $sx2==6 && $sx3<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
				//echo $sx2;
				//echo $sx4;
				//echo $sx5;
		}
		if ($sx4==6 && $sx5==6 && $sx6<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}
		if ($sx7==6 && $sx8==6 && $sx9<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}
		if ($sx1==6 && $sx4==6 && $sx7<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}
		if ($sx2==6 && $sx5==6 && $sx8<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}
		if ($sx3==6 && $sx6==6 && $sx9<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}
		if ($sx1==6 && $sx5==6 && $sx9<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}
		if ($sx7==6 && $sx5==6 && $sx3<>6){
				output("Two Shields! You win %s gold!`n`n",intval($cost*1.25));
				$session['user']['gold']+=intval($cost*1.25);
				$goldwon+=intval($cost*1.25);
		}

	//One Shield

		if ($sx1==6 && $sx2<>6){
				//echo $sx2;
				//echo $sx4;
				//echo $sx5;
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx4==6 && $sx5<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx7==6 && $sx8<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx1==6 && $sx4<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx2==6 && $sx5<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx3==6 && $sx6<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx1==6 && $sx5<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}
		if ($sx7==6 && $sx5<>6){
				output("One Shield! You win %s gold!`n`n",intval($cost*.25));
				$session['user']['gold']+=intval($cost*.25);
				$goldwon+=intval($cost*.25);
		}

//Jackpot

		if ($dragonx==9){
			output("JACKPOT!!! You win %s gold!",$jackpot);
			$session['user']['gold']+=$jackpot;
			$goldwon+=$jackpot;
			$jackpot=$basejackpot;

//All Blanks

		}if ($sx1==1 && $sx2==1 && $sx3==1 && $sx4==1 && $sx5==1 && $sx6==1 && $sx7==1 && $sx8==1 && $sx9==1){
			output("All Blanks! You win %s gold!",$cost*15);
			$session['user']['gold']+=$cost*15;
			$goldwon+=$cost*15;
//No Blanks

		}if ($sx1<>1 && $sx2<>1 && $sx3<>1 && $sx4<>1 && $sx5<>1 && $sx6<>1 && $sx7<>1 && $sx8<>1 && $sx9<>1){
			output("No Blanks! You win %s gold!",intval($cost*62.5));
			$session['user']['gold']+=intval($cost*62.5);
			$goldwon+=intval($cost*62.5);

//Faeries

		}if ($sx1==5 && $sx2==5 && $sx3==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx4==5 && $sx5==5 && $sx6==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx7==5 && $sx8==5 && $sx9==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx1==5 && $sx4==5 && $sx7==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx2==5 && $sx5==5 && $sx8==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx3==5 && $sx6==5 && $sx9==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx1==5 && $sx5==5 && $sx9==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;
		}if ($sx7==5 && $sx5==5 && $sx3==5){
			output("Three `%Faeries! You win %s gold!`n`n",$cost*25);
			$session['user']['gold']+=$cost*25;
			$goldwon+=$cost*25;

//Castles

		}if ($sx1==4 && $sx2==4 && $sx3==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx4==4 && $sx5==4 && $sx6==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx7==4 && $sx8==4 && $sx9==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx1==4 && $sx4==4 && $sx7==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx2==4 && $sx5==4 && $sx8==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx3==4 && $sx6==4 && $sx9==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx1==4 && $sx5==4 && $sx9==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);
		}if ($sx7==4 && $sx5==4 && $sx3==4){
			output("Three `@Castles! You win %s gold!`n`n",intval($cost*12.5));
			$session['user']['gold']+=intval($cost*12.5);
			$goldwon+=intval($cost*12.5);

//Zombies

		}if ($sx1==3 && $sx2==3 && $sx3==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);
			$goldwon+=intval($cost*6.25);
		}if ($sx4==3 && $sx5==3 && $sx6==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);	
			$goldwon+=intval($cost*6.25);
		}if ($sx7==3 && $sx8==3 && $sx9==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);
			$goldwon+=intval($cost*6.25);
		}if ($sx1==3 && $sx4==3 && $sx7==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);
			$goldwon+=intval($cost*6.25);
		}if ($sx2==3 && $sx5==3 && $sx8==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);	
			$goldwon+=intval($cost*6.25);
		}if ($sx3==3 && $sx6==3 && $sx9==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);			
			$goldwon+=intval($cost*6.25);
		}if ($sx1==3 && $sx5==3 && $sx9==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);
			$goldwon+=intval($cost*6.25);
		}if ($sx7==3 && $sx5==3 && $sx3==3){
			output("Three `6Zombies! You win %s gold!`n`n",intval($cost*6.25));
			$session['user']['gold']+=intval($cost*6.25);
			$goldwon+=intval($cost*6.25);

//Swords

		}if ($sx1==2 && $sx2==2 && $sx3==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx4==2 && $sx5==2 && $sx6==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx7==2 && $sx8==2 && $sx9==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx1==2 && $sx4==2 && $sx7==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx2==2 && $sx5==2 && $sx8==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx3==2 && $sx6==2 && $sx9==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx1==2 && $sx5==2 && $sx9==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);
		}if ($sx7==2 && $sx5==2 && $sx3==2){
			output("Three Swords! You win %s gold!`n`n",intval($cost*3.125));
			$session['user']['gold']+=intval($cost*3.125);
			$goldwon+=intval($cost*3.125);

//Blanks

		}if ($sx1==1 && $sx2==1 && $sx3==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx4==1 && $sx5==1 && $sx6==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx7==1 && $sx8==1 && $sx9==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx1==1 && $sx4==1 && $sx7==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx2==1 && $sx5==1 && $sx8==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx3==1 && $sx6==1 && $sx9==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx1==1 && $sx5==1 && $sx9==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}if ($sx7==1 && $sx5==1 && $sx3==1){
			output("Three Blanks! You win %s gold.`n`n",intval($cost/5));
			$jackpot+=intval($cost/5);
			$session['user']['gold']+=intval($cost/5);
			$goldwon+=intval($cost/5);
		}

//8 Dragons

		if ($dragonx==8){
			output("8 Dragons!!! You win %s gold!",intval($jackpot-($jackpot*.125)));
			$session['user']['gold']+=intval($jackpot*.875);
			$goldwon+=intval($jackpot-($jackpot*.125));
			$jackpot=intval($jackpot-($jackpot*.875));
		}

//7 Dragons

		if ($dragonx==7){
			output("7 Dragons!!! You win %s gold!",intval($jackpot-($jackpot*.25)));
			$session['user']['gold']+=intval($jackpot*.75);
			$goldwon+=intval($jackpot-($jackpot*.25));
			$jackpot=intval($jackpot-($jackpot*.75));
		}

//6 Dragons

		if ($dragonx==6){
			output("6 Dragons!!! You win %s gold!",intval($jackpot-($jackpot*.5)));
			$session['user']['gold']+=intval($jackpot*.5);
			$goldwon+=intval($jackpot-($jackpot*.5));
			$jackpot=intval($jackpot-($jackpot*.5));
		}

//5 Dragons

		if ($dragonx==5){			
			output("5 Dragons!!! You win %s gold!",intval($jackpot-($jackpot*.75)));
			$session['user']['gold']+=intval($jackpot*.25);
			$goldwon+=intval($jackpot-($jackpot*.75));
			$jackpot=intval($jackpot-($jackpot*.25));
		}

//4 Dragons

		if ($dragonx==4){
			output("4 Dragons!!! You win %s gold!",$cost*50);
			$session['user']['gold']+=$cost*50;
			$goldwon+=$cost*50;
		}

//3 Dragons

		if ($dragonx==3){
			output("3  Dragons!!! You win %s gold!",intval($cost*18.75));
			$session['user']['gold']+=intval($cost*18.75);
			$goldwon+=intval($cost*18.75);
		}

//2 Dragons

		if ($dragonx==2){
			output("2  Dragons!!! You win %s gold!",$cost*3);
			$session['user']['gold']+=$cost*3;
			$goldwon+=$cost*3;
		}

//3-Chests

		if ($sx1==10 && $sx2==10 && $sx3==10){
			output("Three 3-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx4==10 && $sx5==10 && $sx6==10){
			output("Three 3-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx7==10 && $sx8==10 && $sx9==10){
			output("Three 3-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx1==10 && $sx5==10 && $sx9==10){
			output("Three 3-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx7==10 && $sx5==10 && $sx3==10){
			output("Three 3-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx1==10 && $s4==10 && $sx7==10){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx2==10 && $sx5==10 && $sx8==10){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);
		}if ($sx3==10 && $sx6==10 && $sx9==10){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*312.5));
			$session['user']['gold']+=intval($cost*312.5);
			$goldwon+=intval($cost*312.5);

//2-Chests

		}if ($sx1==9 && $sx2==9 && $sx3==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$session['user']['gold']+=intval($cost*156.25);
			$goldwon+=intval($cost*156.25);
		}if ($sx4==9 && $sx5==9 && $sx6==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$session['user']['gold']+=intval($cost*156.25);
			$goldwon+=intval($cost*156.25);
		}if ($sx7==9 && $sx8==9 && $sx9==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$session['user']['gold']+=intval($cost*156.25);
			$goldwon+=intval($cost*156.25);
		}if ($sx1==9 && $sx5==9 && $sx9==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$session['user']['gold']+=intval($cost*156.25);
			$goldwon+=intval($cost*156.25);
		}if ($sx7==9 && $sx5==9 && $sx3==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$session['user']['gold']+=intval($cost*156.25);
			$goldwon+=intval($cost*156.25);
		}if ($sx1==9 && $s4==9 && $sx7==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$session['user']['gold']+=intval($cost*156.25);
			$goldwon+=intval($cost*156.25);
		}if ($sx2==9 && $sx5==9 && $sx8==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$goldwon+=intval($cost*156.25);
			$session['user']['gold']+=intval($cost*156.25);
		}if ($sx3==9 && $sx6==9 && $sx9==9){
			output("Three 2-Chests! You win %s gold!`n`n",intval($cost*156.25));
			$goldwon+=intval($cost*156.25);
			$session['user']['gold']+=intval($cost*156.25);

//1-Chests

		}if ($sx1==8 && $sx2==8 && $sx3==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);
		}if ($sx4==8 && $sx5==8 && $sx6==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);
		}if ($sx7==8 && $sx8==8 && $sx9==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);
		}if ($sx1==8 && $sx5==8 && $sx9==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);
		}if ($sx7==8 && $sx5==8 && $sx3==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
		}if ($sx1==8 && $sx4==8 && $sx7==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);
		}if ($sx2==8 && $sx5==8 && $sx8==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);
		}if ($sx3==8 && $sx6==8 && $sx9==8){
			output("Three 1-Chests! You win the mini-Jackpot, which is %s gold!`n`n",$minijackpot);
			$session['user']['gold']+=$minijackpot;
			$goldwon+=$minijackpot;
			$minijackpot=$baseminijackpot;
			addnews("%s just won the mini-jackpot in Super Dragon Slots at the Kemsley Casino", $session['user']['name']);

//Mini Jack Pot Boost	

		}if ($sx1<>8 && $sx2<>8 && $sx3<>8 && $sx4<>8 && $sx5==8 && $sx6<>8 && $sx7<>8 && $sx8<>8 && $sx9<>8){
			$minijackpot+=intval($cost/5);
			output("Mini-Jackpot increased by %s gold!`n`n",intval($cost/5));}
		if ($sx1<>9 && $sx2<>9 && $sx3<>9 && $sx4<>9 && $sx5==9 && $sx6<>9 && $sx7<>9 && $sx8<>9 && $sx9<>9){
			$minijackpot+=intval($cost/3);
			output("Mini-Jackpot increased by %s gold!`n`n",intval($cost/3));}
		if ($sx1<>10 && $sx2<>10 && $sx3<>10 && $sx4<>10 && $sx5==10 && $sx6<>10 && $sx7<>10 && $sx8<>10 && $sx9<>10){
			$minijackpot+=intval(intval($cost/2));
			output("Mini-Jackpot increased by %s gold!`n`n",intval($cost/2));}	

//Images
	
	//Slot Tile 1
	
		if ($sx1==1){
			rawoutput("<br><IMG SRC=\"images/superslots/blank.jpg\">");}
		if ($sx1==2){
			rawoutput("<br><IMG SRC=\"images/superslots/lemon.jpg\">");}
		if ($sx1==3){
			rawoutput("<br><IMG SRC=\"images/superslots/orange.jpg\">");}
		if ($sx1==4){
			rawoutput("<br><IMG SRC=\"images/superslots/watermelon.jpg\">");}
		if ($sx1==5){
			rawoutput("<br><IMG SRC=\"images/superslots/plum.jpg\">");}
		if ($sx1==6){
			rawoutput("<br><IMG SRC=\"images/superslots/cherry.jpg\">");}
		if ($sx1==7){
			rawoutput("<br><IMG SRC=\"images/superslots/bar.jpg\">");}
		if ($sx1==8){
			rawoutput("<br><IMG SRC=\"images/superslots/1bar.jpg\">");}
		if ($sx1==9){
			rawoutput("<br><IMG SRC=\"images/superslots/2bar.jpg\">");}
		if ($sx1==10){
			rawoutput("<br><IMG SRC=\"images/superslots/3bar.jpg\">");}

	//Slot Tile 2

		if ($sx2==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\">");}
		if ($sx2==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\">");}
		if ($sx2==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\">");}
		if ($sx2==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\">");}
		if ($sx2==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\">");}
		if ($sx2==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\">");}
		if ($sx2==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\">");}
		if ($sx2==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\">");}
		if ($sx2==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\">");}
		if ($sx2==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\">");}

	//Slot Tile 3

		if ($sx3==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\"><br>");}
		if ($sx3==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\"><br>");}
		if ($sx3==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\"><br>");}
		if ($sx3==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\"><br>");}
		if ($sx3==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\"><br>");}
		if ($sx3==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\"><br>");}
		if ($sx3==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\"><br>");}
		if ($sx3==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\"><br>");}
		if ($sx3==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\"><br>");}
		if ($sx3==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\"><br>");}

	//Slot Tile 4

		if ($sx4==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\">");}
		if ($sx4==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\">");}
		if ($sx4==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\">");}
		if ($sx4==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\">");}
		if ($sx4==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\">");}
		if ($sx4==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\">");}
		if ($sx4==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\">");}
		if ($sx4==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\">");}
		if ($sx4==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\">");}
		if ($sx4==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\">");}

	//Slot Tile 5

		if ($sx5==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\">");}
		if ($sx5==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\">");}
		if ($sx5==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\">");}
		if ($sx5==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\">");}
		if ($sx5==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\">");}
		if ($sx5==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\">");}
		if ($sx5==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\">");}
		if ($sx5==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\">");}
		if ($sx5==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\">");}
		if ($sx5==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\">");}			

	//Slot Tile 6

		if ($sx6==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\"><br>");}
		if ($sx6==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\"><br>");}
		if ($sx6==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\"><br>");}
		if ($sx6==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\"><br>");}
		if ($sx6==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\"><br>");}
		if ($sx6==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\"><br>");}
		if ($sx6==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\"><br>");}
		if ($sx6==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\"><br>");}
		if ($sx6==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\"><br>");}
		if ($sx6==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\"><br>");}

	//Slot Tile 7

		if ($sx7==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\">");}
		if ($sx7==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\">");}
		if ($sx7==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\">");}
		if ($sx7==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\">");}
		if ($sx7==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\">");}
		if ($sx7==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\">");}
		if ($sx7==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\">");}
		if ($sx7==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\">");}
		if ($sx7==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\">");}
		if ($sx7==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\">");}

	//Slot Tile 8

		if ($sx8==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\">");}
		if ($sx8==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\">");}
		if ($sx8==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\">");}
		if ($sx8==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\">");}
		if ($sx8==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\">");}
		if ($sx8==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\">");}
		if ($sx8==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\">");}
		if ($sx8==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\">");}
		if ($sx8==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\">");}
		if ($sx8==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\">");}

	//Slot Tile 9
		
		if ($sx9==1){
			rawoutput("<IMG SRC=\"images/superslots/blank.jpg\"><br>");}
		if ($sx9==2){
			rawoutput("<IMG SRC=\"images/superslots/lemon.jpg\"><br>");}
		if ($sx9==3){
			rawoutput("<IMG SRC=\"images/superslots/orange.jpg\"><br>");}
		if ($sx9==4){
			rawoutput("<IMG SRC=\"images/superslots/watermelon.jpg\"><br>");}
		if ($sx9==5){
			rawoutput("<IMG SRC=\"images/superslots/plum.jpg\"><br>");}
		if ($sx9==6){
			rawoutput("<IMG SRC=\"images/superslots/cherry.jpg\"><br>");}
		if ($sx9==7){
			rawoutput("<IMG SRC=\"images/superslots/bar.jpg\"><br>");}
		if ($sx9==8){
			rawoutput("<IMG SRC=\"images/superslots/1bar.jpg\"><br>");}
		if ($sx9==9){
			rawoutput("<IMG SRC=\"images/superslots/2bar.jpg\"><br>");}
		if ($sx9==10){
			rawoutput("<IMG SRC=\"images/superslots/3bar.jpg\"><br>");}
		}
	}

//Display Odds

	output("`n`b`^  Gold Won: %s  `0`b|`b`5 Gems Won: %s  `0`b|`b Spins: %s`b`n",$goldwon,$gemswon,$spins);
	output("`nAll Dragons = JACKPOT %s gold",$jackpot);
	output("`n8 Dragons = %s gold",intval($jackpot-($jackpot*.125)));
	output("`n7 Dragons = %s gold",intval($jackpot-($jackpot*.25)));
	output("`n6 Dragons = %s gold",intval($jackpot-($jackpot*.50)));
	output("`n5 Dragons = %s gold",intval($jackpot-($jackpot*.75)));
	output("`n 4 Dragons = %s gold",$cost*50);
	output("`n 3 Dragons = %s gold",intval($cost*18.75));
	output("`n 2 Dragons = %s gold",$cost*3);
	output("`nDragon - Dragon - Dragon = %s gems`n",$dragongems);
	output("`n3Chest - 3Chest - 3Chest = %s gold",intval($cost*312.5));
	output("`n2Chests - 2Chests - 2Chests = %s gold",intval($cost*156.25));
	output("`n1Chest - 1Chest - 1Chest = Mini-Jackpot %s gold`n",$minijackpot);
	output("`nNo Blanks = %s gold",intval($cost*62.5));
	output("`nAll Blanks = %s gold`n",$cost*15);
	output("`nShield - Shield - Shield = %s gold",$cost*125);
	output("`nFairy - Fairy - Fairy = %s gold",$cost*25);
	output("`nCastle - Castle - Castle = %s gold",intval($cost*12.5));
	output("`nZombie - Zombie - Zombie = %s gold",intval($cost*6.25));
	output("`nSword - Sword - Sword = %s gold",intval($cost*3.125));
	output("`nShield - Shield - Any = %s gold",intval($cost*1.25));
	output("`nShield - Any - Any = %s gold",intval($cost*.25));
	output("`nBlank - Blank - Blank = %s gold`n",intval($cost/5));

//Win Chart

	output("`nWin Chart`n");
	rawoutput("<br><IMG SRC=\"images/superslots/superslots_graph.gif\"></center>","");

//Navs

	addnav(array("Pull Lever (%s gold)",$cost),"runmodule.php?module=superslots&op=mybet");	
	addnav("Return to Casino","runmodule.php?module=pqcasino");

	addnav("Reset Stats");
	addnav("Gold Won","runmodule.php?module=superslots&op=resetgold");
	addnav("Gems Won","runmodule.php?module=superslots&op=resetgems");
	addnav("Spins","runmodule.php?module=superslots&op=resetspins");
	addnav("Reset All Stats","runmodule.php?module=superslots&op=resetall");

	addnav ("Village");
	villagenav();

//Set module settings

	set_module_setting("jackpot",$jackpot);
	set_module_setting("minijackpot",$minijackpot);
	set_module_pref("gemswon",$gemswon);
	set_module_pref("goldwon",$goldwon);
	set_module_pref("spins",$spins);

	page_footer();
}
?>