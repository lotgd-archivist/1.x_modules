Super Dragon Slots

Version 1.06
Written by RPGSL
Download: http://rpgsl.com/lotgd/superslots.zip
Mirror: http://rpdragon.com/lotgd/superslots.zip
Requires: PQCasino by Lonny Luberts Requisite Download: http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=13

Game: http://rpdragon.com/


Installation

1) Copy superslots folder into your LotGD images folder
2) Copy superslots.php into your LotGD modules folder
3) Log in to LotGD with your admin account
4) Enter the Superuser Grotto
5) Click Manage Modules
6) Install superslots.php (Super Dragon Slots)
7) Configure settings and save
8) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs