<?php
/*
Details:
 * This allows users to buy potions to see their stats, instead of having to go to the dark horse tavern
History Log:
 * Version 1.0
  o Seems Stable
*/

function notionpotion_getmoduleinfo(){
	$info = array(
		"name"=>"Notion Potions",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/notionpotion.zip",
		"settings"=>array(
			"Notion Potions - Settings,title",
			"notbuy"=>"Allow users to buy notion potions?,bool|1",
			"pCost"=>"Cost of notion potions?,int|500",
			"adminPotion"=>"Admin have unlimited access to notion potions?,bool|1",
			"(admin are those that can edit users),note",
			"fName"=>"Name of the fey?,text|Xessa",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"notPot"=>"Notion potions?,int|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
		),
	);
	return $info;
}

function notionpotion_install(){
	if (!is_module_active('notionpotion')) {
		output("`n`Q`b`cInstalling Notion Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Notion Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	return true;
}

function notionpotion_uninstall(){
	output("`n`Q`b`cUninstalling Notion Potions Module.`c`b`n");
	return true;
}

function notionpotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('notPot')>0) {
					output("`n`^You have `@%s`^ Notion Potions...`n",get_module_pref('notPot'));
				}
			}
		break;
		case "charstats":
			$potion="";
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
				set_module_pref('notPot',1);
			}
			if (get_module_pref('notPot')>0) {
				$c = translate_inline("Notion Potions cannot be used here");
				if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "forest")&&!strstr($SCRIPT_NAME, "superuser")||$session['user']['specialinc']!=""&&$session['user']['specialmisc']!="") {
					$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
					$potion .="<img src=\"./images/notionpotion/potionclear.gif\" title=\"$c\" alt=\"$c\">";
					$potion .="</div>";
				} else {
					$x = get_module_pref('notPot');
					$y = 0;
					$c = translate_inline("Drink the Notion Potion...");
					while ($x>0) {
						$y++;
						$x--;
						$potion.="<a style='border:0;' border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=notionpotion&op=use\"><img src=\"./images/notionpotion/potion.gif\" style='border:0;' title=\"$c\" alt=\"$c\"></a>";
						addnav("","runmodule.php?module=notionpotion&op=use");
						if ($y>=3) {
							$y=0;
							$potion.="\n<br/>";
						}
					}
				}
			}
			addcharstat("Click and use Items");
			if ($potion!="") addcharstat("Notion Potions", $potion);
		break;
		case "potionshop-list":
			if (get_module_setting('notbuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$not=array();
				$not['gold']=$price;
				$not['name']=translate_inline("Notion Potions");
				$not['link']="runmodule.php?module=notionpotion&op=shop";
				$not['avail']=translate_inline("In Stock");
				$not['nav']=translate_inline("Buy a `#Notion`0 Potion");
				$not['effects']=translate_inline("Gain a Notion of other users stats.");
				$args[]=$not;
			}
		break;
	}
	return $args;
}

function notionpotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			page_header("You swallow a potion..");
			$stage = httpget('stage');
			if ($stage=='') $stage=0;
			switch ($stage) {
				case "0":
					output("`@You swallow a cold, thick gloopy white potion... the ground seems to spiral away in wisps of lurid smoke...");
					output("`n`3\"`&Who summoned me? My name is.. `^%s`&. I am bound with the power of strong magiks... I would do your bidding.. whoso art thee?`3\" says %s.`n`@You name yourself, and visualize the object of your spying...",get_module_setting('fName'),get_module_setting('fName'));
				case "1":
					notionpotion_form();
				break;
				case "2":
					$ac=httpget('ac');
					$sql = "SELECT name,login,alive,location,maxhitpoints,alive,loggedin,dragonkills,gold,gems,sex,level,weapon,armor,attack,defense FROM " . db_prefix("accounts") . " WHERE acctid='$ac'";
					$result = db_query($sql);
					if (db_num_rows($result)==1){
						$row = db_fetch_assoc($result);
						output("`3\"`&I can see your target... this is what I know..`3\" %s`3 says...`n`n", get_module_setting('fName'));
						output("`@`bName:`b`# %s`n", $row['name']);
						output("`@`bLevel:`b`# %s`n", $row['level']);
						output("`@`bHitpoints:`b`# %s`n", $row['maxhitpoints']);
						output("`@`bGold:`b`# %s`n", $row['gold']);
						output("`@`bGems:`b`# %s`n", $row['gold']);
						output("`@`bWeapon:`b`# %s`n", $row['weapon']);
						output("`@`bLocation:`b`# %s`n", $row['location']);
						output("`@`bAlive:`b`# %s`n", translate_inline($row['alive']?"Yes":"No"));
						output("`@`bLogged In:`b`# %s`n", translate_inline($row['loggedin']?"Yes":"No"));
						output("`@`bAttack:`b`# %s`n", $row['attack']);
						output("`@`bDefense:`b`# %s`n", $row['defense']);
						output("`@`bDragonkills:`b`# %s`n", $row['dragonkills']);
						output("`@`bSex:`b`# %s`n`@`bSend Mail:`b`# ", translate_inline(($row['sex']?"Female":"Male")));
						$writemail = translate_inline("Write Mail");
						rawoutput("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='$writemail' border='0'></a>");
						addnav("","mail.php?op=write&to=".rawurlencode($row['login']));
						output("`n`n`@As it finishes speaking... `^%s`3 shrieks, `3\"`&Thank you! I am free! I will forever remember this boon!`3\"`0`n`n",get_module_setting('fName'));
						set_module_pref('notPot',get_module_pref('notPot')-1);
					} else {
						output("`3\"`&I cannot find that person... my magik binder is halted..`3\" %s`3 says...`n`n", get_module_setting('fName'));
						addnav("Try Again","runmodule.php?module=notionpotion&op=use&stage=1");
					}
				break;
			}
			addnav("Cleanse your mind..","village.php");
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('notPot',get_module_pref('notPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing %s gold to %s, he hands you a potion, \"`&This is a notion potion.. I explained it te yeh already..`3\"",$price,"`#CortalUX`@");
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
	}
}

function notionpotion_form() {
	global $session;
	$n = httppost("n");
	rawoutput("<form action='runmodule.php?module=notionpotion&op=use&stage=1' method='POST'>");
	addnav("","runmodule.php?module=notionpotion&op=use&stage=1");
	if ($n!="") {
		$string="%";
		for ($x=0;$x<strlen($n);$x++){
			$string .= substr($n,$x,1)."%";
		}
		$sql = "SELECT login,name,acctid FROM ".db_prefix("accounts")." WHERE name LIKE '%$string%' AND acctid<>".$session['user']['acctid']." ORDER BY level,login";
		$result = db_query($sql);
		if (db_num_rows($result)!=0) {
			output("`@The potion will disappear when you spy..");
			output("`@These users were found `^(click on a name to spy`@):`n");
			rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
			rawoutput("<tr class='trhead'><td>Name</td></tr>");
			for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=notionpotion&op=use&stage=2&ac=".$row['acctid']."'>");
			output_notl($row['name']);
			rawoutput("</td></tr>");
			addnav("","runmodule.php?module=notionpotion&op=use&stage=2&ac=".$row['acctid']);
			}
			rawoutput("</table>");
		} else {
			output("`c`@`bA user was not found with that name.`b`c");
		}
		output_notl("`n");
	}
	output("`^`b`cNotion Potions..`c`b");
	output("`nWho do you want to spy upon? (Don't worry about funny names.. you'll be asked to confirm it)");
	output("Name of user: ");
	rawoutput("<input name='n' id='n' maxlength='50' value=\"".htmlentities(stripslashes(httppost('n')))."\">");
	$apply = translate_inline("Visualize");
	rawoutput("<input type='submit' class='button' value='$apply'></form>");
	rawoutput("<script language='JavaScript'>document.getElementById('n').focus();</script>");
}
?>