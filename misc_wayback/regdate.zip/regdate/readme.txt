Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Sixf00t4 ()
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=sixf00t4

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a registration date module for LotGD
1.X.X. It allows users and admin to see their
registration date.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy 'regdate.php' within this zip into the
'modules' folder of your installation.

Login to the Superuser Grotto and Install / Activate it.