<?php
require_once("common.php");

function regdate_getmoduleinfo(){
	 $info = array(
		"name"=>"Registration Date",
		"author"=>" `#Sixf00t4`&, and `@CortalUX`&.",
		"version"=>"1.0",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/regdate.zip",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"settings"=>array(
			"Registration Date - Settings,title",
			"allowBio"=>"Allow users to see registration dates in bios?,bool|1",
			"allowAdmin"=>"Allow admin to see registration dates in bios `i(overrides the user setting for admin)`i?,bool|1",
			"(you can also look in their userprefs),note",
			"numInacc"=>"Number of inaccurate rows?,hidden|0",
		),
		"prefs"=>array(
			"Registration Date,title",
			"regdate"=>"What date did this user register upon?,viewonly|",
			"regtime"=>"When time did this user register?,viewonly|",
			"check_show"=>"Show registration dates in bios?,bool|1",
		),
	 );
	return $info;
}

function regdate_install(){
	if (!is_module_active('regdate')){
		output("`n`c`b`QRegistration Date Module - Installed`0`b`c");
		$sql = "SELECT acctid FROM `".db_prefix("accounts")."` ORDER BY acctid DESC LIMIT 1;";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		set_module_setting("numInacc",$row['acctid']);
		$sql = "SELECT count(acctid) AS c FROM `".db_prefix("accounts")."`;";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		output("`n`c`^%s `@users will never have registration times.`nIt will be active from now on. New users will have them.`c",$row['c']);
	}else{
		output("`n`c`b`QRegistration Date Module - Updated`0`b`c");
	}
	module_addhook("checkuserpref");
	module_addhook("biostat");
	module_addhook("process-create");
	module_addhook("player-login");
	return true;
}

function regdate_uninstall(){
	output("`n`c`b`QRegistration Date Module - Uninstalled`0`b`c");
	return true;
}

function regdate_dohook($hookname,$args){
	global $session;
	$date=date("d-m-Y",time());
	$time=date("H:i:s",time());
	switch ($hookname){
		case "checkuserpref":
			$args['allow']=false;
			if ($args['name']="check_show") {
				if (get_module_setting('allowBio')==1||get_module_setting("allowAdmin")==1&&$session['user']['superuser']&SU_GIVES_YOM_WARNING) {
					$args['allow']=true;
				}
			}
		break;
		case "biostat":
			if (get_module_setting("allowBio")==1||get_module_setting("allowAdmin")==1&&$session['user']['superuser']&SU_GIVES_YOM_WARNING) {
				if (get_module_pref('check_show')==1) {
					$x=get_module_setting("numInacc");
					$date=get_module_pref('regdate','regdate',$args['acctid']);
					$time=get_module_pref('regtime','regdate',$args['acctid']);
					if ($args['acctid']<=$x) {
						$date=translate_inline("Unknown");
						$time=translate_inline("Unknown");
					}
					output("`^Registration Date: `@%s`n",$date);
					output("`^Registration Time: `@%s`n",$time);
				}
			}
		break;
		case "process-create":
			global $shortname;
			$sql = "SELECT acctid FROM " . db_prefix("accounts") . " WHERE login='$shortname'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$id=$row['acctid'];
			if (get_module_pref('regdate','regdate',$id)=='') set_module_pref("regdate",$date,"regdate",$id);
			if (get_module_pref('regtime','regdate',$id)=='') set_module_pref("regtime",$time,"regdate",$id);
		break;
		case "player-login":
			if (get_module_pref('regdate','regdate')=='') set_module_pref("regdate",$date,"regdate");
			if (get_module_pref('regtime','regdate')=='') set_module_pref("regtime",$time,"regdate");
		break;
	}
	return $args;
}

function regdate_run(){
}
?>