<?php
require_once("lib/systemmail.php");
function supermessage_getmoduleinfo(){
    $info = array(
        "name"=>"Superuser Messaging",
        "author"=>"Chris Vorndran",
        "version"=>"1.1",
        "category"=>"Administrative",
        "download"=>"http://dragonprime.net/users/Sichae/supermessage.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows for Megausers or Admins to be able to send out a bulletin to all users that are on the Admin Mailing List. List is controlled by a Pref.",
        "settings"=>array(
			"Superuser Messaging Settings,title",
            "subject"=>"Subject line for Message,text|A Message from Staff, For Staff",
            "admins"=>"Do Admins have access to this function,bool|0",
        ),
		"prefs"=>array(
			"Superuser Messaging Preferences,title",
			"isuser"=>"Is this user on the mailing list,bool|0",
			"position"=>"Which position are they,enum,0,Not On,1,Moderator,2,Senior Moderator,3,Junior Admin,4,Admin,5,Senior Admin,6,Owner|0",
				)
        );
    return $info;
}
function supermessage_install(){
    module_addhook("superuser");
    return true;
}
function supermessage_uninstall(){
    return true;
}
function supermessage_dohook($hookname,$args){
    global $session;
    $admins = get_module_setting('admins');
    switch ($hookname){
        case "superuser":
        if ($admins==0){
        if ($session['user']['superuser'] & SU_MEGAUSER){
            addnav("Module Configurations");
            addnav("Message Superusers","runmodule.php?module=supermessage&op=enter");
        }
        }else{
        if ($session['user']['superuser'] & SU_EDIT_USERS){
            addnav("Module Configurations");
            addnav("Message Superusers","runmodule.php?module=supermessage&op=enter");
        }
        }
        break;
    }
    return $args;
}
function supermessage_run(){
    global $session;
    $op = httpget('op');
    $subject = get_module_setting("subject");
    $body = httppost('body');
    page_header("Superuser Messaging");
    switch ($op){
        case "enter":
			output("`3You look around the `%Office`3, and see three distinct slots.");
			output("You know that these slots are to be used for mailing messages to others.");
			addnav("Mail To");
            addnav("Message All Staff","runmodule.php?module=supermessage&op=allstaff");
            addnav("Message Moderators","runmodule.php?module=supermessage&op=moderator");
            addnav("Message Admins","runmodule.php?module=supermessage&op=admin");
			addnav("Leave");
            addnav("Return to the Grotto","superuser.php");
        break;
        case "allstaff":
        if ($body == ""){
            output("Send a message to all on the staff listing.`n`n");
			$sql = "SELECT name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON userid = acctid WHERE modulename = 'supermessage' AND setting = 'position' AND value >= '1'";
			$result = db_query($sql);
			$num = db_num_rows($result);
			for ($i; $i<$num; $i++){
				$row=db_fetch_assoc($result);
					output("%s`n",$row['name']);
			}
            rawoutput("<form action='runmodule.php?module=supermessage&op=allstaff' method='POST'>");
            output("`nMessage to All Staff:`n`n");
            rawoutput("<textarea name=\"body\" rows=\"10\" cols=\"60\" class=\"input\"></textarea>");
                rawoutput("<input type='submit' class='button' value='".translate_inline("Send")."'></form>");
            rawoutput("</form>");
            addnav("Return to the Grotto","superuser.php");
        }else{
            $sql = "SELECT userid FROM ".db_prefix("module_userprefs")." WHERE modulename='supermessage' AND setting='position' AND value>='1'";
            $result = db_query($sql);
            $row = db_fetch_assoc($result);
            systemmail($row['userid'],$subject,$body);
            output("Message has been sent.");
            addnav("Return to the Grotto","superuser.php");
        }
            addnav("","runmodule.php?module=supermessage&op=allstaff");
        break;
        case "moderator":
        if ($body == ""){
            output("This shall send a message to the Moderators and Sr Moderators.");
			output(" Which includes:`n`n");
			$sql = "SELECT name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON userid = acctid WHERE modulename = 'supermessage' AND setting = 'position' AND value <= '2'";
			$result = db_query($sql);
			$num = db_num_rows($result);
			for ($i; $i<$num; $i++){
				$row=db_fetch_assoc($result);
					output("%s`n",$row['name']);
			}
            output("`n`nThose that have been given a 2 or 1 on the staff listing.`n`n");
            rawoutput("<form action='runmodule.php?module=supermessage&op=moderator' method='POST'>");
            output("Message to Moderators:`n`n");
            rawoutput("<textarea name=\"body\" rows=\"10\" cols=\"60\" class=\"input\"></textarea>");
            rawoutput("<input type='submit' class='button' value='".translate_inline("Send")."'></form>");
            rawoutput("</form>");
            addnav("Return to the Grotto","superuser.php");
        }else{
            $sql = "SELECT userid FROM ".db_prefix("module_userprefs")." WHERE modulename='supermessage' AND setting='position' AND value<='2'";
            $result = db_query($sql);
            $row = db_fetch_assoc($result);
            systemmail($row['userid'],$subject,$body);
            output("Message has been sent.");
            addnav("Return to the Grotto","superuser.php");
        }
            addnav("","runmodule.php?module=supermessage&op=moderator");
        break;
        case "admin":
        if($body == ""){
            output("Admins are those that have been given the power to Edit Users.`n`n");
			$sql = "SELECT name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON userid = acctid WHERE modulename = 'supermessage' AND setting = 'position' AND value >= '3'";
			$result = db_query($sql);
			$num = db_num_rows($result);
			for ($i; $i<$num; $i++){
				$row=db_fetch_assoc($result);
					output("%s`n",$row['name']);
			}
            output("`n`nThey are also the ones that have been deemed 3 or higher on the staff listing.");
            rawoutput("<form action='runmodule.php?module=supermessage&op=admin' method='POST'>");
            output("Message to Admins:`n`n");
            rawoutput("<textarea name=\"body\" rows=\"10\" cols=\"60\" class=\"input\"></textarea>");
                rawoutput("<input type='submit' class='button' value='".translate_inline("Send")."'></form>");
            rawoutput("</form>");
            addnav("Return to the Grotto","superuser.php");
        }else{
            $sql = "SELECT userid FROM ".db_prefix("module_userprefs")." WHERE modulename='supermessage' AND setting='position' AND value>='3'";
            $result = db_query($sql);
            $row = db_fetch_assoc($result);
            systemmail($row['userid'],$subject,$body);
            output("Message has been sent.");
            addnav("Return to the Grotto","superuser.php");
        }
            addnav("","runmodule.php?module=supermessage&op=admin");
        break;            
    }
page_footer();
}
?> 