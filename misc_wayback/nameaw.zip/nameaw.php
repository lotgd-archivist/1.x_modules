<?php
// nameaw.php mod to allow renaming of weapon/armor for ref points
// version 1.2 by Lord Wolfen �Copyright 2004-2005 J F LEIGH
// nameaw.php is taken from Wolf Den (den.php) module as on www.fleigh.net
//
// You must name this file: nameaw.php
// TO DO LIST
// 1. Add more options to rename things
// 2. Make Translator Ready
// Change Log
// Updated to 1.1 for new prerelease
// 09-19-2004 Version 1.0 created and released.
// taken from den.php and altered to work with the now available lodge mod.
// for use with 0.9.8-prerelease.7

function nameaw_getmoduleinfo(){
$info = array(
"name"=>"Name Armor or Weapon",
"version"=>"1.2",
"author"=>"Lord Wolfen, (J F LEIGH) ",
"category"=>"Lodge",
"download"=>"http://dragonprime.net/users/Lord%20Wolfen/nameaw.zip",
"settings"=>array(
"Cost Settings,title",
"armcost"=>"Points to name weapon or armor,int|25",
),

);
return $info;
}
function nameaw_install(){
    module_addhook("lodge");
	module_addhook("pointsdesc");
/////module_addhook("village");
return true;
}

function nameaw_uninstall(){
return true;
}

function nameaw_dohook($hookname,$args){
global $session;
switch($hookname){

case "pointsdesc":
      $args['count']++;
      $format = $args['format'];
      $str = translate("Customize the name of your armor or weapon.");
      output($format, $str, true);
      break;

case "referral":
addnav("Rename Stuff","runmodule.php?module=nameaw");
break;
case "lodge":
addnav("Rename Stuff","runmodule.php?module=nameaw");
break;


}
return $args;
}

function nameaw_run(){
global $session;
$op = httpget('op');

page_header("Hunter's Lodge - Wolf Den");

$armcost = get_module_setting("armcost");

if ($op == ""){
output("`c<font size='+.5'>`bThe Hunters Lodge ~ `6Wolf `7Den`0`b</font>`c`n`n",true);
output("`nYou head to a room in the Hunter's Lodge with a sign reading: The `6Wolf `7Den `0`n`n");
output("The clock over the door reads `^".getgametime()."`@.");

output("`n`^So You want to name things yourself? `n");
output("`bCurrently we are offering:`b`n`n");
output("Rename Your Weapon for $armcost `n");
output("Rename Your Armor for $armcost `n`n");

output("`7The new name will stay til you slay the Dragon.`n`n");
addnav("$armcost - Rename Armor","runmodule.php?module=nameaw&op=arm");
addnav("$armcost - Rename Weapon","runmodule.php?module=nameaw&op=weap");

addnav("Other");
modulehook("lodge");

}

////////////////Begin Spend Options////////////////////////////
////////Name Armor
if ($op == "arm"){
if ($session['user']['donation']< $armcost){
 addnav("Go Back","runmodule.php?module=nameaw");
output("`n`@You dont have that many points.`n`n");
}else{
$session['user']['donation']-= $armcost;
output("`n`nAre You ready to Rename Your Armor?....`n");
output("`^ Rename your Armor!");
    output("<form action='runmodule.php?module=nameaw&op=renamea' method='POST'><input name='darmor'><input type='submit' class='button' value='submit'></form>",true);
    addnav("","runmodule.php?module=nameaw&op=renamea");
//addnav("Nevermind","runmodule.php?module=nameaw");
    }
}
if ($op == "renamea"){
    $darmor = httppost('darmor');
    $session['user']['armor'] = $darmor;
     output("`n`&Your Armors name has been changed to {$session['user']['armor']}!`n`n");
addnav("R?Return","nameaw.php");
 }
 ////////////Name Weapon
if ($op == "weap"){
if ($session['user']['donation']< $armcost){
 addnav("Go Back","runmodule.php?module=nameaw");
output("`n`@You dont have that many points.`n");
}else{
$session['user']['donation']-= $armcost;
output("`n`nDo You wish to Rename your Weapon....`n");
output("`^  Rename your weapon!");
    output("<form action='runmodule.php?module=nameaw&op=rename' method='POST'><input name='dweapon'><input type='submit' class='button' value='submit'></form>",true);
    addnav("","runmodule.php?module=nameaw&op=rename");
//addnav("Nevermind","runmodule.php?module=nameaw");
}
    }

if ($op == "rename"){
    $dweapon = httppost('dweapon');
    $session['user']['weapon'] = $dweapon;
     output("`n`7Your Weapon name has been changed to {$session['user']['weapon']}!`n`n");
addnav("Return","runmodule.php?module=nameaw");
 }


////////////////////////////
addnav("Leave");
addnav("L?Return to the Lodge","lodge.php");
require_once("lib/villagenav.php");
villagenav();

page_footer();
}
?>