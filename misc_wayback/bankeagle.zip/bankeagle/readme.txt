Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Author of the Eagle image:
Arune/Khatfield
http://dragonprime.net/index.php?action=viewfiles&user=Khatfield

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is an instant banking module for LotGD 0.9.8.
This also supports gem banking, restrictions,
dk restrictions, etc. etc.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy all 'bankeagle.php' into your modules folder.
Copy 'eagle.gif' into your images folder.

Login to the Superuser Grotto and Install / Activate it.
Uninstall / Deactivate 'instabank'.