<?php
//multi-slot capability added by Lonny Luberts
//gem slot added by Lonny Luberts
require_once("lib/villagenav.php");
function slots_getmoduleinfo(){
	$info = array(
		"name"=>"Multi Slots",
		"version"=>"1.25",
		"author"=>"RPGSL & `#Lonny Luberts & Sixfoot",
		"category"=>"RPGSL",
		"download"=>"http://rpgsl.com/lotgd/slots.zip",
		"vertxtloc"=>"http://www.rpdragon.com/",
		"settings"=>array(
			"Slots General Settings,title",
			"newdayodds"=>"Adjust Odds at newday? (overrides manual settings!),bool|0",
			"oddstimes"=>"How many times to randomize (up to this many machines are set),range,1,5,1",
			"Dragon Slots,title",
			"dragonslot"=>"Dragon Slots Active?,bool|1",
			"dragoncost"=>"Cost to play Dragon Slots,int|5",
			"dragonjackpot"=>"What is the current jackpot?,int|5000",
			"dragonbasejackpot"=>"What should the jackpot be reset to after it is won?,int|5000",
			"dragonminijackpot"=>"What is the current mini-jackpot?,int|250",
			"dragonbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|250",
			"dragonodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",
			"Gem Slots,title",
			"gemslot"=>"Gem Slots Active?,bool|1",
			"gemslotcost"=>"Cost to play Gem Slots,int|10",
			"gemslotjackpot"=>"What is the current jackpot?,int|10000",
			"gemslotbasejackpot"=>"What should the jackpot be reset to after it is won?,int|10000",
			"gemslotminijackpot"=>"What is the current mini-jackpot?,int|500",
			"gemslotbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|500",
			"gemslotodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",
			"Death Slots,title",
			"deathslot"=>"Death Slots Active?,bool|1",
			"deathslotcost"=>"Cost to play Death Slots,int|15",
			"deathslotjackpot"=>"What is the current jackpot?,int|15000",
			"deathslotbasejackpot"=>"What should the jackpot be reset to after it is won?,int|15000",
			"deathslotminijackpot"=>"What is the current mini-jackpot?,int|750",
			"deathslotbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|750",
			"deathslotodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",
			"Fruit Slots,title",
			"fruitslot"=>"Fruit Slots Active?,bool|1",
			"fruitslotcost"=>"Cost to play Fruit Slots,int|5",
			"fruitslotjackpot"=>"What is the current jackpot?,int|5000",
			"fruitslotbasejackpot"=>"What should the jackpot be reset to after it is won?,int|5000",
			"fruitslotminijackpot"=>"What is the current mini-jackpot?,int|250",
			"fruitslotbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|250",
			"fruitslotodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",
			"Color Slots,title",
			"colorslot"=>"Color Slots Active?,bool|1",
			"colorslotcost"=>"Cost to play Color Slots,int|20",
			"colorslotjackpot"=>"What is the current jackpot?,int|20000",
			"colorslotbasejackpot"=>"What should the jackpot be reset to after it is won?,int|20000",
			"colorslotminijackpot"=>"What is the current mini-jackpot?,int|1000",
			"colorslotbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|1000",
			"colorslotodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",
			"LOTGD Slots,title",
			"lotgdslot"=>"LOTGD Slots Active?,bool|1",
			"lotgdslotcost"=>"Cost to play LOTGD Slots,int|25",
			"lotgdslotjackpot"=>"What is the current jackpot?,int|25000",
			"lotgdslotbasejackpot"=>"What should the jackpot be reset to after it is won?,int|25000",
			"lotgdslotminijackpot"=>"What is the current mini-jackpot?,int|1250",
			"lotgdslotbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|1250",
			"lotgdslotodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",
			"Number Slots,title",
			"numberslot"=>"Number Slots Active?,bool|1",
			"numberslotcost"=>"Cost to play Number Slots,int|5",
			"numberslotjackpot"=>"What is the current jackpot?,int|5000",
			"numberslotbasejackpot"=>"What should the jackpot be reset to after it is won?,int|5000",
			"numberslotminijackpot"=>"What is the current mini-jackpot?,int|250",
			"numberslotbaseminijackpot"=>"What should the mini-jackpot be reset to after it is won?,int|250",
			"numberslotodds"=>"What are the chances of winning?,enum,2,Normal,0,Best,1,Better,3,Poor,4,Worst",

            ),
		"requires"=>array(
			"pqcasino" => "1.02|`#Lonny Luberts, http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=13",
		),
	);
	return $info;
}

function slots_install(){
	if (is_module_active('pqcasino')){
	if (!is_module_active('slots')){
		output("Installing Slots Module.`n");
	}else{
		output("Updating Slots Module.`n");
	}
	module_addhook("pqcasino");
	module_addhook("newday-runonce");
	}else{
		output("Casino Module Not Installed NOT Hooking!`n");
	}
	return true;
}

function slots_uninstall(){
	output("Un-Installing Slots Module.`n");
	return true;
}

function slots_dohook($hookname,$args){
	if ($hookname == "newday-runonce"){
		if (get_module_setting("newdayodds") == 1){
			set_module_setting("dragonslot",2);
			set_module_setting("gemslot",2);
			set_module_setting("deathslot",2);
			set_module_setting("fruitslot",2);
			set_module_setting("colorslot",2);
			set_module_setting("lotgdslot",2);
			set_module_setting("numberslot",2);
			$slotnames = array(1=>"dragonslot",2=>"gemslot",3=>"deathslot",4=>"fruitslot",5=>"colorslot",6=>"lotgdslot",7=>"numberslot");
			$oddsname = array(0=>"Best",1=>"Better",2=>"Normal",3=>"Poor",4=>"Worst");
			for($i=1;$i<get_module_setting("oddstimes");$i++){
				$setslotodds = e_rand(1,7);
				$setoddsto = e_rand(0,4);
				set_module_setting($slotnames[$setslotodds],$setoddsto);
				debug("Set odds to ".$oddsname[$setoddsto]." for ".$slotnames[$setslotodds].".");
			}
		}
	}else{
		output("`n");
		if (get_module_setting("dragonslot") == 1){
			addnav(array("Dragon Slots (%s gold)",get_module_setting("dragoncost")),"runmodule.php?module=slots&op=begin&machine=dragon");
			output("`c`2Dragon Slots Jackpot is at %s.`c",get_module_setting("dragonjackpot"));
		}
		if (get_module_setting("gemslot") == 1){
			addnav(array("Gem Slots (%s gold)",get_module_setting("gemslotcost")),"runmodule.php?module=slots&op=begin&machine=gemslot");
			output("`c`2Gem Slots Jackpot is at %s.`c",get_module_setting("gemslotjackpot"));
		}
		if (get_module_setting("deathslot") == 1){
			addnav(array("Death Slots (%s gold)",get_module_setting("deathslotcost")),"runmodule.php?module=slots&op=begin&machine=deathslot");
			output("`c`2Death Slots Jackpot is at %s.`c",get_module_setting("deathslotjackpot"));
		}
		if (get_module_setting("fruitslot") == 1){
			addnav(array("Fruit Slots (%s gold)",get_module_setting("fruitslotcost")),"runmodule.php?module=slots&op=begin&machine=fruitslot");
			output("`c`2Fruit Slots Jackpot is at %s.`c",get_module_setting("fruitslotjackpot"));
		}
		if (get_module_setting("colorslot") == 1){
			addnav(array("Color Slots (%s gold)",get_module_setting("colorslotcost")),"runmodule.php?module=slots&op=begin&machine=colorslot");
			output("`c`2Color Slots Jackpot is at %s.`c",get_module_setting("colorslotjackpot"));
		}
		if (get_module_setting("lotgdslot") == 1){
			addnav(array("LOTGD Slots (%s gold)",get_module_setting("lotgdslotcost")),"runmodule.php?module=slots&op=begin&machine=lotgdslot");
			output("`c`2LOTGD Slots Jackpot is at %s.`c",get_module_setting("lotgdslotjackpot"));
		}
		if (get_module_setting("numberslot") == 1){
			addnav(array("Number Slots (%s gold)",get_module_setting("numberslotcost")),"runmodule.php?module=slots&op=begin&machine=numberslot");
			output("`c`2Number Slots Jackpot is at %s.`c",get_module_setting("numberslotjackpot"));
		}
		output("`n");
	}
	return $args;
}

function slots_run(){
	global $session;
	$op = httpget("op");
	$machine = httpget("machine");
	$basemini = $machine."baseminijackpot";
	$baseminijackpot = get_module_setting($basemini);
	$basejack = $machine."basejackpot";
	$basejackpot = get_module_setting($basejack);
	$mini = $machine."minijackpot";
	$minijackpot = get_module_setting($mini);
	$jack = $machine."jackpot";
	$jackpot = get_module_setting($jack);
	$machinecost = $machine."cost";
	$cost = get_module_setting($machinecost);	
	if ($machine == "dragon"  or $machine == ""){
		$slots = array("machine"=>"Dragon Slots","name6"=>"Shields","tile6"=>"cherry.jpg","name7"=>"Dragons","tile7"=>"bar.jpg","name5"=>"Faeries","tile5"=>"plum.jpg","name4"=>"Castles","tile4"=>"watermelon.jpg","name3"=>"Zombies","tile3"=>"orange.jpg","name2"=>"Swords","tile2"=>"lemon.jpg","name1"=>"Blanks","tile1"=>"blank.jpg");
	}elseif ($machine == "gemslot"){
		$slots = array("machine"=>"Gem Slots","name7"=>"Diamonds","tile7"=>"slotdiamond.jpg","name6"=>"Rubys","tile6"=>"slotruby.jpg","name5"=>"Sapphires","tile5"=>"slotsapphire.jpg","name4"=>"Emeralds","tile4"=>"slotemerald.jpg","name3"=>"Aquamarine","tile3"=>"slotaquamarine.jpg","name2"=>"Amethyst","tile2"=>"slotamethyst.jpg","name1"=>"Perdiot","tile1"=>"slotperdiot.jpg");
	}elseif ($machine == "deathslot"){
		$slots = array("machine"=>"Death Slots","name7"=>"Skull","tile7"=>"deathslot7.jpg","name6"=>"Slimy Face","tile6"=>"deathslot6.jpg","name5"=>"Reaper","tile5"=>"deathslot5.jpg","name4"=>"Grim","tile4"=>"deathslot4.jpg","name3"=>"Undead","tile3"=>"deathslot3.jpg","name2"=>"Crypt Keeper","tile2"=>"deathslot2.jpg","name1"=>"Headstone","tile1"=>"deathslot1.jpg");
	}elseif ($machine == "fruitslot"){
		$slots = array("machine"=>"Fruit Slots","name7"=>"Bar","tile7"=>"fruitslot7.jpg","name6"=>"Watermellon","tile6"=>"fruitslot6.jpg","name5"=>"Plum","tile5"=>"fruitslot5.jpg","name4"=>"Orange","tile4"=>"fruitslot4.jpg","name3"=>"Lemon","tile3"=>"fruitslot3.jpg","name2"=>"Cherry","tile2"=>"fruitslot2.jpg","name1"=>"Blank","tile1"=>"fruitslot1.jpg");
	}elseif ($machine == "colorslot"){
		$slots = array("machine"=>"Color Slots","name7"=>"Blue","tile7"=>"colorslot7.jpg","name6"=>"Red","tile6"=>"colorslot6.jpg","name5"=>"Pink","tile5"=>"colorslot5.jpg","name4"=>"Green","tile4"=>"colorslot4.jpg","name3"=>"Orange","tile3"=>"colorslot3.jpg","name2"=>"Yellow","tile2"=>"colorslot2.jpg","name1"=>"Blank","tile1"=>"colorslot1.jpg");
	}elseif ($machine == "lotgdslot"){
		$slots = array("machine"=>"LOTGD Slots","name7"=>"Grey Dragon","tile7"=>"lotgdslot7.jpg","name6"=>"Green Medallion","tile6"=>"lotgdslot6.jpg","name5"=>"Red Medallion","tile5"=>"lotgdslot5.jpg","name4"=>"Yellow Medallion","tile4"=>"lotgdslot4.jpg","name3"=>"Sword and Shield","tile3"=>"lotgdslot3.jpg","name2"=>"Dragon Claw","tile2"=>"lotgdslot2.jpg","name1"=>"Blank","tile1"=>"lotgdslot1.jpg");
	}elseif ($machine == "numberslot"){
		$slots = array("machine"=>"Number Slots","name7"=>"Seven","tile7"=>"numberslot7.jpg","name6"=>"One","tile6"=>"numberslot6.jpg","name5"=>"Five","tile5"=>"numberslot5.jpg","name4"=>"Four","tile4"=>"numberslot4.jpg","name3"=>"Three","tile3"=>"numberslot3.jpg","name2"=>"Two","tile2"=>"numberslot2.jpg","name1"=>"Zero","tile1"=>"numberslot1.jpg");
	}    
	page_header($slots['machine']);
	if ($op == "begin"){
		output("`c`b%s`c",$slots['machine']);
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile1']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `n",$slots['name1']); 
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile2']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `n",$slots['name2']);
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile3']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `n",$slots['name3']);
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile4']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `n",$slots['name4']);
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile5']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `n",$slots['name5']);
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile6']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `n",$slots['name6']);
		rawoutput("<IMG SRC=\"images/slots/".$slots['tile7']."\" align=\"absmiddle\" style=\"width: 81px; height: 81px;\">");
		output("`2 %s `b`n`n",$slots['name7']);
	}
	if ($op <> "begin"){
		output("`n`cThe cost to play is %s gold. Please pull the lever if you would like to play.`c`n",$cost);
		$op = "mybet";
	}

	if ($op=="mybet"){
		if ($cost> $session['user']['gold']){
			output("You do not have %s gold.`n",$cost);
		}else{
			$op="pull";
			$session['user']['gold']-=$cost;
		}

	if ($op=="pull"){
		$s1 = e_rand(1,64);
		$s2 = e_rand(1,64);
		$s3 = e_rand(1,64);
		//adjust the odds
		$currslotodd = $machine."odds";
		$slotodds = get_module_setting($curslotodd);
		$odds1 = ($slotodds + 26);
		$odds2 = ($slotodds + 34);
		$odds3 = ($slotodds + 41);
		$odds4 = ($slotodds + 47);
		$odds5 = ($slotodds + 53);
		$odds6 = ($slotodds + 58);
		
		if ($s1>0){
			$sx1=1;}
		if ($s1>$odds1){
			$sx1=2;}
		if ($s1>$odds2){
			$sx1=3;}
		if ($s1>$odds3){
			$sx1=4;}
		if ($s1>$odds4){
			$sx1=5;}
		if ($s1>$odds5){
			$sx1=6;}
		if ($s1>$odds6){
			$sx1=7;
		}

		if ($s2>0){
			$sx2=1;}
		if ($s2>($odds1 + 9)){
			$sx2=2;}
		if ($s2>($odds2 + 7)){
			$sx2=3;}
		if ($s2>($odds3 + 5)){
			$sx2=4;}
		if ($s2>($odds4 + 4)){
			$sx2=5;}
		if ($s2>($odds5 + 2)){
			$sx2=6;}
		if ($s2>($odds6 + 1)){
			$sx2=7;
		}

		if ($s3>0){
			$sx3=1;}
		if ($s3>($odds1 + 14)){
			$sx3=2;}
		if ($s3>($odds2 + 12)){
			$sx3=3;}
		if ($s3>($odds3 + 11)){
			$sx3=4;}
		if ($s3>($odds4 + 9)){
			$sx3=5;}
		if ($s3>($odds5 + 6)){
			$sx3=6;}
		if ($s3>($odds6 + 3)){
			$sx3=7;
		}

			//Images
			rawoutput("<center><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"400\"><tr><td WIDTH=\"400\" HEIGHT=\"150\" align=\"center\" background=\"images/slots/slotbackg.jpg\">");
			if ($sx1==1){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile1']."\">");}
			if ($sx1==2){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile2']."\">");}
			if ($sx1==3){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile3']."\">");}
			if ($sx1==4){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile4']."\">");}
			if ($sx1==5){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile5']."\">");}
			if ($sx1==6){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile6']."\">");}
			if ($sx1==7){
				rawoutput("<center><IMG SRC=\"images/slots/".$slots['tile7']."\">");}

			if ($sx2==1){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile1']."\">");}
			if ($sx2==2){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile2']."\">");}
			if ($sx2==3){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile3']."\">");}
			if ($sx2==4){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile4']."\">");}
			if ($sx2==5){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile5']."\">");}
			if ($sx2==6){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile6']."\">");}
			if ($sx2==7){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile7']."\">");}
				
			if ($sx3==1){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile1']."\"></center>");}
			if ($sx3==2){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile2']."\"></center>");}
			if ($sx3==3){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile3']."\"></center>");}
			if ($sx3==4){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile4']."\"></center>");}
			if ($sx3==5){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile5']."\"></center>");}
			if ($sx3==6){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile6']."\"></center>");}
			if ($sx3==7){
				rawoutput("<IMG SRC=\"images/slots/".$slots['tile7']."\"></center>");}
	rawoutput("</td></tr></table></center>");
	$slottext1 = "name".$sx1;
	$slottext2 = "name".$sx2;
	$slottext3 = "name".$sx3;
	output("`c`2".$slots[$slottext1]." | ".$slots[$slottext2]." | ".$slots[$slottext3]."`c`0`n");
	//Winning Check
		output("`b`2");
		//Tile 6	
		if ($sx1==6 && $sx2==6 && $sx3==6){
				output("`cThree %s! You win %s gold!`c`n`n",$slots['name6'],$cost*1000);
				$session['user']['gold']+=$cost*1000;
		}
		
		if ($sx1==6 && $sx2==6 && $sx3<>6){
				output("`cTwo %s! You win %s gold!`c`n`n",$slots['name6'],$cost*10);
				$session['user']['gold']+=$cost*10;
		}
		
		if ($sx1==6 && $sx2<>6 && $sx3==6){
				output("`cTwo %s! You win %s gold!`c`n`n",$slots['name6'],$cost*10);
				$session['user']['gold']+=$cost*10;
		}
		
		if ($sx1<>6 && $sx2==6 && $sx3==6){
				output("`cTwo %s! You win %s gold!`c`n`n",$slots['name6'],$cost*10);
				$session['user']['gold']+=$cost*10;
		}
		
		if ($sx1==6 && $sx2<>6 && $sx3<>6){
				output("`cOne %s! You win %s gold!`c`n`n",$slots['name6'],intval($cost*1.5));

				$session['user']['gold']+=intval($cost*1.5);
		}
		
		if ($sx1<>6 && $sx2==6 && $sx3<>6){
				output("`cOne %s! You win %s gold!`c`n`n",$slots['name6'],intval($cost*1.5));
				$session['user']['gold']+=intval($cost*1.5);
		}

		if ($sx1<>6 && $sx2<>6 && $sx3==6){
				output("`cOne %s! You win %s gold!`c`n`n",$slots['name6'],intval($cost*1.5));
				$session['user']['gold']+=intval($cost*1.5);

		//Tile 7
		}if ($sx1==7 && $sx2==7 && $sx3==7){
			output("`c`4JACKPOT!!! You win %s gold!",$jackpot);
			$session['user']['gold']+=$jackpot;
			set_module_setting("jackpot",$basejackpot);
			$wintext = translate_inline(" wins the Jackpot playing "); 
			addnews($session['user']['name'].$wintext.$slots['machine'].".");
		//Tile 5
		}if ($sx1==5 && $sx2==5 && $sx3==5){
			output("`cThree %s! You win %s gold!`c`n`n",$slots['name5'],$cost*200);
			$session['user']['gold']+=$cost*200;

		//Tile 4
		}if ($sx1==4 && $sx2==4 && $sx3==4){
			output("`cThree %s! You win %s gold!`c`n`n",$slots['name4'],$cost*100);
			$session['user']['gold']+=$cost*100;

		//Tile 3
		}if ($sx1==3 && $sx2==3 && $sx3==3){
			output("`cThree %s! You win %s gold!`c`n`n",$slots['name3'],$cost*50);
			$session['user']['gold']+=$cost*50;

		//Tile 2
		}if ($sx1==2 && $sx2==2 && $sx3==2){
			output("`cThree %s! You win %s gold!`c`n`n",$slots['name2'],$cost*25);
			$session['user']['gold']+=$cost*25;

		//Tile 1
		}if ($sx1==1 && $sx2==1 && $sx3==1){
			output("`cThree %s! You win %s gold! Jackpot increased by %s & Mini-Jackpot increased by %s gold.`c`n`n",$slots['name1'],intval($cost/2),intval($cost/2),intval($cost/3));
			$minijackpot+=intval($cost/3);
			$jackpot+=intval($cost/2);
			$session['user']['gold']+=intval($cost/2);

		//Two Tile 7
		}if ($sx1==7 && $sx2==7 && $sx3<>7){
			output("`c`4Two %s! You win the mini jackpot, which is %s gold! The jackpot is increased by %s gold.`c`n",$slots['name7'],$minijackpot,$cost*5);
			$jackpot += $cost*5;
			$session['user']['gold']+=$minijackpot;
			$minijackpot = $baseminijackpot;
			$wintext = translate_inline(" wins the Mini-Jackpot playing "); 
			addnews($session['user']['name'].$wintext.$slots['machine'].".");
		}if ($sx1==7 && $sx2<>7 && $sx3==7){
			output("`c`4Two %s! You win the mini jackpot, which is %s gold! The Jackpot is increased by %s gold.`c`n",$slots['name7'],$minijackpot,$cost*5);
			$jackpot += $cost*5;
			$session['user']['gold']+=$minijackpot;
			$minijackpot = $baseminijackpot;
			$wintext = translate_inline(" wins the Mini-Jackpot playing "); 
			addnews($session['user']['name'].$wintext.$slots['machine'].".");
		}if ($sx1<>7 && $sx2==7 && $sx3==7){
			output("`c`4Two %s! You win the mini jackpot, which is %s gold! The Jackpot is increased by %s gold.`c`n",$slots['name7'],$minijackpot,$cost*5);
			$jackpot += $cost*5;
			$session['user']['gold']+=$minijackpot;
			$minijackpot = $baseminijackpot;
			$wintext = translate_inline(" wins the Mini-Jackpot playing "); 
			addnews($session['user']['name'].$wintext.$slots['machine'].".");
		}
		output("`b`0");		
	}
}
	output("`n3 %s = JACKPOT %s gold",$slots['name7'],$jackpot);
	output("`n2 %s = mini-JACKPOT %s gold",$slots['name7'],$minijackpot);
	output("`n3 %s = %s gold",$slots['name6'],$cost * 1000);
	output("`n2 %s = %s gold",$slots['name6'],$cost * 10);
	output("`n1 %s = %s gold",$slots['name6'],intval($cost * 1.5));
	output("`n3 %s = %s gold",$slots['name5'],$cost * 200);
	output("`n3 %s = %s gold",$slots['name4'],$cost * 100);
	output("`n3 %s = %s gold",$slots['name3'],$cost * 50);
	output("`n3 %s = %s gold",$slots['name2'],$cost * 25);
	output("`n3 %s = %s gold",$slots['name1'],intval($cost/2));
	addnav("Pull Lever","runmodule.php?module=slots&machine=$machine&op=mybet");	
	addnav("Return to Casino","runmodule.php?module=pqcasino");
	villagenav();
	set_module_setting($jack,$jackpot);
	set_module_setting($mini,$minijackpot);
	$op = "";
	page_footer();
}
?>