Dragon Slots

Version 1.25
Written by RPGSL
Download: http://rpgsl.com/lotgd/slots.rar
Requires: PQCasino by Lonny Luberts Requisite Download: http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=13

Game: http://rpdragon.com/


Installation

1) Copy slots folder into your LotGD images folder
2) Copy slots.php into your LotGD modules folder
3) Log in to LotGD with your admin account
4) Enter the Superuser Grotto
5) Click Manage Modules
6) Install slots.php (Slots, Dragon)
7) Configure settings and save
8) Activate


Percentages

3 Bars: 4*3*1/262,144 = 0.000046 
3 Cherries: 5*4*2/262,144 = 0.000153 
3 Plums: 6*4*3/262,144 = 0.000275 
3 Watermelons: 6*5*4/262,144 = 0.000458 
3 Oranges: 7*5*6/262,144 = 0.000801 
3 Lemons: 8*6*6/262,144 = 0.001099
3 Blanks: (38*37*42/262,144 = 0.165985
2 Cherries: (5*4*62 + 5*60*2 + 59*4*2)/262,144 = 0.008820 
1 Cherry: (5*60*62 + 59*4*62 + 59*60*2)/262,144 = 0.153778

0.000046*5000 + 0.000153*1000 + 0.000275*200 + 0.000458*100 + 0.000801*50 + 0.001099*25 + .0165985/2 + 0.008820*10 + 0.153778*2 = 1.0284

Thus for every unit played the machine will return back 102.84%


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs