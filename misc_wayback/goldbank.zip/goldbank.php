<?php

function goldbank_getmoduleinfo(){
	$info = array(
		"name"=>"Displays Gold in Bank Stat",
		"version"=>"1.0",
		"author"=>"Frederic Hutow",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/Moonlight/goldbank.zip"
	);
	return $info;
}

function goldbank_install(){
	module_addhook("charstats");
    return true;
}

function goldbank_uninstall(){
	return true;
}

function goldbank_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "charstats":
		if ($session['user']['alive']) {
			$old = getcharstat("Personal Info", "Gold");
			$new = $old;
			if ($session['user']['goldinbank'] > 0) $new .= " `7(" . $session['user']['goldinbank'] . ")";
			setcharstat("Personal Info", "Gold", $new);
	}
		break;
	}
	return $args;
}

function goldbank_run(){
}
?>
