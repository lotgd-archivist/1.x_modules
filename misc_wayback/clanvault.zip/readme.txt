Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Authors of this Module:
 Damien(JV)
 CortalUX

Assistance from:
 Talisman
 Hazardy
 Spider
 Kendaer

Additions by:
 RPGSL
 Lonnyl
 Hazardy

Download the latest version of this module from:
http://dragonprime.net/users/CortalUX/clanvault.zip

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a clan vault module for LotGD 1.0.0.
Basic idea from Dasher's Guilds Clans modification.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy the clanvault.php file, and the clanvault
folder within this zip into your modules
directory.

Login to the Superuser Grotto and Install / Activate it.

----------------------------------------------
-- HISTORY: ----------------------------------
----------------------------------------------
Look at:
 http://dragonprime.net/index.php?board=17;action=display;threadid=833