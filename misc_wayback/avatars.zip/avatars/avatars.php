<?php
/*
Version developed under LotGD 0.9.8 prerelease.11
Translator ready * Addnews ready * Mail ready * HTTP Ready
This is a variant/rewrite of my 'uploadavatars' based upon Lonnyls code plus a more versatile 'avatars', based upon Anpera's code.
All of their code is copyright 2004-2005, by them.
All of my code is copyright 2004-2005 CortalUX, produced under the creative commons license.

Version 2.0:
 * A relatively stable release
Version 2.1:
 * Fixed download link
 * Fixed upload bug
Version 2.2:
 * Fixed bug in main code
Version 2.3:
 * Fixed bug in install code
Version 2.4:
 * Fixed bug in main code
Version 2.5:
 * Fixed bug in main code
Version 2.6:
 * Fixed bug in preference code
++--+ NOTE +--++++--+ NOTE +--++++--+ NOTE +--++++--+ NOTE +--++++--+ NOTE +--++++--+ NOTE +--++++--+ NOTE +--++
I would like to thank Anpera, Dannic, Lonnyl, and Sichae (In alphabetical order).
*/
require_once("common.php");
require_once("lib/villagenav.php");
require_once("lib/http.php");

function avatars_getmoduleinfo(){
	$info = array(
		"name"=>"Avatars",
		"version"=>"2.6",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"author"=>"`^CortalUX`@- Based upon code by `#Lonnyl`@ and `#Anpera`@.",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/avatars.zip",
		"override_forced_nav"=>true,
		"settings"=>array(
			"General,title",
			"maxwidth"=>"Max. width of Avatars (Pixel),range,20,400,20|200",
			"maxheight"=>"Max. height of Avatars (Pixel),range,20,400,20|200",
			"resize"=>"Avatar Resizing Method,enum,0,CSS/HTML,1,(PHP) Gd2,3,Turned Off",
			"uploads"=>"Are Avatar uploads enabled?,bool|1",
			"nonuploaded"=>"Can Avatars be set that have not been uploaded?,bool|1",
			"suApprove"=>"Can superusers (of any kind) upload/set avatars without them having to be approved?,bool|0",
			"picApprove"=>"Do avatars have to be approved?,bool|0",
			"Uploads,title",
			"maxSize"=>"What is the maximum file size?,enum,1000,1k,5000,5k,10000,10k,20000,20k,30000,30k,40000,40k,50000,50k,60000,60k,70000,70k,80000,80k,90000,90k",
			"pngType"=>"Can PNGs be uploaded?,bool|1",
			"(not all browsers support them),note",
			"cost"=>"Do users have to pay?,int|0",
			"(if this is set to 0- it's free),note",
			"ptd"=>"URL for LotGD?,|http://www.yoursite.com/lotgd",
			"ptda"=>"Path to Avatars dir?,|avatars",
			"(IE: if your lotgd was at yoursite.com/lotgd and your avatars were in yoursite.com/lotgd/avatars- Path to avatars dir would be 'avatars' and Path to lotgd would be yoursite.com/lotgd),note",
			"(the folder must exist on your server),note",
		),
		"prefs"=>array(
			"Avatar Preferences,title",
			"user_showavatar"=>"Display avatars in bios?,bool|1",
			"user_avatar"=>"URL of your avatar|",
			"sysmail"=>"Had systemmail?,bool|0",
			"hasUploaded"=>"Previous picture uploaded,viewonly|0",
			"avatarURL"=>"URL of last known approved avatar|",
			"approved"=>"Is this users avatar approved?,hidden|0",
			"banUser"=>"Is this user banned from having an avatar?,bool|0",
			"alApprove"=>"Can this user upload/set avatars without it having to be approved?,bool|0",
		),
	);
	return $info;
}

function avatars_install(){
	output("`n");
	if (!is_module_active('avatars')){
		output("`@Installing Avatars Module.`n");
	}elseif(is_module_installed('avatars','14102004')){
		output("`@Updating Avatars Module.`n`b`^Please note! This version does *not* have any German translations- yet.`b`n");
	}else{
		output("`@Updating Avatars Module.`n");
	}
	if (is_module_active('uploadavatars')) {
		output("`n`b`^Please deactivate the 'upload_avatars' module!!!`b`n`n");
	}
	if (!db_table_exists(db_prefix("avatars"))) {
		output("`&`iDB table created.`i`n");
		db_query("CREATE TABLE `".db_prefix("avatars")."` (
			`userid` int( 11 ) unsigned NOT NULL default '0'
		) TYPE = MYISAM ;");
	}
	output("`@Be sure to set your settings.`n");
	module_addhook("footer-prefs");
	module_addhook("superuser");
	module_addhook("bioinfo");
	module_addhook("faq-toc");
	module_addhook("delete_character");
	return true;
}

function avatars_uninstall(){
	if (db_table_exists(db_prefix("avatars"))) {
		db_query ("DROP TABLE ".db_prefix("avatars").";");
	}
	output("`@Uninstalled the Avatars Module.`n");
	return true;
}

function avatars_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "faq-toc":
			$t = translate_inline("`@Frequently Asked Questions on Avatars`0");
			output_notl("&#149;<a href='runmodule.php?module=avatars&op=faq'>$t</a><br/>", true);
			addnav("","runmodule.php?module=avatars&op=faq");
		break;
		case "bioinfo":
			avatars_resizeshow($args);
			if (get_module_setting("nonuploaded")==0&&get_module_setting("uploads")==0) {
				set_module_setting("nonuploaded","1");
			}
		break;
		case "superuser":
			if ($session['user']['superuser'] & SU_EDIT_USERS) {
				addnav("Module Configurations");
				addnav("Avatar Tools","runmodule.php?module=avatars&op=admin&admin=true",false,true);
			}
		break;
		case "footer-prefs":
			if (get_module_pref("banUser")==0){
				if (get_module_setting("uploads")==1){
					addnav("Upload Avatar (gif)","runmodule.php?module=avatars&op=gif",false,true);
					addnav("Upload Avatar (jpg)","runmodule.php?module=avatars&op=jpg",false,true);
					if (get_module_setting("pngType")==1) {
						addnav("Upload Avatar (png)","runmodule.php?module=avatars&op=png",false,true);
					}
				}
				if (get_module_pref("hasUploaded")!=0) {
					$str = get_module_setting("ptd").get_module_setting("ptda").get_module_pref("hasUploaded");
					if (get_module_pref("hasUploaded")==0) {
						$str = "";
					}
					if (get_module_pref("user_avatar")!=$str){
						set_module_pref("approved","0");
						if (get_module_setting("nonuploaded")==0) {
							require_once("lib/systemmail.php");
							$mailmessage="Sorry, you are not allowed to set your avatar to something that has not been uploaded to this server.";
							systemmail($session['user']['acctid'],"`\$Avatar Info!",$mailmessage);
						}
					}
				}
				if (get_module_setting("picApprove")==0) {
					set_module_pref("approved","1");
					set_module_pref("avatarURL",get_module_pref("user_avatar"));
				} else {
					if (get_module_pref("user_avatar")!=get_module_pref("avatarURL")) {
						set_module_pref("approved","0");
					}
					if (get_module_pref("alApprove")==1) {
						set_module_pref("approved","1");
						set_module_pref("avatarURL",get_module_pref("user_avatar"));
					} elseif (get_module_setting("suApprove")==1&&$session['user']['superuser']) {
						set_module_pref("approved","1");
						set_module_pref("avatarURL",get_module_pref("user_avatar"));
					}
					if (get_module_pref("approved")==0&&get_module_pref('sysmail')==0&&get_module_pref("user_avatar")!="") {
						require_once("lib/systemmail.php");
						$mailmessage="Your avatar has not yet been approved. Your Bio will display your last known and approved avatar, until your avatar is approved. You will get a mail informing you of this.";
						systemmail($session['user']['acctid'],"`\$Avatar Info!",$mailmessage);
						set_module_pref('sysmail',1);
					}
					if (get_module_pref("user_avatar")==""){
						set_module_pref("avatarURL","");
						$sql = "SELECT userid FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
						$result = db_query($sql);
						if (db_num_rows($result)!=0){
							$sql = "DELETE FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
							$result = db_query($sql);
						}
					} else {
						$sql = "SELECT userid FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
						$result = db_query($sql);
						if (db_num_rows($result)==0){
							$sql = "INSERT INTO ".db_prefix("avatars")." (userid) VALUES (".$session['user']['acctid'].")";
							db_query($sql);
						}
					}
				}
			}else{
				set_module_pref('user_avatar','');
				addnav("You are banned from avatars.","");
			}
		break;
		case "delete_character":
			$sql = "DELETE FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
			db_query($sql);
		break;
	}
}

function avatars_run(){
	global $session;
	$op = httpget('op');
	switch($op){
		default:
			global $session, $_FILES;
			$max = get_module_setting("maxSize");
			$mtext = str_replace("000", "", $max)."k";
			popup_header("Upload an Avatar");
			if ($_FILES['userfile']) {
				$message = avatars_upload();
			} else {
				$message = "Avatar Upload - You may only upload ".$op." files with a ".$mtext." Maximum, and your avatar will be renamed.'";
				if (get_module_setting("cost")>0) {
					$message .= " This service does however, cost ".get_module_setting("cost")." gold.";
				}
			}
			output("`c`b`^%s`b`c`0",translate_inline($message));
			if ($session['user']['gold']>=get_module_setting("cost")) {
				$a = translate_inline("Upload");
				$b = translate_inline("Upload Image");
				rawoutput("<form name=\"upload\" id=\"upload\" action=\"runmodule.php?module=avatars&op=".httpget('op')."\" ENCTYPE=\"multipart/form-data\" method=\"post\">");
				rawoutput("$b".": <input type=\"file\" id=\"userfile\" name=\"userfile\"> <input type=\"submit\" name=\"upload\" value=\"".$a."\"></form>");
			} else {
				output("`n`$`b`i`cYou don't have enough gold to do this!`c`i`b");
			}
			popup_footer();
		break;
		case "faq":
			tlschema("faq");
			popup_header("Avatar Questions");
			$c = translate_inline("Contents");
			output_notl("`#`b`c<a href='petition.php?op=faq'>$c</a>`c`b`0",true);
			addnav("","petition.php?op=faq");
			output("`n`n`c`&`bQuestions about Avatars`b`c`n");
			output("`^1. What are Avatars, anyway?`n");
			output("`@Avatars are a picture used to represent yourself.`n`n");
			output("`^2. Where can I get an Avatar?`n");
			output("`@Why not do a search, lots of people do ready-made ones.`nNo, we won't make one for you. However, if someone offers to make you one, by all means accept.`n`n");
			output("`^3. Can I upload an Avatar?`n");
			if (get_module_setting("uploads")==1) {
				output("`@Of course! There is a size limit of `^%sk`@, and the file will be renamed automatically- if you link to an outside Avatar URL, your Avatar will, however, get deleted.`n`n",str_replace("000", "", get_module_setting("maxSize")));
			} else {
				output("`@Not at the present time.`n`n");
			}
			output("`^4. What are the restrictions?`n`@");
			if (get_module_setting("picApprove")==1) {
				output("All pictures must be approved by an admin.`n");
			}
			if (get_module_setting("pngType")==0) {
				output("PNG files cannot be uploaded, as not all browsers a compatible with them.`n");
			}
			output("The maximum width of a picture is `^%s`@, with a height restriction of `^%s`@. This is measured in pixels.`n`n",get_module_setting("maxwidth"),get_module_setting("maxheight"));
			output("`^5. Do I have to pay?`n");
			if (get_module_setting("cost")==0) {
				output("`@Of course not!`n`n");
			} else {
				output("`@There is a cost of `^%s`@ gold, each time you change your avatar.`n`n",get_module_setting("cost"));
			}
			popup_footer();
		break;
		case "admin":
			require_once("lib/systemmail.php");
			popup_header("Avatar Tools");
			if (httpget('ty')=="delete") {
				if (get_module_pref("hasUploaded",'avatars',httpget('user'))!=0) {
					$upload_dir = get_module_setting("ptda")."/";
					unlink($upload_dir.get_module_pref("hasUploaded",'avatars',httpget('user')));
					set_module_pref('hasUploaded','0','avatars',httpget('user'));
				}
				set_module_pref('user_avatar','','avatars',httpget('user'));
				output("That users picture has been deleted from the server and their URL, reset. Banning from uploading an avatar must be done seperately.");
				$mailmessage="Your Avatar has been deleted, if you wish to discuss it, use the Petition link.";
				systemmail($user,"`\$Avatar Info!",$mailmessage);
			 	avatars_form("Search Again:");
			}elseif(httpget('ty')=="rej") {
				if (get_module_pref('hasUploaded')!=0) {
					$upload_dir = get_module_setting("ptda")."/";
					unlink($upload_dir.get_module_pref("hasUploaded",'avatars',httpget('user')));
				}
				set_module_pref('hasUploaded','0','avatars',httpget('user'));
				set_module_pref('approved','0','avatars',httpget('user'));
				set_module_pref('user_avatar','0','avatars',httpget('user'));
				output("That user has had their avatar rejected.");
				$mailmessage="Your Avatar has been rejected for approval.";
				systemmail($user,"`\$Avatar Info!",$mailmessage);
			 	avatars_form("Search Again:");
			}elseif(httpget('ty')=="app") {
				set_module_pref('avatarURL',get_module_pref('user_avatar','avatars',httpget('user')),'avatars',httpget('user'));
				set_module_pref('approved','1','avatars',httpget('user'));
				output("That user has had their avatar approved.");
				$mailmessage="Your Avatar has been approved.";
				systemmail($user,"`\$Avatar Info!",$mailmessage);
			 	avatars_form("Search Again:");
			}elseif(httpget('ty')=="ban") {
				if (get_module_pref('hasUploaded')!=0) {
					$upload_dir = get_module_setting("ptda")."/";
					unlink($upload_dir.get_module_pref("hasUploaded",'avatars',httpget('user')));
				}
				set_module_pref('user_avatar','','avatars',httpget('user'));
				set_module_pref('avatarURL','','avatars',httpget('user'));
				set_module_pref('hasUploaded','0','avatars',httpget('user'));
				set_module_pref('banUser','1','avatars',httpget('user'));
				set_module_pref('approved','0','avatars',httpget('user'));	
				output("That user has been banned from uploading an avatar, or setting one, and has also had their avatar URL reset.");
				$mailmessage="You have been banned from having an avatar/uploading an avatar.";
				systemmail($user,"`\$Avatar Info!",$mailmessage);
			 	avatars_form("Search Again:");
			}elseif(httpget('ty')=="unban") {
				$mailmessage="Your have been UNBANNED from having an avatar/uploading an avatar.";
				systemmail($user,"`\$Avatar Info!",$mailmessage);
				set_module_pref('banUser','0','avatars',httpget('user'));
				output("That user has been unbanned from uploading an avatar, or setting a url for one.");
				avatars_form("Search Again:");
			}elseif(httpget('ty')=="list") {
				avatars_list();
				rawoutput("<hr>");
				avatars_form("What would you like to do? Type in a name, and then chose an action at the next stage.");
			}elseif(httpget('ty')=="stage2") {
				$string="%";
				for ($x=0;$x<strlen(httppost('name'));$x++){
					$string .= substr(httppost('name'),$x,1)."%";
				}
				$sql = "SELECT name,acctid FROM ".db_prefix("accounts")." WHERE name LIKE '%".$string."%' ORDER BY acctid";
				$result = db_query($sql);
			    output("You can do things to these users:`n");
			    rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
			    rawoutput("<tr class='trhead'><td>Name</td><td>Actions</td></tr>");
			    for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
					output_notl($row['name']);
					$a = get_module_pref('banUser','avatars',$row['acctid']);
					rawoutput("</td><td>[<a href='runmodule.php?module=avatars&op=admin&ty=".($a?"unban":"ban")."&user=".$row['acctid']."'>".($a?"Unban":"Ban")."</a>]");
					$b = get_module_pref('avatarURL','avatars',$row['acctid']);
					if ($b=='') {
						rawoutput(" - [<i>Has no Avatar...</i>]");
					} else {
						rawoutput(" - [<a href='runmodule.php?module=avatars&op=admin&ty=delete&user=".$row['acctid']."'>Delete Avatar from server</a>]");
					}
					rawoutput("</td></tr>");
					addnav("","runmodule.php?module=avatars&op=admin&ty=delete&user=".$row['acctid']);
					addnav("","runmodule.php?module=avatars&op=admin&ty=".($a?"ban":"unban")."&user=".$row['acctid']);
			    }
			    if (db_num_rows($result)==0) {
				    rawoutput("<tr><td colspan='2'>");
				    output("`c`b`\$***NOTHING FOUND***`b`c`n`^`cThis goes by Name, not Login.`c");
				    rawoutput("</td></tr>");
				}
			    rawoutput("</table>");
				avatars_form("Search Again:");
			}else {
				avatars_form("What would you like to do? Type in a name, and then chose an action at the next stage.");
			}
			popup_footer();
		break;
	}
}

function avatars_form($text) {
	$h = translate_inline("Reset");
	$t = translate_inline("List Unapproved Avatars");
	output("`n`c`^`b$text`b`c`n",$text);
	rawoutput("<form action='runmodule.php?module=avatars&op=admin&ty=stage2' method='POST'>");
	rawoutput("<p><input type=\"text\" name=\"whom\" size=\"37\"></p>");
	rawoutput("<p><input type=\"submit\" value=\"Submit\"><input type=\"reset\" value=\"".$h."\"></p>");
	rawoutput("</form><br>");
	rawoutput("[<a href='runmodule.php?module=avatars&op=admin&ty=list&show=unp'>".$t."</a>]");
	addnav("","runmodule.php?module=avatars&op=admin&ty=stage2");
	addnav("","runmodule.php?module=avatars&op=admin&ty=list&show=unp");
}

function avatars_upload() {
	global $session, $_FILES;
	$max = get_module_setting("maxSize");
	$mtext = str_replace("000", "", $max)."k";
	$site_name = $_SERVER['HTTP_HOST'];
	$url_dir = get_module_setting("ptd")."/".get_module_setting("ptda");
	$url_this =  get_module_setting("ptd")."runmodule.php?module=avatars&op=".httpget('op');
	$upload_dir = get_module_setting("ptda")."/";
	$upload_url = $url_dir."/";
	$temp_name = $_FILES['userfile']['tmp_name'];
	$file_name = $_FILES['userfile']['name']; 
	$file_type = $_FILES['userfile']['type']; 
	$file_size = $_FILES['userfile']['size']; 
	$result    = $_FILES['userfile']['error'];
	$file_url  = $upload_url.$session['user']['acctid'].".".httpget('op');
	$file_path = $upload_dir.$session['user']['acctid'].".".httpget('op');
	$type = "image/".httpget('op');
	//File Name Check
	if ($file_name=="") { 
    		$message = "Invalid File Name Specified";
	    	return $message;
	    				
	} elseif ( $file_size > $max) { //File Size Check
        $message = "The file size is over ".$mtext.".";
        return $message;
	} elseif ($session['user']['gold']<get_module_setting("cost")) {
		$message = "You don't have enough gold!";
		return $message;
	} elseif ( $file_type <> $type||$file_type <> "image/jpeg"&&httpget('op')=='jpg'  ) { //File Type Check
        $message = "Sorry, You must upload a ".httpget('op');
        return $message;
	} else {
		if (get_module_pref("hasUploaded")!="0") {
			if (get_module_setting("picApprove")==1) {
					set_module_pref("avatarURL","");
					require_once("lib/systemmail.php");
					$mailmessage="Your avatar has not yet been approved. Your Bio will display your last known and approved avatar, until your avatar is approved. You will get a mail informing you of this.";
					systemmail($session['user']['acctid'],"`\$Avatar Info!",$mailmessage);
					$sql = "SELECT userid FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
						$result = db_query($sql);
					if (db_num_rows($result)==0){
						$sql = "INSERT INTO ".db_prefix("avatars")." (userid) VALUES ('".$session['user']['acctid']."')";
						$result = db_query($sql);
					}
			}
			unlink($upload_dir.get_module_pref("hasUploaded"));
			$a = " Your previous avatar has been ERASED from the server!";
		}
		$result = move_uploaded_file($temp_name, $file_path);
		$message = ($result)?"Your Avatar URL is $file_url".", and this has been set for you.":"Something went wrong, when trying to uploading your file.";
		if ($result==1) {
			if (isset($a)) {
				$message .= $a;
			}
			set_module_pref("user_avatar",$file_url,"avatars");
			set_module_pref("hasUploaded","".$session['user']['acctid'].".".httpget('op')."");
			if (get_module_setting("cost")>0) {
				$message .= " A fee of ".get_module_setting("cost")." gold has been deducted from your money on hand.";
				$session['user']['gold']-=get_module_setting("cost");
			}
		}
	}
	if (get_module_setting("picApprove")==0) {
		set_module_pref("approved","1");
		set_module_pref("avatarURL",get_module_pref("user_avatar"));
	} else {
		if (get_module_pref("user_avatar")!=get_module_pref("avatarURL")) {
			set_module_pref("approved","0");
		}
		if (get_module_pref("alApprove")==1) {
			set_module_pref("approved","1");
			set_module_pref("avatarURL",get_module_pref("user_avatar"));
		} elseif (get_module_setting("suApprove")==1&&$session['user']['superuser']) {
			set_module_pref("approved","1");
			set_module_pref("avatarURL",get_module_pref("user_avatar"));
		}
		if (get_module_pref("user_avatar")==""){
			set_module_pref("avatarURL","");
			$sql = "SELECT userid FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";	
			$result = db_query($sql);
			if (db_num_rows($result)!=0){
				$sql = "DELETE FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
				$result = db_query($sql);
			}
		} else {
			$sql = "SELECT userid FROM ".db_prefix("avatars")." WHERE userid=".$session['user']['acctid']."";
			$result = db_query($sql);
			if (db_num_rows($result)==0){
				$sql = "INSERT INTO ".db_prefix("avatars")." (userid) VALUES (".$session['user']['acctid'].")";
				$result = db_query($sql);
			}
		}
	}
	return $message;
}

function avatars_resizeshow($args) {
	if (get_module_pref("user_showavatar")==1){
		$avatar = get_module_pref("avatarURL","avatars",$args['acctid']);
		$avatar = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$avatar));
		if ($avatar>"" && strpos($avatar,".gif")<1 && strpos($avatar,".GIF")<1 && strpos($avatar,".jpg")<1&& strpos($avatar,".JPEG")<1&& strpos($avatar,".jpeg")<1 && strpos($avatar,".JPG")<1 && strpos($avatar,".png")<1 && strpos($avatar,".PNG")<1){
			require_once("lib/systemmail.php");
			set_module_pref("user_avatar","","avatars",$args['acctid']);
			$subj = array("`\$Avatar deleted!`0");
			$body = array("`QThe URL of your avatar was corrupt or was no picture and has been deleted automatically. Please check the following URL and enter a new URL in your preferences:`n`\$%s",$avatar);
			systemmail($args['acctid'],$subj,$body);
		}elseif ($avatar>""){
			$maxwidth = get_module_setting("maxwidth");
			$maxheight = get_module_setting("maxheight");
			if (get_module_setting("resize")==1) {
				$pic_size = @getimagesize($avatar); // GD2 required here - else size always is recognized as 0
				$pic_width = $pic_size[0];
				$pic_height = $pic_size[1];
				if ($pic_size[0]==0 || $pic_size[1]==0){
					// file not readable so ...
				$avatar="";
				}
			}
			rawoutput("<table><tr><td valign='top'>");
			output("`^Avatar:`0`n");
			if ($session['user']['superuser'] & SU_EDIT_USERS) {
				$ret = httpget('ret');
				$del = translate_inline("Del");
				rawoutput("[ <a target='_blank' href='runmodule.php?module=avatars&op=admin&ty=delete&user={$args['acctid']}' onClick=\"".popup("runmodule.php?module=avatars&op=admin&ty=delete&user={$args['acctid']}").";return false;\">$del</a> ]");
				addnav("","runmodule.php?module=avatars&op=admin&ty=delete&user={$args['acctid']}");
			}
			rawoutput("</td><td valign='top'>");		
			if (get_module_pref("approved","avatars",$args['acctid'])==1) {
				if (get_module_setting("resize")==0) {
					rawoutput("<div name='avatarkeepsize' style='!width:".$maxwidth.";height:".$maxheight.";overflow:scroll; !important'>");
				}
				rawoutput("<img src=\"$avatar\" ");
				if (get_module_setting("resize")==1) {
					if ($pic_width > $maxwidth) rawoutput("width=\"$maxwidth\" ");
					if ($pic_height > $maxheight) rawoutput("height=\"$maxheight\" ");
				}
				rawoutput("alt=\"".preg_replace("'[`].'","",$args['name'])."\">");
				if (get_module_setting("resize")==0) {
					rawoutput("</div>");
				}
			} else {
				output("`bThis image has not been approved.`b");	
			}
			rawoutput("</td></tr></table>");
		}
	}
}

function avatars_list() {
	if (httpget('show')=="unp") {
		output("These users have Avatars that have not been approved:`n");
	} else {
		output("These users have Avatars:`n");
	}
	$sql = "SELECT userid FROM ".db_prefix("avatars")." ORDER BY userid";
	$result = db_query($sql);
	rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
    rawoutput("<tr class='trhead'><td>Name</td><td>Actions</td></tr>");
    $n=0;
    for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$approved = get_module_pref('approved','avatars',$row['userid']);
		if ($approved==1&&httpget('show')!="unp") {
			$t = true;	
		} elseif ($approved==0&&httpget('show')=="unp") {
			$t = true;
		} elseif ($approved==0&&httpget('show')!="unp") {
			$t = true;
		} else {
			$t = false;
		}
		if ($t) {
			$n++;
			$sqli = "SELECT acctid,name FROM ".db_prefix("accounts")." WHERE acctid=".$row['userid']." AND locked=0 ORDER BY acctid";
			$resulti = db_query($sqli);
			if (db_num_rows($resulti)==1) {
				$rowi = db_fetch_assoc($resulti);
				rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
				output_notl($rowi['name']);
				$avatarURL = get_module_pref('avatarURL','avatars',$row['userid']);
				$user_avatar = get_module_pref('user_avatar','avatars',$row['userid']);
				$x = translate_inline("Approve Avatar");
				$y = translate_inline("Avatar Approved");
				if ($approved==0) {
					rawoutput("</td><td>[<a href='runmodule.php?module=avatars&op=admin&ty=app&user=".$row['userid']."'>".$x."</a>]");
				} else {
					rawoutput("</td><td>[<i>".$y."</i>]");
				}
				$a = translate_inline("View Current Avatar");
				$b = translate_inline("View Old Avatar");
				$c = translate_inline("View Pending Avatar");
				if ($approved==0) {
					if ($avatarURL!='') rawoutput(" - [<a href='".$avatarURL."' target='_BLANK'>".$b."</a>]");
					if ($user_avatar!='') rawoutput(" - [<a href='".$user_avatar."' target='_blank'>".$c."</a>]");
				} else {
					if ($avatarURL!='') rawoutput(" - [<a href='".$avatarURL."' target='_BLANK'>".$a."</a>]");
				}
				rawoutput("</td></tr>");
				addnav("","runmodule.php?module=avatars&op=admin&ty=app&user=".$row['userid']);
			}
		}
	}	
	if ($n<=0) {
	    rawoutput("<tr><td colspan='2'>");
	    output("`c`b`\$***NOTHING FOUND***`b`c`n`^`cNo one has an Avatar with that criteria.`c");
		rawoutput("</td></tr>");
	}
	rawoutput("</table>");
	$u = translate_inline("Show only Unapproved Avatars");
	$p = translate_inline("Show All Avatars");
	rawoutput("<br>[<a href='runmodule.php?module=avatars&op=admin&ty=list'>".$p."</a>] - [<a href='runmodule.php?module=avatars&op=admin&ty=list&show=unp'>".$u."</a>]");
	addnav("","runmodule.php?module=avatars&op=admin&ty=list&show=unp");
	addnav("","runmodule.php?module=avatars&op=admin&ty=list");
}
?>