Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is an avatars module for LotGD 0.9.8.
It allows users to set their own avatar and
also to upload them. You can force users to
have them moderated.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy all files within this zip into your modules
directory, except this one.
Login to the Superuser Grotto and Install it.
Set up the settings.
Login to the Superuser Grotto and Activate it.

If you want your users to be able to upload avatars:
Create a directory called 'avatars' within your LotGD
main installation folder.
If on a linux server, 'chmod 777 avatars'.
Set this up in the Grotto.