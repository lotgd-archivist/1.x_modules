<?php
require_once("lib/nltoappon.php");
function newsmotd_getmoduleinfo(){
	$info = array(
		"name"=>"MotD on News Page",
		"author"=>"Chris Vorndran",
		"version"=>"0.15",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Sichae/newsmotd.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Will display the most recent MotD on the news page.",
		"settings"=>array(
			"MotD on News Page Settings,title",
			"diout"=>"Does this display for logged in users only,bool|1",
			"link"=>"Display MotD Link after Poll Message,enum,0,No,1,Yes (Popup),2,Yes (Full Page)|1",
			),
		);
	return $info;
}
function newsmotd_install(){
	module_addhook("header-news");
	return true;
	}
function newsmotd_uninstall(){
	return true;
}
function newsmotd_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "header-news":
				$sql = "SELECT * FROM ".db_prefix("motd")." ORDER BY motditem DESC LIMIT 1";
				$res = db_query($sql);
				$row = db_fetch_assoc($res);
				$sqln = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid='".$row['motdauthor']."'";
				$resn = db_query($sqln);
				$rown = db_fetch_assoc($resn);
				$name = $rown['name'];
				if (get_module_setting("diout") == 1){
					if ($session['user']['loggedin']){
						if ($row['motdtype'] == 0){
							rawoutput("<big>");
							output("`c`%Most Recent MotD`n");
							rawoutput("</big>");
							output("`@`b%s`b`^ by %s`^, on `#%s`0.`n",$row['motdtitle'],$name,$row['motddate']);
							rawoutput("<hr>");
							output_notl("`2%s`0", nltoappon($row['motdbody']), true);
							output("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`c`n`0");
						}else{
							rawoutput("<big>");
							output("`c`%Most Recent MotD`n");
							rawoutput("</big>");
							output("`@`b%s`b`^ by %s`^, on `#%s`0.`n",$row['motdtitle'],$name,$row['motddate']);
							rawoutput("<hr>");
							output("`#The Most Recent MotD is a Poll.");
							output("You may wish to view the actual MotD, in order to better view the full results of the poll.`n");
							if (get_module_setting("link")){
								rawoutput("<a href='motd.php' target='_blank' onClick=\"".popup("motd.php").";return false;\" class='motd'><b>".translate_inline("MoTD")."</b></a>");
							}elseif (get_module_setting("link") == 2){
								rawoutput("<a href='motd.php' target='_blank'><b>".translate_inline("MoTD")."</b></a>");
							}
							output("`n`^-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`c`n`0");
						}
					}
				}else{
					if ($row['motdtype'] == 0){
						rawoutput("<big>");
						output("`c`%Most Recent MotD`n");
						rawoutput("</big>");
						output("`@`b%s`b`^ by %s`^, on `#%s`0.`n",$row['motdtitle'],$name,$row['motddate']);
						rawoutput("<hr>");
						output_notl("`2%s`0", nltoappon($row['motdbody']), true);
						output("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`c`n`0");
					}else{
						rawoutput("<big>");
						output("`c`%Most Recent MotD`n");
						rawoutput("</big>");
						output("`@`b%s`b`^ by %s`^, on `#%s`0.`n",$row['motdtitle'],$name,$row['motddate']);
						rawoutput("<hr>");
						output("`#The Most Recent MotD is a Poll.");
						output("You may wish to view the actual MotD, in order to better view the full results of the poll.`n");
						if (get_module_setting("link") == 1){
							rawoutput("<a href='motd.php' target='_blank' onClick=\"".popup("motd.php").";return false;\" class='motd'><b>".translate_inline("MoTD")."</b></a>");
						}elseif (get_module_setting("link") == 2){
							rawoutput("<a href='motd.php' target='_blank'><b>".translate_inline("MoTD")."</b></a>");
						}
						output("`n`^-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`c`n`0");
					}
				}
			break;
		}
	return $args;
}
function newsmotd_run(){
}
?>