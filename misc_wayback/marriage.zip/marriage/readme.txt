Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Additions:
Alva 

Download the latest version of this module from:
http://dragonprime.net/users/CortalUX/marriage.zip

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a marriage module for LotGD 1.0.0.
It allows your users to marry, flirt, and many
other things.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy all files within this zip into your modules
directory, except this one.

Login to the Superuser Grotto and Install / Activate it.

----------------------------------------------
-- HISTORY: ----------------------------------
----------------------------------------------
Look at:
 http://dragonprime.net/index.php?board=17;action=display;threadid=1565
