<?php
require_once("./modules/alignment/func.php");
function alignment_getmoduleinfo(){
	$info = array(
		"name"=>"Basic Alignment",
		"author"=>"WebPixie<br> `#Lonny Luberts<br>`^and Chris Vorndran",
		"version"=>"1.72",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/Sichae/alignment.zip",
		"vertxtloc">"http://dragonprime.net/users/Sichae/",
		"description"=>"This module will display the alignment of a character (Evil, Neutral, Good). Certain events in the LotGD universe will effect this alignment.",
		"settings"=>array(
			"Alignment Settings,title",
				"evilalign"=>"What number is evil alignment,range,1,100,1|33",
				"Any number under the evil number will make the user show up evil,note",
				"goodalign"=>"What number is good alignment,range,1,100,1|66",
				"Any number above the good number will make the user show up good,note",
				"Any number between evil and good number the user shows up neutral,note",
				"statbar"=>"Use Status Bar instead of text,bool|0",
			"Other Settings,title",
				"shead"=>"What Stat heading does this go under,text|Vital Info",
				"pvp"=>"Does PVP affect Alignment,bool|1",
		),
		"prefs-mounts"=>array(
			"Mount Alignment Settings,title",
			"Please note that this change happens at newday.,note",
			"norp"=>"How does this mount effect alignment?,enum,0,No Change,inc,Increase,dec,Decrease|0",
			"al"=>"How much does this mount effect alignment?,range,0,20|0",
			"0 This value to disable.,note",
		),
		"prefs"=>array(
		    "Alignment user preferences,title",
			"alignment"=>"Current alignment number,int|50",
		),
	);
	return $info;
}

function alignment_install(){
	module_addhook("biostat");
	module_addhook("charstats");
	module_addhook("newday");
	module_addhook("battle-victory");
    return true;
}

function alignment_uninstall(){
        return true;
}

function alignment_dohook($hookname,$args){
	global $session,$badguy;
	$title = translate_inline("Alignment");
	$area = get_module_setting("shead");
	$evilalign = get_module_setting('evilalign','alignment');
	$goodalign = get_module_setting('goodalign','alignment');
    switch($hookname){
		case "newday":
			$id = $session['user']['hashorse'];
			$norp = get_module_objpref("mounts",$id,"norp");
			$al = get_module_objpref("mounts",$id,"al");
			if ($al > 0){
				if ($norp == "inc"){
					$effect = get_module_pref("alignment")+$al;
				}elseif($norp == "dec"){
					$effect = get_module_pref("alignment")-$al;
				}
				set_module_pref("alignment",$effect);
			}
			break;
		case "charstats":
			if (get_module_setting('statbar')){
			 $len = 0;
			 $len2 = 0;
			 $max = 100;
			 $align = get_module_pref("alignment");
			 $alignval = get_module_pref('alignment');
			 for ($i=0;$i<$max/1;$i+=1){
				if ($alignval>$i) $len+=1;
			 }
			 $pct = round($len / $max * 100, 0);
			 $nonpct = 100-$pct;
			 if ($pct > 100) {
				$pct = 100;
				$nonpct = 0;
			 } elseif ($pct < 0) {
				$pct = 0;
				$nonpct = 100;
			 }
			 if ($align>=get_module_setting('goodalign')){
				 $color = translate_inline("`2Good");
				 $barcolor="#0C9B01";
			 }
			 elseif ($align<=get_module_setting('evilalign')){
				 $color = translate_inline("`4Evil");
				 $barcolor="#C10303";
			 }else{
				 $color = translate_inline("`6Neutral");
				 $barcolor = "#8B7603";
			 }
			 $barbgcol = "#777777";
			 $align = "";
			 $align .= "`b$color`b";
			 $align .= "<br />";
			 $align .= "<table style='border: solid 1px #000000' bgcolor='$barbgcol' cellpadding='0' cellspacing='0' width='70' height='5'><tr><td width='$pct%' bgcolor='$barcolor'></td><td width='$nonpct%'></td></tr></table>";
			 setcharstat($area,$title,$align);
		 }else{
			$useralign = get_module_pref('alignment');
			if ($useralign >= $goodalign) setcharstat($area, $title, translate_inline("`2Good"));
			if ($useralign <= $evilalign) setcharstat($area, $title, translate_inline("`4Evil"));
			if ($useralign > $evilalign and $useralign < $goodalign) setcharstat($area, $title, translate_inline("`6Neutral"));
			}
			break;
		
		case "biostat":
			$useralign = get_module_pref('alignment','alignment',$args['acctid']);
			if ($useralign >= $goodalign) output("`^Alignment: `2Good`n");
			if ($useralign <= $evilalign) output("`^Alignment: `4Evil`n");
			if ($useralign > $evilalign and $useralign < $goodalign) output("`^Alignment: `6Neutral`n");
			break;
		case "battle-victory":
			if (get_module_setting("pvp")){
				$ual = get_module_pref("alignment");
				if ($args['type'] == "pvp"){
					$al = get_module_pref("alignment","alignment",$badguy['creatureid']);
					if ($al > $goodalign && $ual < $evilalign){
						$new = $ual-round($session['user']['level']/2);
						output("`n`bYou have smote a good person, and as your are evil... it makes you more evil.`b`0");
					}elseif($al < $evilalign && $ual > $goodalign){
						$new = $ual+round($session['user']['level']/2);
						output("`n`bYou have destroyed an evil person, and as you are good... it makes you more good.`b`0");
					}else{
						switch (e_rand(1,2)){
							case 1:
								$new = $ual+round($session['user']['level']/3);
								output("`n`bYou have destroyed a person... strangely, it makes you more good.`b`0");
								break;
							case 2:
								$new = $ual-round($session['user']['level']/3);
								output("`n`bYou have destroyed a person... strangely, it makes you more evil.`b`0");
								break;
							}
						}
					set_module_pref("alignment",$new);
					output_notl("`n");
					}
				}
				break;
	}
	return $args;
}
?>