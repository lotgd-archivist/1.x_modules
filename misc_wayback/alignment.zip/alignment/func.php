<?php
function align($val){
	global $session;
	set_module_pref('alignment',(get_module_pref('alignment','alignment') + $val),'alignment');
}
function get_align($user=false){
	global $session;
	if ($user){
		$val = get_module_pref('alignment','alignment',$user);
			if ($val == "") $val = 50;
			return $val;
	}else{
			$val = get_module_pref('alignment','alignment');
			return $val;
	}
}
function set_align($val,$user=false){
	global $session;
	if ($user){
		set_module_pref('alignment',$val,'alignment',$user);
	}else{
		set_module_pref('alignment',$val,'alignment');
	}
}
/*
copy and paste code for setting alignment from other modules
make em more evil
if (is_module_active('alignment')) {
		set_module_pref('alignment',get_module_pref('alignment','alignment') - 1,'alignment');
		}
or
if (is_module_active('alignment')) {
	align("-1");
}
make em less evil
if (is_module_active('alignment')) {
		set_module_pref('alignment',get_module_pref('alignment','alignment') + 1,'alignment');
		}
or
if (is_module_active('alignment')) {
	align("1");
}
and of course change the +/- 1 to fit how evil or good the deed is....

getting alignment value
if (is_module_active('alignment')) {
	$variable = get_module_pref('alignment','alignment');
}
or
if (is_module_active('alignment')) {
	$variable = get_align();
}

getting alignment value for user other than current
if (is_module_active('alignment')) {
	$variable = get_module_pref('alignment','alignment',$userid);
}
or
if (is_module_active('alignment')) {
	$variable = get_align($userid);
}
of course setting the userid variable first or using $row['acctid'] (after a 
query of course) in place of user id.

simply setting the alignment value
if (is_module_active('alignment')) {
	set_module_pref('alignment',"50",'alignment',$userid);
}
or
if (is_module_active('alignment')) {
	set_align("50",$userid);
}
of course setting the userid variable first or using $row['acctid'] (after a 
query of course) in place of user id.
*/
?>