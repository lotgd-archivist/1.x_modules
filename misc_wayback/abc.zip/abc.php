<?php

function abc_getmoduleinfo(){
	$info = array(
		"name"=>"Aravis' Talismans",
		"author"=>"Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Village",
		"description"=>"A shoppe that sells Talismans. A Talisman will revive a character upon death.",
		"download"=>"http://dragonprime.net/users/Sichae/abc.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"Aravis' Talismans Settings,title",
				"favor"=>"How much favor does a Talisman cost?,int|100",
				"max"=>"Chance (%) that a Talisman will malfunction?,range,0,10,1|5",
				"tloss"=>"How many turns are lost upon Talisman Ressurection?,range,1,10,1|6",
				"pvp"=>"Does a Talisman ressurect a PvP-death?,bool|1",
				"abcloc"=>"Where is Aravis stationed?,location|".getsetting("villagename", LOCATION_FIELDS),
			),
		"prefs"=>array(
			"Aravis' Talismans Prefs,title",
				"has"=>"Does the user have a Talisman?,bool|0",
			),
		);
	return $info;
}
function abc_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("battle-defeat");
	return true;
}
function abc_uninstall(){
	return true;
}
function abc_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting("abcloc")){
					set_module_setting("abcloc",$args['new']);
				}
			}
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("abcloc")){
				tlschema($args['schemas']['fightnav']);
				addnav($args['fightnav']);
				tlschema();
				addnav("Aravis' Talismans","runmodule.php?module=abc&op=enter");
			}
			break;
		case "battle-defeat":
			if (get_module_pref("has")){
				if (!get_module_setting("pvp") && $args['type'] == "pvp"){
					// do nothing... :P
				}elseif(httpget('module') != "battlearena"){
					// This is to make sure that Battle Arena deaths don't take away the Talisman. :P
					blocknav("news.php");
					blocknav("shades.php");
					addnav("Continue","runmodule.php?module=abc&op=res");
				}
			}
			break;
		}
	return $args;
}
function abc_run(){
	global $session;
	$op = httpget('op');
	$favor = get_module_setting("favor");
	$mchance = get_module_setting("max");
	$g = translate_inline($session['user']['sex']==1?"miss":"mister");
	page_header("Aravis' Talismans");
	
	switch ($op){
		case "enter":
			if (!get_module_pref("has")){
				output("`)You push open the door to a small shoppe.");
				output("Entering, you notice a vast array of ornaments amongst the walls.");
				output("Seeing a shining light behind the counter, you walk over.");
				output("`n`nA young girl peeks her head over the counter, \"`%Who is it!?`)\"");
				output("You reply, \"`@This is %s.`)\"",$session['user']['name']);
				output("`n`nAll of a sudden, wings appear on either side of her and `%Aravis`) floats a bit higher, gazing into your eyes.");
				output("\"`%Oh... hello there %s`%.",$g);
				output("My name is Aravis B. Crockford, pleased to meet you... I think...`)\", `%Aravis`) smiles.");
				output("You can see her brow come to a peek and you just continue smiling.");
				output("`n`n\"`%Around here, I sell Talismans.");
				output("In times of great peril, they are said to have powerful regenerative capabilities...`)\"");
				output("`%Aravis `)comes really close to you and whispers, \"`%Even the ability to conquer death...`)\"");
				output("She flies back and stands on the counter, giggling, \"`%So... you want one?!`)\"");
				addnav(array("Buy a Talisman (%s Favor)",$favor),"runmodule.php?module=abc&op=buy");
			}else{
				output("`%Aravis `)smiles cherubically at you, \"`%I am sorry %s, but you have already purchased one of my fine wares...`)\"",$g);
				output("She then flits away from you, smiling softly.");
			}
			break;
		case "buy":
			if ($session['user']['deathpower'] >= $favor){
				output("`%Aravis`) smiles and claspes her hands together.");
				output("She flies up and then dives behind her counter, retrieving a dank piece of metal.");
				output("`%Aravis`) sets it around your neck, and it slowly swings left and right.");
				output("`n`nShe`) says, \"`%This shall protect you... but be warned... there is a chance that the darkness is too great.");
				output("If that happens, the Talisman may fail... Do not fret, for these Talismans are strong and will not be bested easily...`)\"");
				$session['user']['deathpower']-=$favor;
				set_module_pref("has",1);
			}else{
				output("`%Aravis`) gazes upon your aura and shakes her head gently.");
				output("\"`%I am terribly sorry... but you do not have the required spiritual strength to bear the Talisman.");
				output("Please return when you have `^%s `%Favor.`)\"",$favor);
				output("`%Aravis`) notes, \"`%That is `^%s `%more that you need...`)\"",$favor-$session['user']['deathpower']);
			}
			break;
		case "res":
			blocknav("village.php");	
			page_header("Pool of Darkness");
			output("`)You stand in a small area... not knowing which way is up.");
			output("You are surrounded in darkness, as the pit of your stomach falls out...");
			output("Just when you feel that you are about to slip into death, the `&Talisman `)around your neck begins to light up...`n`n");
			$i = e_rand(1,100);
			if ($mchance != 0 && $i <= $mchance){
				output("`)Yet, it begins to cough and sputter.");
				output("You frown, as you soul is slowly ripped away by `\$Ramius`).");
				set_module_pref("has",0);
			}else{
				output("`)You grin, as the light from the `&Talisman `)enraptures your being.");
				output("Seeing that `\$Ramius`) is pushed away by the light, you slowly swim towards the surface of the blackness.");
				output("Finally you reach the top, and you peek your head above the black.");
				output("Taking in a fresh gulp of air, you feel ready for a newday.");
				addnav("Continue","newday.php?resurrection=true");
				set_module_pref("has",0);
				blocknav("shades.php");
			}
			break;
		}
villagenav();
page_footer();
}
?>