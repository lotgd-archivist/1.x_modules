<?php
// Wolf Den (den.php) module is a place to refer others as on www.fleigh.net
/// version 1.1 by Lord Wolfen �Copyright 2004 J F LEIGH
// check for most recent version at
//http://groups.msn.com/lotgd/join or dragonprime.net
// You must name this file: den.php
// TO DO LIST
// 1. Continue to add spend features.
//2. Consider making separate mods for lodge instead.
// 3. Else Make Translator Ready
// Change Log
// 09-19-2004 Version 1.1 spends added, links added
// changed to work with the suddenly available lodge mod.
// while considering merit of dividing into several mods for lodge
// 09-03-2004 V1.0 Added ref check and ref ranks and added more spends
// 08-17-2004 V 0.5.0 Updated for use with 0.9.8-prerelease.3

function den_getmoduleinfo(){
$info = array(
"name"=>"Wolf Den",
"version"=>"1.1",
"author"=>"Lord Wolfen, (J F LEIGH) ",
"category"=>"Lodge",
"download"=>"http://dragonprime.net/users/Lord%20Wolfen/den.zip",
"settings"=>array(
"Wolf Den Settings,title",
"units"=>"Set points per monetary unit,text|5 points per Dollar",
"gemcost"=>"Points per gem,int|25",
"goldcost"=>"Points per 500 gold,int|25",
"armcost"=>"Points to name weapon or armor,int|25",
"charmcost"=>"Points per charm,int|20",
"inncost2"=>"Points for 10 innstays,int|100",

"Donation Settings,title",
"text"=>"message,text| ",
"money"=>"Admin Legal Name,text| ",
"street"=>"Mailing Address,text| ",
"local"=>"City, ST ZIP,text| ",
),
"prefs"=>array(
"Wolf Den User Preferences,title",
"pointstoday"=>"How many points spent today?,int|0",
),
);
return $info;
}
function den_install(){
    module_addhook("lodge");
	module_addhook("pointsdesc");
module_addhook("village");
return true;
}

function den_uninstall(){
return true;
}

function den_dohook($hookname,$args){
global $session;
switch($hookname){

case "village":
addnav($args["fightnav"]);
addnav("`6Wolf `7Den","runmodule.php?module=den");
break;
case "referral":
addnav("`6Wolf `7Den","runmodule.php?module=den");
break;
case "lodge":
addnav("`6Wolf `7Den","runmodule.php?module=den");
break;


}
return $args;
}

function den_run(){
global $session;
$op = httpget('op');

page_header("Wolf Den");
$worth1 = get_module_setting("units");
$charmcost = get_module_setting("charmcost");
$armcost = get_module_setting("armcost");

$gemcost = get_module_setting("gemcost");

$goldcost = get_module_setting("goldcost");

$inncost2 = get_module_setting("inncost2");

$text = get_module_setting("text");
$money = get_module_setting("money");
$street = get_module_setting("street");
$local = get_module_setting("local");

if ($op == ""){
output("`c<font size='+1'>`bThe `6Wolf `7Den`0`b</font>`c`n`n`n",true);
output("`n`#You walk down a cobblestone path that leads into a small opening, you suddenly see two guards in front of
you...You wonder what they could be doing, as you approach you see a large decorated gate with a sign above that says
`&Wolf Den`#.");
output("`n`nYou walk up to one of the guards and he lets you through the gate and you enter the `&Wolf Den`#.`n");
output("The clock on the mantle reads `^".getgametime()."`@.");
output("`nThis is the place for referring other players to the game!`n");
output("You will automatically receive %s points for each person that you refer to this website who makes it to level %s.`n`n", getsetting("refereraward", 25), getsetting("referminlevel", 4));
$url = getsetting("serverurl",
            "http://".$_SERVER['SERVER_NAME'] .
            ($_SERVER['SERVER_PORT']==80?"":":".$_SERVER['SERVER_PORT']) .
            dirname($_SERVER['REQUEST_URI']));
    if (!preg_match("/\/$/", $url)) {
        $url = $url . "/";
        savesetting("serverurl", $url);
    }
output("How does the site know that I referred a person?`n
  Easy!  When you tell your friends about this site, give out the following link:`n`n".$url."referral.php?r=". rawurlencode($session['user']['login'])."`n`n
	and the site will know that you were the one who sent them here.  When they reach level 4 for the first time, you'll get your points!`n");
//output("With a single referral you will get ability to colorize your name as often as you want for Free. And still get to spend your points.`n`n");

output("`7When You have enough points and wish to spend them, you can do so using links here. `6You currently have approximately:  \"`3".$session[user][donation]."`6 points including donation and referral points.`6\". `0`n`n");
output("`#If you donate to `i`b`3this site`b`i`# you will get contribution points ~ $worth1 `n");

output(" `^To donate to this site you can use the PayPal link for site admin. `n ");
/////////Site specific blank til changed in mod settings
output("`^ $text `n`n ");
output("`&`b  $money `n $street `n $local `b`0`n");
output("`n `n");
/////////
output("`n`n");

addnav("Ref Stats");
addnav("Check My Referrals","runmodule.php?module=den&op=myref");
addnav("See Ref Rank","runmodule.php?module=den&op=checkref");

addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");

}
////About your points earned

if ($op == "myref"){
    output("`nHere is your list of referrals so you can track how you are doing.`n`n");
$sql = "SELECT name,level,refererawarded FROM " . db_prefix("accounts") . " WHERE referer={$session['user']['acctid']} ORDER BY dragonkills,level";
	$result = db_query($sql);
  output("`n`nAccounts which you referred:`n<table border='0' cellpadding='3' cellspacing='0'><tr><td>Name</td><td>Level</td><td>Awarded?</td></tr>",true);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		output("<tr class='".($i%2?"trlight":"trdark")."'><td>",true);
		output($row['name']);
		output("</td><td>{$row['level']}</td><td>".($row['refererawarded']?"`@Yes!`0":"`\$No!`0")."</td></tr>",true);
	}
	if (db_num_rows($result)==0){
		output("<tr><td colspan='3' align='center'>`iNone!</td></tr>",true);
	}
	output("</table>",true);
addnav("Wolf Den","runmodule.php?module=den&op=");
}
////////end view your points
/////////Referral Ranks
if ($op == "checkref"){
    output("`nBelow are stats on how our warriors are doing in referrals.`n`n");
output("<table border='0' cellpadding='2' cellspacing='1' bgcolor='#999999'>",true);
output("<tr class='trhead'><td><b>Name</b></td><td><b>Referrals</b></td></tr>",true);
$sql = "SELECT count(*) AS c, acct.acctid,acct.name AS referer FROM accounts INNER JOIN accounts AS acct ON
acct.acctid = accounts.referer WHERE accounts.referer>0 GROUP BY accounts.referer DESC ORDER BY c DESC";
$result = db_query($sql);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);
output("`@{$row['referer']}`0</td><td>`^{$row['c']}:`0 ", true);
$sql = "SELECT name,refererawarded from accounts WHERE referer = ${row['acctid']} ORDER BY acctid ASC";
$reweap = db_query($sql);
for ($j = 0; $j < db_num_rows($reweap); $j++) {
$r = db_fetch_assoc($reweap);
output(($r['refererawarded']?"`&":"`$") . $r['name'] ."`0");
if ($j != db_num_rows($reweap)-1) output(",");
}
output("</td></tr>",true);
}
output("</table>",true);
addnav("Wolf Den","runmodule.php?module=den&op=");
}
//////////End Referral Ranks

////////////////Begin Spend Options////////////////////////////
////////Name Armor
if ($op == "arm"){
if ($session['user']['donation']< $armcost){
 addnav("Go Back","runmodule.php?module=den");
output("`n`@You dont have that many points.`n`n");
}else{
$session['user']['donation']-= $armcost;
output("`n`nAre You ready to Rename Your Armor?....`n");
output("`^ Rename your Armor!");
    output("<form action='runmodule.php?module=den&op=renamea' method='POST'><input name='darmor'><input type='submit' class='button' value='submit'></form>",true);
    addnav("nevermind","runmodule.php?module=den");
    addnav("","runmodule.php?module=den&op=renamea");
    addnav("Back ","runmodule.php?module=den");
    }
}
if ($op == "renamea"){
    $darmor = httppost('darmor');
    $session['user']['armor'] = $darmor;
     output("`n`&Your Armors name has been changed to {$session['user']['armor']}!`n`n");
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
 }
 ////////////Name Weapon
if ($op == "weap"){
if ($session['user']['donation']< $armcost){
 addnav("Return ","runmodule.php?module=den");
output("`n`@You dont have that many points.`n");
}else{
$session['user']['donation']-= $armcost;
output("`n`nDo You wish to Rename your Weapon....`n");
output("`^  Rename your weapon!");
    output("<form action='runmodule.php?module=den&op=rename' method='POST'><input name='dweapon'><input type='submit' class='button' value='submit'></form>",true);
    addnav("nevermind","runmodule.php?module=den");
    addnav("","runmodule.php?module=den&op=rename");
    addnav("Back ","runmodule.php?module=den");
}
    }

if ($op == "rename"){
    $dweapon = httppost('dweapon');
    $session['user']['weapon'] = $dweapon;
     output("`n`7Your Weapon name has been changed to {$session['user']['weapon']}!`n`n");
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
 }
///////////// Inn Stays 10 coupons
if ($op == "inn2"){
    $config = unserialize($session['user']['donationconfig']);
if ($session['user']['donation'] > $inncost2){
            $config['innstays'] += 10;
            $config['coupon'] += 10;
$session['user']['donation']-= $inncost2;
output("`n`n`2You currently have `^".$config['innstays']."`2 coupons left.");
addnav("Return Den","runmodule.php?module=den");
}
else {
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
output("`nYou can`t afford this.`n`n");
}
}
///////////////// Charm points purchase
if ($op == "charming"){
    output("`c<font size='+1'>`bThe `6Wolf `7Den`0`b</font>`c`n`n`n",true);
output("`%How many charm points would you like to buy?`n");
output("<form action='runmodule.php?module=den&op=charmingbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button'
value='buy'></form>",true);
addnav("","runmodule.php?module=den&op=charmingbuy2");
addnav("Wolf Den","runmodule.php?module=den&op=");
}

if ($op == "charmingbuy2"){
$buy = httppost('buy');
if ($session['user']['donation'] < ($buy * $charmcost)) {output("Lord Wolfen's assistant gives you the finger after you show you cant count.`n`n"); }
else{
$cost=($buy * $charmcost);
$session['user']['donation']-= $cost;
$session['user']['charm']+= $buy;
output("`7Lord `6Wolfen `0takes your $cost points");
output(" and hands you $buy charm points.");
}
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
}
/////////////////

/////////////gold purchase

if ($op == "goldbuy"){
    output("`c<font size='+1'>`bThe `6Wolf `7Den`0`b</font>`c`n`n`n",true);
output("`%How much gold would you like to buy with points?`n");
output("<form action='runmodule.php?module=den&op=goldbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button'
value='buy'></form>",true);
addnav("","runmodule.php?module=den&op=goldbuy2");
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
}

if ($op == "goldbuy2"){
$buy = httppost('buy');
$bags = ($buy/500);
if ($session['user']['donation'] < ($bags * $goldcost)) {output("Lord Wolfen's assistant gives you the finger after you show you cant count.`n`n"); }
else{

$cost=($bags * $goldcost);
$session['user']['donation']-= $cost;

$session['user']['gold']+= $buy;
output("`7Lord `6Wolfen `0takes your $cost points");
output(" and hands you $buy gold.");
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
}
}
///////////////// Gem purchase working version
if ($op == "gembuy"){
    output("`c<font size='+1'>`bThe `6Wolf `7Den`0`b</font>`c`n`n`n",true);
output("`%How many gems would you like to buy with points?`n");
output("<form action='runmodule.php?module=den&op=gembuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button'
value='buy'></form>",true);
addnav("","runmodule.php?module=den&op=gembuy2");
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
}

if ($op == "gembuy2"){
$buy = httppost('buy');
if ($session['user']['donation'] < ($buy * $gemcost)) {output("Lord Wolfen's assistant gives you the finger after you show you cant count.`n`n"); }
else{
$cost=($buy * $gemcost);
$session['user']['donation']-= $cost;
$session['user']['gems']+= $buy;
output("`7Lord `6Wolfen `0takes your $cost points");
output(" and hands you $buy gems.");
}
addnav("Wolf Den","runmodule.php?module=den&op=");
addnav("Spend Options");
addnav("View Offers","runmodule.php?module=den&op=spend");
}
/////////////////////////////////////////////
if ($op == "spend"){
    output("`c<font size='+1'>`bThe `6Wolf `7Den`0`b</font>`c`n`n`n",true);
    output("`c`bPossible Point Spends`b`c");
output("`n`6You currently have approximately:  \"`3".$session['user']['donation']."`6 points including donation and referral points.`6\"`n`n");
addnav("Return Den","runmodule.php?module=den");
output("`bCurrently we are offering:`b`n`n");


addnav("Spend Points on");

output("`&Charm Potion - `7You will gain 1 more charm for $charmcost points.`n");
addnav("$charmcost per Charm point","runmodule.php?module=den&op=charming");


output("`^So You want to name things yourself? `n");
output("Rename Your Weapon or Armor for $armcost `n");
output("`7The new name will stay til you slay the Dragon.`n");
addnav("$armcost - Rename Armor","runmodule.php?module=den&op=arm");
addnav("$armcost - Rename Weapon","runmodule.php?module=den&op=weap");

output("`7Lord `6Wolfen `0has gems for trade, they cost $gemcost points.`n");
addnav("$gemcost per gem ","runmodule.php?module=den&op=gembuy");

output("`&$goldcost points will get you 500 in gold.`n");
addnav("$goldcost per 500 gold","runmodule.php?module=den&op=goldbuy");

output("`nBelow are spend options in the works. `n");
output("`^For $inncost2 points - `7You will recieve 10 Free Stays at the Inn.`n`n");

output("`n`^Be sure to check back to see what else will become available.`n`0");
output("`7Will need to get new coding to implement these.`n`n");
output("`n`5Change Name Color`n");
//addnav("Change Name Color","");
output("`5Change Mount Name`n");
//addnav("Change Mount Name","");

output("`n`7Note Other Spends options will take you to the old lodge.`n`n");


addnav("Other Spends");
modulehook("lodge");
}

////////////////////////////
addnav("Other");
require_once("lib/villagenav.php");
villagenav();

page_footer();
}
?>
