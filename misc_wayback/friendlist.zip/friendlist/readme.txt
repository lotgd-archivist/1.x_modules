Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a friend list module for LotGD 1.0.0.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy every file in this zip, except this one,
into your modules folder.
Login to the Superuser Grotto and Install it.
Set up the settings.
Login to the Superuser Grotto and Activate it.

Version Info
Details:
 * It allows your users to have a friendlist
History Log:
 v1.0:
 o Seems to be Stable
 v1.1:
 o Ignoring will stop a user from sending another user mail
 o Users can click on a name in their list to send them mail
 v1.3:
 o Fixed a bug with redirect changing your restorepage
 v1.3:
 o It really *is* fixed now
 v1.4:
 o Users can ignore Superusers, however mails from those who can enter the Grotto will override this
 v1.5:
 o Users can see if their friends are logged-in
 v1.6:
 o More is explained in the FaQ
 v1.7:
 o Checks work...
 v2.1:
 o Includes checking modifications, thanks XChrisX!