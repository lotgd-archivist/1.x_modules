<?php
function charmdisplay_getmoduleinfo(){
	$info = array(
		"name"=>"Charm Display",
		"author"=>"Chris Vorndran",
		"version"=>"0.2",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/Sichae/charmdisplay.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"This module will allow for users to see how much charm they have and even get a compliment based on their charm level.",
		"settings"=>array(
			"Tresholds,title",
			"one"=>"Threshhold of Level One,int|10",
			"two"=>"Threshhold of Level Two,int|30",
			"three"=>"Threshhold of Level Three,int|50",
			"four"=>"Threshhold of Level Four,int|70",
			"These Values mark the MINIMUM of the Level. For Level Five it will be anything above Level Four,note",
			"Female Self Esteem Ratings,title",
			"onef"=>"Level One Self Esteem Title,text|Plain",
			"twof"=>"Level Two Self Esteem Title,text|Cute",
			"threef"=>"Level Three Self Esteem Title,text|Pretty",
			"fourf"=>"Level Four Self Esteem Title,text|Gorgeous",
			"fivef"=>"Level Five Self Esteem Title,text|Beautiful",
			"Male Self Esteem Ratings,title",
			"onem"=>"Level One Self Esteem Title,text|Plain",
			"twom"=>"Level Two Self Esteem Title,text|Muscular",
			"threem"=>"Level Three Self Esteem Title,text|Handsome",
			"fourm"=>"Level Four Self Esteem Title,text|Ravishing",
			"fivem"=>"Level Five Self Esteem Title,text|Debonair",
		),
		"user_prefs"=>array(
			"Charm Display Preferences,title",
			"user_showcharm"=>"Do you wish for Charm to be displayed,bool|0",
			"user_esteem"=>"Do you wish for the Charm to give you a Self Esteem Boost,bool|0",
			),
		"prefs"=>array(
			"Charm Display Preferences,title",
			"user_showcharm"=>"Do you wish for Charm to be displayed,bool|0",
			"user_esteem"=>"Do you wish for the Charm to give you a Self Esteem Boost,bool|0",
			),
		);
	return $info;
}
function charmdisplay_install(){
	module_addhook("charstats");
	return true;
}
function charmdisplay_uninstall(){
	return true;
}
function charmdisplay_dohook($hookname,$args){
	global $session;

	$amnt = $session['user']['charm'];

	$onef = get_module_setting("onef");
	$twof = get_module_setting("twof");
	$threef = get_module_setting("threef");
	$fourf = get_module_setting("fourf");
	$fivef = get_module_setting("fivef");

	$onem = get_module_setting("onem");
	$twom = get_module_setting("twom");
	$threem = get_module_setting("threem");
	$fourm = get_module_setting("fourm");
	$fivem = get_module_setting("fivem");

	$one = get_module_setting("one");
	$two = get_module_setting("two");
	$three = get_module_setting("three");
	$four = get_module_setting("four");
	switch ($hookname){
		case "charstats":
			if (get_module_pref("user_showcharm") == 1){
			$title = translate_inline("Personal Info");
			$name = translate_inline("Charm");
			$amnt = $session['user']['charm'];
			setcharstat ($title,$name,$amnt);
		}
			if ($session['user']['sex'] == 1){
				if ($amnt < $one) $level = $onef;
				if ($amnt >= $one && $amnt < $two) $level = $twof;
				if ($amnt >= $two && $amnt < $three) $level = $threef;
				if ($amnt >= $three && $amnt < $four) $level = $fourf;
				if ($amnt >= $four) $level = $fivef;
			}else{
				if ($amnt < $one) $level = $onem;
				if ($amnt >= $one && $amnt < $two) $level = $twom;
				if ($amnt >= $two && $amnt < $three) $level = $threem;
				if ($amnt >= $three && $amnt < $four) $level = $fourm;
				if ($amnt >= $four) $level = $fivem;
				}
			if (get_module_pref("user_esteem") == 1){
			$title = translate_inline("Personal Info");
			$name = translate_inline("Compliment");
			setcharstat ($title,$name,$level);
			}
				break;
		}
	return $args;
}
function charmdisplay_run(){
}
?>