<?php
function massmodule_getmoduleinfo(){
	$info = array(
		"name"=>"Mass Module Things",
		"author"=>"Chris Vorndran",
		"version"=>"1.1",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/users/Sichae/massmodule.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows for Megauser's to be able to Deactivate, Activate, Reinstall all modules, or based on Category.",
		);
	return $info;
}
function massmodule_install(){
	module_addhook("superuser");
	return true;
}
function massmodule_uninstall(){
	return true;
}
function massmodule_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "superuser":
			if ($session['user']['superuser'] & SU_MEGAUSER){
			addnav("Mechanics");
			addnav("Mass Module Options","runmodule.php?module=massmodule&op=enter");
		}
		break;
	}
	return $args;
}
function massmodule_run(){
	global $session;
	$op = httpget('op');
	$op2 = httpget('op2');
	page_header("Mass Module Options");
	switch ($op){
	case "enter":
		output("`3You walk into a rather large room, and see a couple of big switches... three to be exact.");
		addnav("Activation");
		addnav("Activate All Modules","runmodule.php?module=massmodule&op=activate");
		addnav("De-Activate All Modules","runmodule.php?module=massmodule&op=deact");
		addnav("Other");
		addnav("Reinstall All Modules","runmodule.php?module=massmodule&op=reinstall");
		addnav("Category Options","runmodule.php?module=massmodule&op=category");
		blocknav("runmodule.php?module=massmodule&op=enter");
		break;
	case "activate":
		output("`3Once you do so, all Modules shall be activated, that are installed.");
		output("Do you wish to proceed?");
		addnav("Yes","runmodule.php?module=massmodule&op=actyes");
		blocknav("runmodule.php?module=massmodule&op=enter");
		break;
	case "actyes":
		rawoutput("<big>");
		output("`b`^ALL MODULES ACTIVATED!!!`b");
		rawoutput("</big>");
		$sql = "UPDATE " . db_prefix("modules") . " SET active=1 WHERE modulename !='serversuspend'";
		db_query($sql);
		break;
	case "reinstall":
		output("`3Once you do so, all modules installed, shall be reinstalled. No losing of any information.");
		output("Do you wish to proceed?");
		addnav("Yes","runmodule.php?module=massmodule&op=reinyes");
		blocknav("runmodule.php?module=massmodule&op=enter");
		break;
	case "reinyes":
		rawoutput("<big>");
		output("`b`^ALL MODULES REINSTALLED!!!`b");
		rawoutput("</big>");
		$sql = "UPDATE " . db_prefix("modules") . " SET filemoddate='0000-00-00 00:00:00'";
		db_query($sql);
		break;
	case "deact":
		output("`3Once you do so, all modules shall not be able to be accessed, except for this one that you are using.");
		output("Do you wish to proceed?");
		addnav("Yes","runmodule.php?module=massmodule&op=deactyes");
		blocknav("runmodule.php?module=massmodule&op=enter");
		break;
	case "deactyes":
		rawoutput("<big>");
		output("`b`^ALL MODULES DEACTIVATED!!!`b");
		rawoutput("</big>");
		$sql = "UPDATE " . db_prefix("modules") . " SET active=0 WHERE modulename !='massmodule'";
		db_query($sql);
		break;
	case "category": 
           output("`3Also, you have the option to activate/reinstall, in any category you wish."); 
           output(" Which category do you wish to look at?"); 
           $sql = "SELECT modulename,category FROM " . db_prefix("modules"); 
           $result = db_query($sql); 
           $seencats = array(); 
           for ($i=0;$i<db_num_rows($result);$i++){ 
                $row = db_fetch_assoc($result); 
                $seencats[$row['category']]++; 
           } 
           ksort($seencats); 
           foreach ($seencats as $cat=>$count) { 
			   addnav("Categories");
               addnav(array(" ?%s - (%s modules)", $cat, $count), "runmodule.php?module=massmodule&op=categyes&op2=".$cat); 
           } 
           addnav("Leave"); 
           break; 
	case "categyes":
		output("`3You have selected the Category: `^%s`3.", $op2);
		output(" `3What would you like to do?`n`n");
		rawoutput("<big>");
		output("`b`\$NOTE: Once you select, the process shall start.`b");
		rawoutput("</big>");
		addnav("Activate","runmodule.php?module=massmodule&op=categact&op2=".$op2);
		addnav("De-Activate","runmodule.php?module=massmodule&op=categdeact&op2=".$op2);
		addnav("Reinstall","runmodule.php?module=massmodule&op=categrein&op2=".$op2);
		break;
	case "categact":
		rawoutput("<big>");
		output("`b`^ALL MODULES ACTIVATED IN THE %s CATEGORY!!!`b",$op2);
		rawoutput("</big>");
		$sql = "UPDATE " . db_prefix("modules") . " SET active=1 WHERE category='$op2' AND modulename !='serversuspend'";
		db_query($sql);
		break;
	case "categdeact":
		rawoutput("<big>");
		output("`b`^ALL MODULES DEACTIVATED IN THE %s CATEGORY!!!`b",$op2);
		rawoutput("</big>");
		$sql = "UPDATE " . db_prefix("modules") . " SET active=0 WHERE category='$op2' AND modulename !='massmodule'";
		db_query($sql);
		break;
	case "categrein":
		rawoutput("<big>");
		output("`b`^ALL MODULES REINSTALLED IN THE %s CATEGORY!!!`b",$op2);
		rawoutput("</big>");
		$sql = "UPDATE " . db_prefix("modules") . " SET filemoddate='0000-00-00 00:00:00' WHERE category='$op2'";
		db_query($sql);
		break;
	}
	addnav("Leave");
	addnav("Return to the Switches","runmodule.php?module=massmodule&op=enter");
	addnav("Return to the Grotto","superuser.php"); 
page_footer();
}
?>