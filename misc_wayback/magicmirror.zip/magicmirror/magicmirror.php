<?php
require_once("lib/sanitize.php");
require_once("lib/http.php");

function magicmirror_getmoduleinfo(){
	$info = array(
		"name"=>"Magic Mirror",
		"author"=>"`@CortalUX",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"version"=>"2.0",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/magicmirror.zip",
		"allowanonymous"=>true,
		"override_forced_nav"=>true,
		"settings"=>array(
			"Magic Mirror Settings - General,title",
			"GoldCost"=>"How much gold does the Magic Mirror cost?,int|1800",
			"MirrorBuy"=>"Can the Magic Mirror be purchased?,bool|1",
			"(select no if you want every user to have one by default),note",
			"suHave"=>"Do Superusers have Mirrors by default?,bool|0",
			"(this only applys to Superusers with comment editing privs...),note",
			"seconds"=>"Seconds between each refresh?,range,1,10,1|1",
			"Magic Mirror Settings - Note,title",
			"currentNote"=>"The current mirror note...,text|Note?",
			"payNote"=>"Can users pay to change this?,bool|1",
			"price"=>"If yes- Cost for changing the note?,int|1500",
			"(Set to 0 for free),note",
			"limit"=>"Maximum times can be changed between each new day?,int|0",
			"(0 for unlimited),note",
			"Magic Mirror Settings - Clans,title",
			"clanMirror"=>"Can clans have their own Mirror System?,bool|0",
			"clanGoldCost"=>"How much gold does the Magic Mirror System cost for a clan to buy?,int|89200",
			"(the leader has to pay for it),note",
		),
		"prefs"=>array(
			"Magic Mirror Preferences,title",
			"hasMirror"=>"Does this user have a Magic Mirror?,bool|0",
			"(only of any use if you have to buy Mirrors...),note",
			"changed"=>"Times changed since last newday?,int|0",
		),
		"prefs-clans"=>array(
			"haveSystem"=>"Does this clan have a Mirror System yet?,bool|0",
			"officersUse"=>"Does the leader allow his/her officers to set the name/note?,bool|1",
			"beenNamed"=>"What have officers/leaders named their system?,text|The Clan Mirror",
			"note"=>"What is the Mirror System's 'note'?,text|Nothing of importance...",
		),
	);
	return $info;
}

function magicmirror_install(){
	require_once("modules/magicmirror/magicmirror_install.php");
	return true;
}

function magicmirror_uninstall(){
	require_once("modules/magicmirror/magicmirror_uninstall.php");
	return true;
}

function magicmirror_dohook($hookname,$args){
	require_once("modules/magicmirror/magicmirror_dohook.php");
	return $args;
}

function magicmirror_run(){
	require_once("modules/magicmirror/magicmirror_run.php");
}
?>