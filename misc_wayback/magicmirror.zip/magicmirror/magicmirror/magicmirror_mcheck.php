<?php
function magicmirror_mcheck() {
	global $session;
	if (get_module_setting("MirrorBuy")==1&&get_module_pref("hasMirror")==1){
		return true;
	} elseif (get_module_setting("MirrorBuy")==0) {
		return true;
	} elseif ($session['user']['superuser'] & SU_EDIT_COMMENTS && get_module_setting("suHave")==1){
		return true;
	}
	return false;
}
?>