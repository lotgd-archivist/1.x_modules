<?php
global $session;
$op = httpget('op');
$buymirror = httpget('buymirror');
$clan = $session['user']['clanid'];
$place=httpget('place');
switch ($op) {
	case "mirror":
		require_once("modules/magicmirror/magicmirror_page.php");
		magicmirror_page();
	break;
	case "notechange":
		page_header("Gypsy Seer's tent");
		if (httpget('ty')=="") {
			$price=get_module_setting($price);
			if ($session['user']['gold']>$price&&$price!=0||$session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO||$price==0) {
				if ($session['user']['gold']>$price&&$price!=0) {
					$session['user']['gold']-=$price;
					output("`@As you pass `^%s`@ gold to %s`@, and he grins at you.",$price,"`#CortalUX");
				}
				output("%s `@hands you a potion, and begins to speak. `3\"`^Gulp this, and vizualize the note... the potion will disappear, so drink it quickly!`3\"","`#CortalUX");
				rawoutput("<form action='runmodule.php?module=magicmirror&op=notechange&ty=2' method='post'>");
				output_notl("`^`b%s`b`@ <input size='50' name='note' value=''>`n",translate_inline("The Note:"),true);
				$s=translate_inline("Vizualize");
				rawoutput(" <input class='button' type='submit' value='$s'></form>");
				addnav("","runmodule.php?module=magicmirror&op=notechange&ty=2");
			} else {
				output("%s`@ shrugs, and walks off.`n`&You don't have enough gold.`n`%You are so embarassed, you want to leave the shop.","`#CortalUX");
				require_once("lib/villagenav.php");
				villagenav();
			}
		} else {
			$notem=trim(httppost("note"));
			require_once("lib/addnews.php");
			if ($notem=="") {
				$notem=translate_inline("`\$I stupidly couldn't think of anything for this note! From... ").$session['user']['name'];
				addnews("`^%s `&stupidly couldn't think of anything for the Magic Mirror note!",$session['user']['name']);
			} else {
				$notem=$session['user']['name'].translate_inline("`^'s note: `&").$notem;
				addnews("`^%s `&set the Magic Mirror note to `@'`@'`&.",$session['user']['name'],$notem);
			}
			set_module_setting("currentNote",$notem);
			output("`@Colours blur before your eyes, and the note changes...");
			addnav("Navigation");
			require_once("lib/villagenav.php");
			villagenav();
		}
		page_footer();
	break;
	case "comms":
		if ($session['user']['loggedin']==0) {
			echo "<br/>".translate_inline("Logged Out.");
			die();
		} else {
			$str=httpget("graf");
			$stri=str_replace("%s",$str,translate_inline(" `3says `^\"`&%s`^\""));
			if (substr($str, 0, 1)==":") {
				$x=strlen($str)-1;
				$stri="`& ".substr($str,1,$x);
			}
			if (substr($str, 0, 2)=="::") {
				$x=strlen($str)-2;
				$stri="`& ".substr($str,2,$x);
			}
			if (substr($str, 0, 3)=="/me") {
				$x=strlen($str)-3;
				$stri="`& ".substr($str,3,$x);
			}
			$stri=$session['user']['name'].$stri;
			//echo "<br/>".appoencode($stri);
			$time=time();
			$sql="INSERT INTO `".db_prefix("magicmirror")."` SET place='".addslashes($place)."',time='$time',data='".addslashes($stri)."';";
			db_query($sql);
			$del=time()-get_module_setting("seconds")-1;
			$sql="DELETE FROM `".db_prefix("magicmirror")."` WHERE time<'$del'";
			db_query($sql);
		}
	break;
	case "buffer":
		$time=httpget('lasttime');
		if ($session['user']['loggedin']==0) {
			echo "<br/>".translate_inline("Logged Out.");
			die();
		} else {
			if ($time==0) $time=time()-1;
			$sql="SELECT * FROM `".db_prefix("magicmirror")."` WHERE place='".addslashes($place)."' AND time>$time;";
			$result=db_query($sql);
			while ($row=db_fetch_assoc($result)) {
				echo "<br/>".appoencode(stripslashes($row['data']));
			}
			echo "lastseen".time();
		}
	break;
	case "gypsy":
		page_header("The Gypsy");
		$cost = get_module_setting("GoldCost");
		if ($buymirror == ''){
			output("`5\"`!%s`5\" %s`n",translate_inline("Ah, yes.  An adventurer.  I could tell by looking into your eyes,"),translate_inline("the gypsy says."));
			output("\"`!%s",translate_inline("Many people travel the world, my Mirror allows you to speak through the ether..."));
			output("%s`5\"`n",translate_inline("It will let you see their plight, and reply with your might."));
			output("\"`!%s",translate_inline("Yes, yes.  Let's see...  What sort of price should I put on this?"));
			output("%s `^%s`! %s`5\"",translate_inline("Hmm.  How about"), $cost, translate_inline("gold?"));
			addnav(array("%s `0(`^%s %s`0)", translate_inline("Buy a Magic Mirror"), $cost, translate_inline("gold")),"runmodule.php?module=magicmirror&op=gypsy&buymirror=yes");
			addnav(array("%s", translate_inline("Browse the rest of the shop...")),"gypsy.php");
			require_once("lib/villagenav.php");
			villagenav();
		} elseif ($buymirror == 'yes'){
			if ($session['user']['gold'] < $cost){
				output("`5\"`!%s`5\"",translate_inline("What do you take me for?  A blind hag?  Come back when you have the money!"));
				addnav(array("%s",translate_inline("Run!!!")),"village.php");
			}else{
				output("`5\"`!%s,`5\" %s",translate_inline("Enjoy your new found speech"),translate_inline("the gypsy says as she walks away to greet some patrons that have just strolled in."));
				$session['user']['gold']-=$cost;
				set_module_pref("hasMirror",1);
				require_once("lib/villagenav.php");
				villagenav();
			}
		}
		page_footer();
	break;
	case "csettings":
		page_header("Clan Mirror System");
		output("`@%s `^%s`n`n",translate_inline("Your Clan's Mirror System is currently named:"),translate_inline(get_module_objpref("clans", $session['user']['clanid'], "beenNamed")));
		output("`@%s `^%s`n`n",translate_inline("Your Clan's Mirror System currently has the note of:"),translate_inline(get_module_objpref("clans", $session['user']['clanid'], "note")));
		addnav(array("%s",translate_inline("Set the note of your Mirror System")),"runmodule.php?module=magicmirror&op=csettings&ty=note");
		addnav(array("%s",translate_inline("Set the name of your Mirror System")),"runmodule.php?module=magicmirror&op=csettings&ty=name");
		if ($session['user']['clanrank'] == CLAN_LEADER) {
			$status = translate_inline((get_module_objpref("clans", $session['user']['clanid'], "officersUse")?"On":"Off"));
			output("`@%s `^%s `@%s",translate_inline("You currently have Officers System Editing"),$status,translate_inline(". If this is on, Officers and all higher ranks can change the Mirror System name/note, otherwise, only you can."));
			addnav(array("`^%s`@%s`^%s",translate_inline("Toggle Clan Officers (Currently: "),$status,translate_inline(")")),"runmodule.php?module=magicmirror&op=csettings&ty=toggle");
		}
		addnav(translate_inline("Return to your clan."),"clan.php");
		switch (httpget('ty')) {
			case "note":
				if (httpget('con')=="yes"){
					set_module_objpref("clans", $session['user']['clanid'], "note",httppost('newnote'));
					output("`n`b`^Magic Mirror System note set to '`@`b%s`b`^'`b",httppost('newnote'));
					output_notl("`n`n`&`b`i");
					rawoutput("<a href='runmodule.php?module=magicmirror&op=csettings'>");
					output("%s",translate_inline("Click here to refresh this page, to make any changes you made show up.`i`b"));
					rawoutput("</a>");
					output("`i`b`0");
				}else{
					rawoutput("<form action='runmodule.php?module=magicmirror&op=csettings&ty=note&con=yes' method='POST'>");
					$b = translate_inline("New note:");
					output_notl("`n`&");
					rawoutput("<b>$b"."</b> <input type='text' name='newnote'><input type='submit' value='Submit'>");
					rawoutput("</form>");
					addnav("", "runmodule.php?module=magicmirror&op=csettings&ty=note&con=yes");
				}
			break;
			case "toggle":
				$status = translate_inline((get_module_objpref("clans", $session['user']['clanid'], "officersUse")?"0":"1"));
				set_module_objpref("clans", $session['user']['clanid'], "officersUse",$status);
				$status = translate_inline(($status?"On":"Off"));
				output("`n`n`b`@You have just toggled Officers System Editing to `^%s `@.`b`n`n`&`b`i",$status);
				rawoutput("<a href='runmodule.php?module=magicmirror&op=csettings'>");
				output("Click here to refresh this page, to make any changes you made show up.`i`b");
				rawoutput("</a>");
				output_notl("`i`b`0");
			break;
			case "name":
				if (httpget('con')=="yes"){
					set_module_objpref("clans", $session['user']['clanid'], "beenNamed",full_sanitize(httppost('newname')));
					output("`n`b`^Magic Mirror System name set to`@ %s`b`n`n`&`b`i",full_sanitize(httppost('newname')));
					rawoutput("<a href='runmodule.php?module=magicmirror&op=csettings'>");
					output("Click here to refresh this page, to make any changes you made show up.`i`");
					rawoutput("</a>");
					output("`i`b`0");
				}else{
					rawoutput("<form action='runmodule.php?module=magicmirror&op=csettings&ty=name&con=yes' method='POST'>");
					output_notl("`n`&");
					$b = translate_inline("New name:");
					rawoutput("<b>$b"."</b> <input type='text' name='newname'><input type='submit' value='Submit'>");
					rawoutput("</form>");
					addnav("", "runmodule.php?module=magicmirror&op=csettings&ty=name&con=yes");
				}
			break;
		}
		page_footer();
	break;
	case "clanbuy":
		page_header("Clan Mirror System");
		$cost = get_module_setting("clanGoldCost");
		if ($buymirror == ''){
			output("`@%s`n",translate_inline("An old Hag from the Gypsy Tent sits in front of you."));
			output("`5\"`!%s`5\" %s`n",translate_inline("Have you noticed the Magic Mirrors I have been selling?"),translate_inline("the gypsy says."));
			output("\"`!%s",translate_inline("Many people travel the world, my Mirror allows you to speak through the ether..."));
			output("\"`!%s",translate_inline("I could give your Clan it's own system, oh yes. Perfect for clans.."));
			output("\"`!%s`^ $cost `!%s",translate_inline("I only ask..."),translate_inline("gold."));
			addnav(array("%s `0(`^%s %s`0)", translate_inline("Buy a Magic Mirror System"), $cost, translate_inline("gold")),"runmodule.php?module=magicmirror&op=clanbuy&buymirror=yes");
			addnav(array("%s",translate_inline("Return to your clan.")),"clan.php");
		} elseif ($buymirror == 'yes'){
			if ($session['user']['gold'] < $cost){
				output("`5\"`!%s`5\"",translate_inline("What do you take me for?  A blind hag? I'll come back when you have the money!"));
				addnav(array("%s",translate_inline("Run!!!")),"clan.php");
			}else{
				output("`5\"`!%s,`5\" %s",translate_inline("Enjoy your communication.."),translate_inline("the gypsy says as she fades away..."));
				$session['user']['gold']-=$cost;
				set_module_objpref("clans", $session['user']['clanid'], "haveSystem","1");
				addnav(array("%s",translate_inline("Return to your clan.")),"clan.php");
				addnav(array("%s",translate_inline("Set up your Mirror System Settings")),"runmodule.php?module=magicmirror&op=settings");
			}
		}
		page_footer();
	break;
}
?>