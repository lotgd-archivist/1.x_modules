<?php
global $session;
global $nobios;
$clan = $session['user']['clanid'];
switch($hookname){
	case "newday":
		set_module_pref("changed",0);
	break;
	case "footer-clan":
		if (get_module_objpref("clans", $clan, "haveSystem")==1&&get_module_setting("clanMirror")==1) {
			if ($session['user']['clanrank'] == CLAN_LEADER){
				addnav("~");
				addnav(array("%s", translate_inline("Clan Mirror System Settings")),"runmodule.php?module=magicmirror&op=csettings");
			}elseif ($session['user']['clanrank'] == CLAN_OFFICER&&get_module_objpref("clans", $clan, "officersUse")==1){
				addnav("~");
				addnav(array("%s", translate_inline("Clan Mirror System Settings")),"runmodule.php?module=magicmirror&op=csettings");
			}
		} else {
			if ($session['user']['clanrank'] == CLAN_LEADER&&get_module_setting("clanMirror")==1){
				addnav("~");
				addnav(array("`@%s", translate_inline("Buy a Clan Mirror System")),"runmodule.php?module=magicmirror&op=clanbuy");
			}
		}
	break;
	case "footer-popup":
		if (httpget('module')=='magicmirror'&&httpget('op')=='mirror') {
			require_once("modules/magicmirror/magicmirror_script.php");
			$script=magicmirror_script(httpget('place'))."<meta http-equiv=\"Page-Enter\" content=\"getnewLotGD_MagicMirror(0,1);\">";
			if (!isset($args['headscript'])) {
				$args['headscript'] = array();
			} elseif (!is_array($args['headscript'])) {
				$args['headscript'] = array($args['headscript']);
			}
			array_push($args['headscript'], $script);
		}
	break;
	case "footer-gypsy":
		if (get_module_setting("MirrorBuy")==1&&get_module_pref("hasMirror")==0){
			addnav("Magic Mirror");
			$x = translate_inline("Ask about Funny Mirror");
			addnav("`@Ask about Funny Mirror", "runmodule.php?module=magicmirror&op=gypsy");
			output("`n`n`^You can see a Funny Mirror sparkling on the shop floor...");
	      }
	      require_once("modules/magicmirror/magicmirror_mcheck.php");
	      if (get_module_setting("payNote")==1&&magicmirror_mcheck()) {
		      if (get_module_pref("changed")<get_module_setting("limit")||get_module_setting("limit")==0) {
			      $price=get_module_setting("price");
			      output("`n`@A man sits in the corner of the room.");
			      output("`n`^The Gypsy looks in your direction. Gesturing at you to come over, you begin to move over to her.");
			      output("`nAs she introduces you to the man, he begins to speak in a ye olde worlde voice.`n`3\"`^I am %s`^, Master of Potions. I hear you have a Magic Mirror of mine. I have some powers at my disposal... would you like to post a note upon the mirror?`3\"","`#CortalUX");
			      if (get_module_setting("price")>0) {
				      output("`n%s`& continues... `3\"`^This service is but `@%s`^ gold.`3\"","`#CortalUX",get_module_setting("price"));
			      }
			      addnav("Magic Mirror");
			      addnav("`@Change the Mirror Note","runmodule.php?module=magicmirror&op=notechange");
		      } else {
		      	output("`n`&A corner of the room is oddly empty...");
		      }
	      }
	break;
	case "charstats":
		require_once("modules/magicmirror/magicmirror_mcheck.php");
		if (magicmirror_mcheck()) {
			require_once("modules/magicmirror/magicmirror_statshow.php");
			magicmirror_statshow();
		}
	break;
}
?>