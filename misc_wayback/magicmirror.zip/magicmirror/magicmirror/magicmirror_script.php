<?php
function magicmirror_script($place="") {
	$script="<script language='Javascript' type='text/javascript'>
<!--

var lastseen;
lastseen=0;
var timeout;
var inthemiddle;
inthemiddle=0;
var cycles;			// refreshes since last keystroke
cycles=0;
var paused;
paused=0;
var count;
count=0;

function checkforenter(e) {
	cycles=0;
	var found;
	found=0;
	if (e.keyCode==13) {
		submitLotGD_MagicMirror();
		found=1;
	}
	if (found==0) {
		if (e.which==13) submitLotGD_MagicMirror();
		found=1;
	}
}

function submitLotGD_MagicMirror() {
	var url;
	var http
	/"."*@cc_on @*"."/
	/"."*@if (@_jscript_version >= 5)
	  try {
	  http=new ActiveXObject(\"Msxml2.XMLHTTP\")
	 } catch (e) {
	  try {
	    http=new ActiveXObject(\"Microsoft.XMLHTTP\")
	  } catch (E) {
	   http=false
	  }
	 }
	@else
	 http=false
	@end @*"."/
	if (!http) {
	 try {
	  http = new XMLHttpRequest();
	 } catch (e) {
	  http=false
	 }
	}
	var postedgraf=document.LotGD_MagicMirrorform.graf.value;
	//alert(URLDecode(URLEncode(postedgraf)));
	postedgraf=URLEncode(postedgraf);
	//url = \"http://\"+window.location.hostname+\"/runmodule.php?module=magicmirror&place=$place&op=comms&graf=\"+postedgraf;
	url = \"runmodule.php?module=magicmirror&place=$place&op=comms&graf=\"+postedgraf;
	http.open(\"GET\", url);
	http.onreadystatechange = function () {
		if (http.readyState==4) {
			document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML+=(http.responseText);
			document.getElementById(\"LotGD_MagicMirrorWindow\").scrollTop+=55;
			document.LotGD_MagicMirrorform.graf.value=\"\";
			document.LotGD_MagicMirrorform.graf.focus();
			if (inthemiddle==0) getnewLotGD_MagicMirror(lastseen,1);
		}
	}
	http.send(null);
	return false;
}

function restartLotGD_MagicMirror() {
	if (paused!=0) {
		paused=0;
		cycles=0;
		getnewLotGD_MagicMirror(0,1);
		document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML+=\"<font color=green>".translate_inline("MagicMirror restarted.")."</font><br>\";
		document.getElementById(\"LotGD_MagicMirrorWindow\").scrollTop+=55;
	}
}

function getnewLotGD_MagicMirror(last,repeat) {
	inthemiddle=1;
	//document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML+=\"Start #\"+count+\"<br>\";
	document.getElementById(\"LotGD_MagicMirrorWindow\").scrollTop+=40;
	var subcount;
	subcount=count;
	count++;
	var url;

	var http
	/"."*@cc_on @*"."/
    /"."*@if (@_jscript_version >= 5)
	  try {
	  http=new ActiveXObject(\"Msxml2.XMLHTTP\")
	 } catch (e) {
	  try {
	    http=new ActiveXObject(\"Microsoft.XMLHTTP\")
	  } catch (E) {
	   http=false
	  }
	 }
	@else
	 http=false
	@end @*"."/
	if (!http) {
	 try {
	  http = new XMLHttpRequest();
	 } catch (e) {
	  http=false
	 }
	}
	//url = \"http://\"+window.location.hostname+\"/runmodule.php?module=magicmirror&place=$place&op=buffer&lasttime=\"+last;
	url = \"runmodule.php?module=magicmirror&place=$place&op=buffer&lasttime=\"+last;
	http.open(\"GET\", url);
	http.onreadystatechange = function () {
		if (http.readyState==4) {
			inthemiddle=0;
			index=http.responseText.lastIndexOf(\"lastseen\");
			newlast=http.responseText.substring(index+8,index+19);
			if (newlast>0) {
				lastseen=newlast;
			}
			var doscroll=false;

			theDiv=document.getElementById(\"LotGD_MagicMirrorWindow\");
			if (theDiv.scrollHeight - (theDiv.scrollTop + theDiv.offsetHeight) < 4) doscroll=true;

			document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML+=(http.responseText.substring(0, (http.responseText.length-18)));

			LotGD_MagicMirrorlen=document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML.length;
			if (LotGD_MagicMirrorlen>30000 && newlast>0) {
				newhtml=document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML.substring(LotGD_MagicMirrorlen-30000,LotGD_MagicMirrorlen);
				newhtml=newhtml.substring(newhtml.indexOf(\"<\"),30000);
				document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML=newhtml;
			}
			//document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML+=\"Stop #\"+subcount+\"<br>\";
			if (doscroll) document.getElementById(\"LotGD_MagicMirrorWindow\").scrollTop+=55;

			cycles++;
			if (paused==0 && cycles>150) {
				paused=1;
				document.getElementById(\"LotGD_MagicMirrorWindow\").innerHTML+=\"<font color=green>".translate_inline("Your MagicMirror has stopped refreshing because you have been inactive for 15 minutes.")."  <a href=\\\"javascript:restartLotGD_MagicMirror();\\\">".translate_inline("Click Here")."</a>".translate_inline(" to reconnect to your MagicMirror.")."</font><br>\";
				document.getElementById(\"LotGD_MagicMirrorWindow\").scrollTop+=55;
			} else if (repeat==1) {
				timeout = setTimeout(\"getnewLotGD_MagicMirror(lastseen,1);\",".get_module_setting("seconds")."000);
			}
		}
	}
	http.send(null);

}

// ====================================================================
//       URLEncode and URLDecode functions
//
// Copyright Albion Research Ltd. 2002
// http://www.albionresearch.com/
//
// You may copy these functions providing that
// (a) you leave this copyright notice intact, and
// (b) if you use these functions on a publicly accessible
//     web site you include a credit somewhere on the web site
//     with a link back to http://www.albionresarch.com/
//
// If you find or fix any bugs, please let us know at albionresearch.com
//
// SpecialThanks to Neelesh Thakur for being the first to
// report a bug in URLDecode() - now fixed 2003-02-19.
// ====================================================================
function URLEncode(x)
{
	// The Javascript escape and unescape functions do not correspond
	// with what browsers actually do...
	var SAFECHARS = \"0123456789\" +					// Numeric
					\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\" +	// Alphabetic
					\"abcdefghijklmnopqrstuvwxyz\" +
					\"-_.!~*'()\";					// RFC2396 Mark characters
	var HEX = \"0123456789ABCDEF\";

	var plaintext = x;
	var encoded = \"\";
	for (var i = 0; i < plaintext.length; i++ ) {
		var ch = plaintext.charAt(i);
		if (ch==\"+\") {
			encoded+=\"%2B\";
		} else if (ch == \" \") {
		    encoded += \"+\";				// x-www-urlencoded, rather than %20
		} else if (SAFECHARS.indexOf(ch) != -1) {
		    encoded += ch;
		} else {
		    var charCode = ch.charCodeAt(0);
			if (charCode > 255) {
				encoded += \"+\";
			} else {
				encoded += \"%\";
				encoded += HEX.charAt((charCode >> 4) & 0xF);
				encoded += HEX.charAt(charCode & 0xF);
			}
		}
	} // for

	return encoded;
};

function URLDecode(x)
{
   // Replace + with ' '
   // Replace %xx with equivalent character
   // Put [ERROR] in output if %xx is invalid.
   var HEXCHARS = \"0123456789ABCDEFabcdef\";
   var encoded = x;
   var plaintext = \"\";
   var i = 0;
   while (i < encoded.length) {
       var ch = encoded.charAt(i);
	   if (ch == \"+\") {
	       plaintext += \" \";
		   i++;
	   } else if (ch == \"%\") {
			if (i < (encoded.length-2)
					&& HEXCHARS.indexOf(encoded.charAt(i+1)) != -1
					&& HEXCHARS.indexOf(encoded.charAt(i+2)) != -1 ) {
				plaintext += unescape( encoded.substr(i,3) );
				i += 3;
			} else {
				alert( 'Bad escape combination near ...' + encoded.substr(i) );
				plaintext += \"%[ERROR]\";
				i++;
			}
		} else {
		   plaintext += ch;
		   i++;
		}
	} // while
   return plaintext;
};
-->
</script>";
	return $script;
}
?>