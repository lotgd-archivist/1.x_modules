<?php
module_addhook("newday");
module_addhook("footer-clan");
module_addhook("footer-popup");
module_addhook("footer-gypsy");
module_addhook("charstats");
if (!is_module_active('magicmirror')){
	if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) output("`@`bMagic Mirror Module- `&Installed.`b`n");
}else{
	if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) output("`@`bMagic Mirror Module- `&Updated.`b`n");
}
// table creation
if (!db_table_exists(db_prefix("magicmirror"))){
	$sql = "CREATE TABLE `".db_prefix("magicmirror")."` (
	  `id` int(11) NOT NULL auto_increment,
	  `place` varchar(255) NOT NULL default 'mirror',
	  `data` varchar(255) NOT NULL default '',
	  `time` int(10) NOT NULL default '1',
	  PRIMARY KEY  (`id`)
	) TYPE=MyISAM COMMENT='This holds the data for the LotGD Magic Mirror System.' AUTO_INCREMENT=1 ;";
	db_query($sql);
	output("`n`Q`b`cCreating the Magic Mirror table.`c`b`n");
}
?>