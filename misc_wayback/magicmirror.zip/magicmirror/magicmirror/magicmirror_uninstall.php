<?php
if (db_table_exists(db_prefix("magicmirror"))){
	$sql = "DROP TABLE `".db_prefix("magicmirror")."`";
	db_query($sql);
	output("`n`Q`b`cDropping the Magic Mirror table.`c`b`n");
}
output("`n`Q`b`cMagic Mirror- `&Uninstalled.`c`b`n");
?>