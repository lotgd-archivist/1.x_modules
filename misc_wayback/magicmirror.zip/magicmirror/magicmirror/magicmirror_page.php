<?php
function magicmirror_page() {
	$name=httpget("name");
	$str=httpget("str");
	$place=httpget("place");
	popup_header($name);
	rawoutput("<div id='LotGD_MagicMirrorWindow' onload='getnewLotGD_MagicMirror(0,1);' style='overflow:scroll;display:block;height:190;'>".appoencode(translate_inline("`&Type something to begin chatting.`n"))."</div>");
	rawoutput("<form name=\"LotGD_MagicMirrorform\" onSubmit='return false;'>\n<div id=\"InputForm\" class=\"inputform\">\n<Center>\n<input style=\"width: 70%;\" maxlength=200 class=text type=text size=12 name=graf onKeyDown='previewtexti();' onKeyUp='checkforenter(event);'>\n<input class=button type=button onClick=\"submitLotGD_MagicMirror()\" value=\"Submit\">\n</center>\n</div><div id='previewtexti'></div>\n</form>");
	output_notl("`n%s",stripslashes($str));
	popup_footer();
}
?>