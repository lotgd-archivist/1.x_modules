<?php
function magicmirror_statshow() {
	global $session;
	$t = translate_inline("Magic Mirror");
	$y = translate_inline("Search your Mirror...");
	$url="runmodule.php?module=magicmirror&op=mirror&place=mirror&name=".urlencode("$t")."&str=".urlencode("`^".get_module_setting("currentNote"));
	$magicmirror="<a href='$url' onClick=\"".popup($url).";return false;\" target='_blank' align='center' class=\"charinfo\" style=\"font-size:10px\">".$y."</a>";
	addcharstat("Extra Info");
	addcharstat("$t", $magicmirror);
	addnav("",$url);
	if (get_module_objpref("clans", $session['user']['clanid'], "haveSystem")==1 && get_module_setting("clanMirror")==1) {
		if ($session['user']['clanid']) {
			$str=get_module_objpref("clans", $session['user']['clanid'], "note");
			$name=get_module_objpref("clans", $session['user']['clanid'], "beenNamed");
			$url="runmodule.php?module=magicmirror&op=mirror&place=clan-{$session['user']['clanid']}&name=".urlencode("$name")."&str=".urlencode(translate_inline("Note:")." `^$str");
			addcharstat("Extra Info");
			addnav("",$url);
			$tc = translate_inline("Clan Mirror");
			$yc = translate_inline("Scan your Mirror");
			$mclan="<a href='$url' onClick=\"".popup($url).";return false;\" target='_blank' align='center' class=\"charinfo\" style=\"font-size:10px\">".$yc."</a>";
			addcharstat("$tc", $mclan);
		}
	}
}
?>