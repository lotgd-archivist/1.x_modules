<?php
require_once("lib/http.php");
function bioequip_getmoduleinfo(){
	$info = array(
		"name"=>"Bio: Show Weapon/Armor",
		"author"=>"Chris Vorndran",
		"version"=>"0.1",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Sichae/bioequip.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"This module will display the equipment of the user that's bio you are looking at. The user can turn on/off a pref to disable this viewing.",
		"settings"=>array(
			"Bio: Show Weapon/Armor Settings,title",
			"override"=>"Does Admin override the User's decision,bool|0",
				),
		"prefs"=>array(
			"Bio: Show Weapon/Armor Prefs,title",
			"user_showequip"=>"Do you wish for others to be allowed to see what armor/weapon you have equipped from your bio,bool|1",
				)
		);
	return $info;
}
function bioequip_install(){
	module_addhook("biostat");
	return true;
}
function bioequip_uninstall(){
	return true;
}
function bioequip_dohook($hookname,$args){
	global $session;
	$name = httpget('char');
	$sql = "SELECT acctid,weapon,armor FROM ".db_prefix("accounts")." WHERE login='$name'";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$weapon = $row['weapon'];
	$armor = $row['armor'];
	$id = $row['acctid'];
	switch ($hookname){
		case "biostat":
			if (get_module_pref("user_showequip","bioequip",$id) == 1 || get_module_setting("override") == 1){
			output("`^Weapon: `&%s`0",$weapon);
			output_notl("`n");
			output("`^Armor: `&%s`0",$armor);
			output_notl("`n");
		}
			break;
		}
		return $args;
	}
function bioequip_run(){
}
?>