<?php

require_once("lib/datetime.php");

function movietheater_getmoduleinfo(){
	$genrelist = "Movie Genre,enum,1,Action,2,Horror,3,Comedy,4,Sci-Fi,5,Romance,6,Indie,7,Documentary,8,Mystery";
	$info = array(
		"name"=>"Movie Theater",
		"version"=>"0.6.4",
		"author"=>"Lee Thomas<br>based on Movies (v 1.0) by Zachary Bridges ",
		"category"=>"Village",
		"download"=>"http://lotgd.escutcheonsoft.com/download/movietheater.zip",
		"settings"=>array(
			"Movie Theater - Settings,title",
			"movietheaterall"=>"Is there a movie theater in every village?,bool|1",
			"movietheaterloc"=>"If not&#44; where does the theater appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"movietheateropen"=>"What time does the theater open?`n0 = midnight`n1-11 = am`n12 = noon`n13-23 = pm,range,0,23,1|11",
			"movietheaterclose"=>"What time does the theater close?`n1-11 = am`n12 = noon`n13-23 = pm`n24 = midnight,range,1,24,1|23",
			"movietheatermatinee"=>"Is matinee pricing available until 4pm?,bool|1",
			"movieticketpricebase"=>"What is the base movie ticket price?`n`n`i(Matinee ticket base price&#44; if used&#44; is half of this amount.)`i,range,10,100,10|30",
			"movieticketpricemod"=>"What is the movie ticket price modifier (per level)?`n`n`i(Matinee ticket price modifier&#44; if used&#44; is half of this amount.)`i,range,0,200,10|20",
			"goodmodchance"=>"Percent chance of something special happening (good),range,0,50,1|20",
			"badmodchance"=>"Percent chance of something special happening (bad),range,0,50,1|20",
			"Concession Stand - Settings,title",
			"concessionitem1"=>"Menu Item #1,string|Buttered Popcorn",
			"concessionprice1"=>"Price (in gold),range,10,100,5|15",
			"concessionitem2"=>"Menu Item #2,string|Caramel Corn",
			"concessionprice2"=>"Price (in gold),range,10,100,5|20",
			"concessionitem3"=>"Menu Item #3,string|Candy",
			"concessionprice3"=>"Price (in gold),range,10,100,5|25",
			"concessionitem4"=>"Menu Item #4,string|Soda",
			"concessionprice4"=>"Price (in gold),range,10,100,5|10",
			"Screen 1 - Settings,title",
			"screen1title"=>"Movie Title,string|Troll with a Vengeance",
			"screen1genre"=>$genrelist . "|1",
			"screen1description"=>"Movie \"Trailer\" Description,textarea|Action Movie about a Troll.",
			"screen1showing"=>"Movie \"Watching\" Text,textarea|A Troll is on a Rampage through the Village.",
			"Screen 2 - Settings,title",
			"screen2title"=>"Movie Title,string|Bath-Time in Dwarf Village",
			"screen2genre"=>$genrelist . "|2",
			"screen2description"=>"Movie \"Trailer\" Description,textarea|Horror Movie about a Dwarf taking a Bath.",
			"screen2showing"=>"Movie \"Watching\" Text,textarea|A Dwarf is standing there in just a Towel.",
			"Screen 3 - Settings,title",
			"screen3title"=>"Movie Title,string|Paladin Academy VII",
			"screen3genre"=>$genrelist . "|3",
			"screen3description"=>"Movie \"Trailer\" Description,textarea|Comedy Movie about a Bunch of Goofy Paladins.",
			"screen3showing"=>"Movie \"Watching\" Text,textarea|A Bunch of Goofy Paladins create Havoc."
		),
		"prefs"=>array(
			"Movie Theater User Preferences,title",
			"matinee"=>"Is it currently matinee time,bool|0",
			"concessionbought"=>"Which Menu Item was last purchased today?,range,0,4,1|0",
		)
	);
	return $info;
}
function movietheater_install(){
	module_addhook("changesetting");
	module_addhook("newday");
	module_addhook("village");
	module_addhook("village-desc");
	return true;
}

function movietheater_uninstall(){
	return true;
}

function formatmovietime($timevalue){
	$timetemp = $timevalue;
	$returnstring = "";
	switch($timetemp){
		case 0:
		case 24:
			$timetemp = 12;
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
			$returnstring = $timetemp . " am";
			break;
		case 12:
			$timetemp = 24;
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
			$timetemp -= 12;
			$returnstring = $timetemp . " pm";
			break;
	}
	return $returnstring;
}

function movietheater_dohook($hookname,$args){
	global $session;
	$genrenames = array("","Action","Horror","Comedy","Sci-Fi","Romance","Indie","Documentary","Mystery");
	$opentime = get_module_setting("movietheateropen");
	$opentimestring = formatmovietime($opentime);
	$closetime = get_module_setting("movietheaterclose");
	$gamehour = intval(gmdate("g",gametime()));
	$theateropen = 0;
	if ($gamehour == 12)
	{
		$gamehour = 0;
	}
	if (gmdate("a",gametime()) == "pm")
	{
		$gamehour += 12;
	}
	if ($closetime < $opentime)
	{
		if ($gamehour < $closetime || $gamehour >= $opentime)
		{
			$theateropen = 1;
		}
	} else {
		if ($gamehour >= $opentime && $gamehour < $closetime)
		{
			$theateropen = 1;
		}
	}
	$screen1title = get_module_setting("screen1title");
	if (!$screen1title)
	{
		$screen1title = "Troll with a Vengeance";
		set_module_setting("screen1title", "Troll with a Vengeance");
	}
	$screen1genre = get_module_setting("screen1genre");
	if (!$screen1genre)
	{
		$screen1genre = 1;
		set_module_setting("screen1genre", 1);
	}
	$screen1description = get_module_setting("screen1description");
	if (!$screen1description)
	{
		$screen1description = "Action Movie about a Troll.";
		set_module_setting("screen1description", "Action Movie about a Troll.");
	}
	$screen1showing = get_module_setting("screen1showing");
	if (!$screen1showing)
	{
		$screen1showing = "A Troll is on a Rampage through the Village.";
		set_module_setting("screen1showing", "A Troll is on a Rampage through the Village.");
	}
	$screen2title = get_module_setting("screen2title");
	if (!$screen2title)
	{
		$screen2title = "Bath-Time in Dwarf Village";
		set_module_setting("screen2title", "Bath-Time in Dwarf Village");
	}
	$screen2genre = get_module_setting("screen2genre");
	if (!$screen2genre)
	{
		$screen2genre = 2;
		set_module_setting("screen2genre", 2);
	}
	$screen2description = get_module_setting("screen2description");
	if (!$screen2description)
	{
		$screen2description = "Horror Movie about a Dwarf taking a Bath.";
		set_module_setting("screen2description", "Horror Movie about a Dwarf taking a Bath.");
	}
	$screen2showing = get_module_setting("screen2showing");
	if (!$screen2showing)
	{
		$screen2showing = "A Dwarf is standing there in just a Towel.";
		set_module_setting("screen2showing", "A Dwarf is standing there in just a Towel.");
	}
	$screen3title = get_module_setting("screen3title");
	if (!$screen3title)
	{
		$screen3title = "Paladin Academy VII";
		set_module_setting("screen3title", "Paladin Academy VII");
	}
	$screen3genre = get_module_setting("screen3genre");
	if (!$screen3genre)
	{
		$screen3genre = 3;
		set_module_setting("screen3genre", 3);
	}
	$screen3description = get_module_setting("screen3description");
	if (!$screen3description)
	{
		$screen3description = "Comedy Movie about a Bunch of Goofy Paladins.";
		set_module_setting("screen3description", "Comedy Movie about a Bunch of Goofy Paladins.");
	}
	$screen3showing = get_module_setting("screen3showing");
	if (!$screen3showing)
	{
		$screen3showing = "A Bunch of Goofy Paladins create Havoc.";
		set_module_setting("screen3showing", "A Bunch of Goofy Paladins create Havoc.");
	}
	$menuitem1 = get_module_setting("concessionitem1");
	if (!$menuitem1)
	{
		$menuitem1 = "Buttered Popcorn";
		set_module_setting("concessionitem1", "Buttered Popcorn");
	}
	$menuitem2 = get_module_setting("concessionitem2");
	if (!$menuitem2)
	{
		$menuitem2 = "Caramel Corn";
		set_module_setting("concessionitem2", "Caramel Corn");
	}
	$menuitem3 = get_module_setting("concessionitem3");
	if (!$menuitem3)
	{
		$menuitem3 = "Candy";
		set_module_setting("concessionitem3", "Candy");
	}
	$menuitem4 = get_module_setting("concessionitem4");
	if (!$menuitem4)
	{
		$menuitem4 = "Soda";
		set_module_setting("concessionitem4", "Soda");
	}
	switch($hookname){
		case "newday":
			set_module_pref("matinee", false);
			if (get_module_setting("movietheatermatinee") && $gamehour >= $opentime && $gamehour < 16)
			{
				set_module_pref("matinee", true);
			}
			set_module_pref("concessionbought", 0);
			break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("movietheaterloc")) {
					set_module_setting("movietheaterloc", $args['new']);
				}
			}
			break;
		case "village":
			if (($session['user']['location'] == get_module_setting("movietheaterloc") || get_module_setting("movietheaterall")) && $theateropen) {
				tlschema($args['schemas']['tavernnav']);
				addnav($args['tavernnav']);
				tlschema();
				set_module_pref("matinee", false);
				if (get_module_setting("movietheatermatinee") && $gamehour >= $opentime && $gamehour < 16)
				{
					set_module_pref("matinee", true);
				}
				addnav("v?" . $session['user']['location'] . " Movie Theater","runmodule.php?module=movietheater");
			}
			break;
		case "village-desc":
			if ($session['user']['location'] == get_module_setting("movietheaterloc") || get_module_setting("movietheaterall")){
				if ($theateropen)
				{
					output("`n`&Now Showing at the " . $session['user']['location'] . " `#Movie Theater`&`n`n");
					output("`c`\$%s`& (%s)`n`@%s`& (%s)`n`!%s`& (%s)`c`n", $screen1title, $genrenames[$screen1genre], $screen2title, $genrenames[$screen2genre], $screen3title, $genrenames[$screen3genre]);
				} else {
					output("`n`c`&The `#Movie Theater`& is closed.`n");
					output("`&It will reopen at %s`c`n", $opentimestring);
				}
			}
			break;
	}
	return $args;
}

function movietheater_run() {
	global $session;
	$op = httpget('op');
	$concessionbought = httpget('cb');
	$screen = intval(httpget("screen"));
	$genrenames = array("","Action","Horror","Comedy","Sci-Fi","Romance","Indie","Documentary","Mystery");
	$genrecomments = array(
				"",
				"got all pumped up",
				"had a good scare",
				"let yourself have a good laugh",
				"used your thinker",
				"had a good cry",
				"opened your mind to new things",
				"learned something new",
				"tried to solve a good mystery"
			);
	$moviegold = get_module_setting("movieticketpricebase") + (get_module_setting("movieticketpricemod") * $session['user']['level']);
	if (get_module_pref("matinee"))
	{
		$moviegold *= .5;
	}
	$screen1title = get_module_setting("screen1title");
	if (!$screen1title)
	{
		$screen1title = "Troll with a Vengeance";
		set_module_setting("screen1title", "Troll with a Vengeance");
	}
	if (!$screen1genre)
	{
		$screen1genre = 1;
		set_module_setting("screen1genre", 1);
	}
	$screen1description = get_module_setting("screen1description");
	if (!$screen1description)
	{
		$screen1description = "Action Movie about a Troll.";
		set_module_setting("screen1description", "Action Movie about a Troll.");
	}
	$screen1showing = get_module_setting("screen1showing");
	if (!$screen1showing)
	{
		$screen1showing = "A Troll is on a Rampage through the Village.";
		set_module_setting("screen1showing", "A Troll is on a Rampage through the Village.");
	}
	$screen2title = get_module_setting("screen2title");
	if (!$screen2title)
	{
		$screen2title = "Bath-Time in Dwarf Village";
		set_module_setting("screen2title", "Bath-Time in Dwarf Village");
	}
	$screen2genre = get_module_setting("screen2genre");
	if (!$screen2genre)
	{
		$screen2genre = 2;
		set_module_setting("screen2genre", 2);
	}
	$screen2description = get_module_setting("screen2description");
	if (!$screen2description)
	{
		$screen2description = "Horror Movie about a Dwarf taking a Bath.";
		set_module_setting("screen2description", "Horror Movie about a Dwarf taking a Bath.");
	}
	$screen2showing = get_module_setting("screen2showing");
	if (!$screen2showing)
	{
		$screen2showing = "A Dwarf is standing there in just a Towel.";
		set_module_setting("screen2showing", "A Dwarf is standing there in just a Towel.");
	}
	$screen3title = get_module_setting("screen3title");
	if (!$screen3title)
	{
		$screen3title = "Paladin Academy VII";
		set_module_setting("screen3title", "Paladin Academy VII");
	}
	$screen3genre = get_module_setting("screen3genre");
	if (!$screen3genre)
	{
		$screen3genre = 3;
		set_module_setting("screen3genre", 3);
	}
	$screen3description = get_module_setting("screen3description");
	if (!$screen3description)
	{
		$screen3description = "Comedy Movie about a Bunch of Goofy Paladins.";
		set_module_setting("screen3description", "Comedy Movie about a Bunch of Goofy Paladins.");
	}
	$screen3showing = get_module_setting("screen3showing");
	if (!$screen3showing)
	{
		$screen3showing = "A Bunch of Goofy Paladins create Havoc.";
		set_module_setting("screen3showing", "A Bunch of Goofy Paladins create Havoc.");
	}
	$screentitles = array("",$screen1title,$screen2title,$screen3title);
	$screengenres = array("",$screen1genre,$screen2genre,$screen3genre);
	$screendescriptions = array("",$screen1description,$screen2description,$screen3description);
	$screenshowings = array("",$screen1showing,$screen2showing,$screen3showing);
	$menuitem1 = get_module_setting("concessionitem1");
	if (!$menuitem1)
	{
		$menuitem1 = "Buttered Popcorn";
		set_module_setting("concessionitem1", "Buttered Popcorn");
	}
	$menuitem2 = get_module_setting("concessionitem2");
	if (!$menuitem2)
	{
		$menuitem2 = "Caramel Corn";
		set_module_setting("concessionitem2", "Caramel Corn");
	}
	$menuitem3 = get_module_setting("concessionitem3");
	if (!$menuitem3)
	{
		$menuitem3 = "Candy";
		set_module_setting("concessionitem3", "Candy");
	}
	$menuitem4 = get_module_setting("concessionitem4");
	if (!$menuitem4)
	{
		$menuitem4 = "Soda";
		set_module_setting("concessionitem4", "Soda");
	}
	$snacknum = get_module_pref("concessionbought");
	$snackitem = "";
	if ($snacknum != 0)
	{
		$snackitem = get_module_setting("concessionitem" . $snacknum);
	}
	if ($op == "" || $op == "snacks" || ($op == "watch" && ($screen == "" || $screen < 1 || $screen > 3)) || $op == "ticket")
	{
		$gametime = getgametime();
		$gamehour = gmdate("g",gametime());
		if ($gamehour == 12)
		{
			$gamehour = 0;
		}
		if (gmdate("a",gametime()) == "pm")
		{
			$gamehour += 12;
		}
		$opentime = get_module_setting("movietheateropen");
		$opentimestring = formatmovietime($opentime);
		$closetime = get_module_setting("movietheaterclose");
		$closetimestring = formatmovietime($closetime);
		$theateropen = 0;
		if ($closetime < $opentime)
		{
			if ($gamehour < $closetime || $gamehour >= $opentime)
			{
				$theateropen = 1;
			}
		} else {
			if ($gamehour >= $opentime && $gamehour < $closetime)
			{
			$theateropen = 1;
			}
		}
		if ($theateropen || $op == "snacks" || $op == "watch" || $op == "ticket")
		{
			page_header($session['user']['location'] . " Movie Theater Lobby");
			output("`&`c`bWelcome to the " . $session['user']['location'] . " Movie Theater!`b`c");
			if ($op == "watch" && ($screen == "" || $screen < 1 || $screen > 3)) {
				output("`7That movie isn't playing right now. Please check the current showings.`n`n");
			} else {
				output("`7You walk into the Movies.`n`n");
			}
			output("On the wall, several posters advertise the movies which are currently showing.`n`n");
			output("`&Now Showing at the " . $session['user']['location'] . " `#Movie Theater`&`n`n");
			output("`c`\$%s`& (%s)`n`@%s`& (%s)`n`!%s`& (%s)`7`c`n`n", $screen1title, $genrenames[$screen1genre], $screen2title, $genrenames[$screen2genre], $screen3title, $genrenames[$screen3genre]);
			if ($op != "ticket")
			{
				addnav("Ticket Booth");
				addnav("Buy Ticket (`^" . $moviegold ."`0 gold)","runmodule.php?module=movietheater&op=ticket");
			}
			if ($op == "snacks")
			{
				$concessionboughtnum = (int)$concessionbought;
				if ($concessionbought == "")
				{
					output("The elf working at the concession stand smiles at you as you decide what you want.`n`n");
					output("`c`#Concession Stand Menu`n`n`\$%s`n`@%s`n`!%s`n`^%s`&`c`n`n", $menuitem1, $menuitem2, $menuitem3, $menuitem4);
				} else if ($concessionboughtnum < 1 || $concessionboughtnum > 4)
				{
					output("The concession stand elf looks at you for a moment, the points at the sign...`n`n");
					output("`c`#Concession Stand Menu`n`n`\$%s`n`@%s`n`!%s`n`^%s`&`c`n`n", $menuitem1, $menuitem2, $menuitem3, $menuitem4);
					$concessionbought = "";
				} else {
					$concessionprice = get_module_setting("concessionprice" . $concessionboughtnum);
					$concessionitem = get_module_setting("concessionitem" . $concessionboughtnum);
					if ($session['user']['gold'] >= $concessionprice)
                                        {
						$session['user']['gold'] -= $concessionprice;
						set_module_pref("concessionbought", $concessionboughtnum);
						output("`7The elf happily hands you your `&%s`7, then you head back over to the ticket booth.`n`n", $concessionitem);
					} else {
						output("With a sad look on her face, the elf reminds you that you don't have enough money for any `&%s`7.`n`n", $concessionitem);
					}
				}
				if ($concessionbought == "")
				{
					addnav("Concession Stand");
					for ($counter = 1; $counter <= 4; $counter++)
					{
						$concessionprice = get_module_setting("concessionprice" . $counter);
						$concessionitem = get_module_setting("concessionitem" . $counter);
						addnav("Buy " . $concessionitem . " (`^" . $concessionprice ."`0 gold)","runmodule.php?module=movietheater&op=snacks&cb=" . $counter);
					}
				}
			} elseif ($op == "ticket")
			{
				output("The imp working at the ticket booth smiles at you as you decide which movie to see.`n`n");
				addnav("Ticket Booth");
				addnav($screen1title,"runmodule.php?module=movietheater&op=watch&screen=1");
				addnav($screen2title,"runmodule.php?module=movietheater&op=watch&screen=2");
				addnav($screen3title,"runmodule.php?module=movietheater&op=watch&screen=3");
			} else
			{
				output("As you look around you see a concession stand off to one side, and a ticket booth to the other.`n`n");
			}
			if ($op != "snacks" && $snacknum == 0)
			{
				addnav("Concession Stand");
				addnav("Buy Snacks","runmodule.php?module=movietheater&op=snacks");
			}
		} else {
			page_header($session['user']['location'] . " Movie Theater");
			output("`&`c`bThe " . $session['user']['location'] . " Movie Theater is now closed!`b`c");
			output("`n`2When you try to enter the Movie Theater Lobby, you notice a sign on the door:`n`n");
			output("`&The time is %s`n`n", $gametime);
			output("`&Hours of operation are %s - %s`n`n", $opentimestring, $closetimestring);
		}
	} elseif ($op == "watch") {
		if ($session['user']['gold'] >= $moviegold)
		{
			$session['user']['gold'] -= $moviegold;
			page_header($screentitles[$screen]);
			output("`7You decide to see %s. It's been a while since you %s.`n`n", $screentitles[$screen], $genrecomments[$screengenres[$screen]]);
			if ($snacknum > 0)
			{
				output("You take your `&%s`7 and enter the dark movie. You LOVE `&%s`7!`n`n", $snackitem, $snackitem);
			} else {
				output("As you enter the dark movie, you smell the `&Caramel Corn`7 and the `&Buttered Popcorn`7, and you regret not stopping for some.`n`n");
			}
			output("You find your seat as the previews begin to roll...`n`n");
			for ($trailercounter = 1; $trailercounter <= 3; $trailercounter++)
			{
				if ($trailercounter != $screen)
				{
					output("`c`b`&Now Showing on Screen %u...`7`b`c`n`n", $trailercounter);
					output("`c`b`&%s`7`b`c`n`n", $screentitles[$trailercounter]);
					output("`c`b`&%s`7`b`c`n`n`n", $screendescriptions[$trailercounter]);
				}
			}
			output("And now for out Feature Presentation...`n`n");
			output("`c`b`&%s`7`b`c`n`n", $screentitles[$screen]);
			output("`c`b`&%s`7`b`c`n`n`n", $screenshowings[$screen]);
			output("Thank you. We hope you enjoyed the show. Please come again!`n`n");
			if ($snacknum > 0 && $session['user']['hitpoints'] < $session['user']['maxhitpoints'])
			{
				$snackprice = get_module_setting("concessionprice" . $snacknum);
				$randomchance = E_rand(1, 100);
				if ($randomchance <= $snackprice * 2)
				{
					$adverbstring = "";
					$randommulti = e_rand(1, 5);
					if ($session['user']['hitpoints'] >= ($session['user']['maxhitpoints'] - (int)($snackprice / $randommulti)))
					{
						$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
						$adverbstring = "`&COMPLETELY`7 ";
					} else {
						$session['user']['hitpoints'] += (int)($snackprice / $randommulti);
					}
					output("As you get up to leave, you feel %srejuvenated by your %s!`n`n", $adverbstring, $snackitem);
					debuglog("You regained some hit points from your snack at the movies");
				}
			}
			set_module_pref("concessionbought", 0);
			do_random_event($screengenres[$screen]);
		} else {
			page_header($session['user']['location'] . " Movie Theater Lobby");
			output("`7You don't have enough gold to see %s. The goblin usher stops you as you try to sneak in.`n`n", $screentitles[$screen]); 
		}
	}
	addnav("Theater Exit");
	villagenav();
	page_footer();
}

function do_random_event($moviegenre)
{
	global $session;
	$goodchance = get_module_setting("goodmodchance");
	$badchance = 100 - get_module_setting("badmodchance");
	$eventchance = e_rand(1, 100);

	if ($eventchance <= $goodchance) {
		switch ($moviegenre) {
			case 1:
				// Action
				$buff = array(
						"name"=>"`\$Adrenaline Rush",
						"rounds"=>10,
						"wearoff"=>"`\$Your adrenaline level returns to normal.",
						"atkmod"=>1.2,
						"roundmsg"=>"`\$Adrenaline courses through your veins!",
						"schema"=>"module-movietheater",
					);
				apply_buff("actionmovie", $buff);
				output("`7Watching all of that action really pumped you up.`n`n");
				output("`7You get an adrenaline rush from watching the movie!`n`n");
				debuglog("You get an adrenaline rush at the movies");
				break;
			case 2:
				// Horror
				if (is_module_active("specialtydarkarts"))
				{
					$adjectivetext = "";
					$dauses = 2;
					if ($session['user']['specialty'] == "DA")
					{
						$adjectivetext = "extra ";
						$dauses = 2 + get_module_pref("uses", "specialtydarkarts");
					}
					set_module_pref("uses", $dauses, "specialtydarkarts");
					output("`7While watching the horror movie, you realize one of the characters recited a real incantation.`n`n");
					output("`7You can use Dark Arts 2 %stimes today!`n`n", $adjectivetext);
					debuglog("You get 2 darkarts uses at the movies");
				}
				break;
			case 3:
				// Comedy
				if (is_module_active("specialtycomicrelief"))
				{
					$adjectivetext = "";
					$cruses = 2;
					if ($session['user']['specialty'] == "CR")
					{
						$adjectivetext = "extra ";
						$cruses = 2 + get_module_pref("uses", "specialtycomicrelief");
					}
					set_module_pref("uses", $cruses, "specialtycomicrelief");
					output("`7Watching the comedy improves your sense of humor.`n`n");
					output("`7You can use Comic Relief 2 %stimes today!`n`n", $adjectivetext);
					debuglog("You get 2 comicrelief uses at the movies");
				}
				break;
			case 4:
				// Sci-Fi
				output("`c`iGood Sci-Fi Event Here...`i`c`n`n");
				break;
			case 5:
				// Romance
				output("`7For showing your sensitive side, you gain a charm point!`n`n", $travelstoday);
				debuglog("You gained a charm point at the movies");
				$session['user']['charm']++;
				break;
			case 6:
				// Indie
				output("`c`iGood Indie Event Here...`i`c`n`n");
				break;
			case 7:
				// Documentary
				$travelstoday = get_module_pref("traveltoday", "cities");
				if ($travelstoday > 1)
				{
					if ($travelstoday > 3)
					{
						$travelstoday = 3;
					}
					output("`7Watching the documentary makes you feel more worldly.`n`n");
					output("You gain `&%u`7 Free Travels!`n`n", $travelstoday);
					debuglog("You gained " . $travelstoday . " free travels at the movies");
				} elseif ($travelstoday == 1)
				{
					output("`7Watching the documentary makes you feel a little more worldly.`n`n");
					output("You gain `&1`7 Free Travel!`n`n");
					debuglog("You gained a free travel at the movies");
				}
				set_module_pref("traveltoday", get_module_pref("traveltoday", "cities") - $travelstoday, "cities");
				break;
			case 8:
				// Mystery
				output("`c`iGood Mystery Event Here...`i`c`n`n");
				break;
		}
	} elseif ($eventchance > $badchance) {
		switch ($moviegenre) {
			case 1:
				// Action
				$buff = array(
						"name"=>"`\$Berserk",
						"rounds"=>10,
						"wearoff"=>"`\$Your sanity returns to normal.",
						"regen"=>-1 * $session['user']['level'],
						"roundmsg"=>"`\$You flail about wildly, causing " . $session['user']['level'] . " point" . ($session['user']['level']==1?"s":"") . " damage to yourself!",
						"schema"=>"module-movietheater",
					);
				apply_buff("actionmovie", $buff);
				output("`7Watching all of that action really pumped you up WAY too much.`n`n");
				output("`7You go berzerk from watching the movie!`n`n");
				debuglog("You go berzerk at the movies");
				break;
			case 2:
				// Horror
				if (is_module_active("specialtydarkarts"))
				{
					if ($session['user']['specialty'] == "DA")
					{
						$dauses = get_module_pref("uses", "specialtydarkarts");
						if ($dauses > 0)
						{
							$dausesmod = 2;
							if ($dauses == 1)
							{
								$dausesmod = 1;
							}
							$dauses -= $dausesmod;
							set_module_pref("uses", $dauses, "specialtydarkarts");
							output("`7While watching the horror movie, you get scared out of your wits.`n`n");
							output("`7You can use Dark Arts %u less time%s today!`n`n", $dausesmod, ($dausesmod==1?"s":""));
							debuglog("You lose " . $dausesmod . " darkarts use" . ($dausesmod==1?"s":"") . " at the movies");
						}
					}
				}
				break;
			case 3:
				// Comedy
				if (is_module_active("specialtycomedyrelief"))
				{
					if ($session['user']['specialty'] == "CR")
					{
						$cruses = get_module_pref("uses", "specialtycomicrelief");
						if ($cruses > 0)
						{
							$crusesmod = 2;
							if ($cruses == 1)
							{
								$crusesmod = 1;
							}
							$cruses -= $crusesmod;
							set_module_pref("uses", $cruses, "specialtycomicrelief");
							output("`7After watching that comedy, your jaws hurt too much to even smile.`n`n");
							output("`7You can use Comic Relief %u less time%s today!`n`n", $crusesmod, ($crusesmod==1?"s":""));
							debuglog("You lose " . $crusesmod . " comicrelief use" . ($crusesmod==1?"s":"") . " at the movies");
						}
					}
				}
				break;
			case 4:
				// Sci-Fi
				output("`c`iBad Sci-Fi Event Here...`i`c`n`n");
				break;
			case 5:
				// Romance
				output("`7For crying like a little baby, you lose a charm point!`n`n", $travelstoday);
				debuglog("You lost a charm point at the movies");
				$session['user']['charm']--;
				break;
			case 6:
				// Indie
				output("`c`iBad Indie Event Here...`i`c`n`n");
				break;
			case 7:
				// Documentary
				$args = modulehook("count-travels", array('available'=>0,'used'=>0));
				$free = max(0, $args['available'] - $args['used']);
				if ($free > 0 ) {
					output("`7Watching the documentary makes you realize just how insignificant your life really is.`n`n");
					output("You lose `&1`7 Free Travel!`n`n");
					debuglog("You lost a free travel at the movies");
					set_module_pref("traveltoday", get_module_pref("traveltoday", "cities") + 1, "cities");
				}
				break;
			case 8:
				// Mystery
				output("`c`iBad Mystery Event Here...`i`c`n`n");
				break;
		}
	}
	return true;
}
?>