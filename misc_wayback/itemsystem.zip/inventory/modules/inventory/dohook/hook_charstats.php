<?
	if (get_module_setting("withcharstats")==true) {
		$open = translate_inline("Open Inventory");
		addnav("runmodule.php?module=inventory&op=charstat");
		addcharstat("Inventory");
		addcharstat("Inventory", "<a href='runmodule.php?module=inventory&op=charstat' target='inventory' onClick=\"".popup("runmodule.php?module=inventory&op=charstat").";return false;\">$open</a>");
	}
?>