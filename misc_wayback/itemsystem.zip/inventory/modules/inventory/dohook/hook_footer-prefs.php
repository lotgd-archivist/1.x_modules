<?
	global $session, $REQUEST_URI;
	addnav("Inventar");
	addnav("Inventar anzeigen", "runmodule.php?module=inventory&user=".$session['user']['acctid']."&login=".$session['user']['login']."&return=".URLEncode($_SERVER['REQUEST_URI']));
?>