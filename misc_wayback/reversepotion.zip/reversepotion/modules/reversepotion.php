<?php
/*
Details:
 * This allows users to buy potions that return you to your home city after a while
History Log:
 * Version 1.0:
  o Seems Stable
 * Version 1.1:
  o Textual fix
 * Version 1.2:
  o Textual fix
 * Version 1.3:
  o Now uses the 'potionshop' module
*/
require_once("lib/commentary.php");
require_once("lib/villagenav.php");

function reversepotion_getmoduleinfo(){
	$info = array(
		"name"=>"Reverse Potions",
		"version"=>"1.3",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/reversepotion.zip",
		"settings"=>array(
			"Reverse Potions - Settings,title",
			"revbuy"=>"Allow users to buy reverse potions?,bool|1",
			"tLast"=>"Time for potions to last (realtime minutes)?,range,1,120,1|10",
			"pCost"=>"Cost of reverse potions?,int|1500",
			"adminPotion"=>"Admin have unlimited access to reverse potions?,bool|1",
			"(admin are those that can edit users),note",
			"ffReset"=>"Amount of forest fights to lose when your potion wears off?,int|0",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"revPot"=>"Reverse potions?,int|0",
			"secLast"=>"To last?,int|0",
			"start"=>"Started?,int|0",
			"usPot"=>"Is using a reverse potion?,bool|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
		),
	);
	return $info;
}

function reversepotion_install(){
	if (!is_module_active('reversepotion')) {
		output("`n`Q`b`cInstalling Reverse Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Reverse Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	module_addhook("village");
	module_addhook("forest");
	module_addhook("header-inn");
	module_addhook("header-gardens");
	module_addhook("header-gypsy");
	module_addhook("header-healer");
	module_addhook("header-armor");
	module_addhook("header-weapons");
	module_addhook("header-rock");
	module_addhook("header-stables");
	return true;
}

function reversepotion_uninstall(){
	output("`n`Q`b`cUninstalling Reverse Potions Module.`c`b`n");
	return true;
}

function reversepotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('revPot')>0) {
					output("`n`^You have `@%s`^ Reverse Potions...`n",get_module_pref('revPot'));
				}
			}
		break;
		case "charstats":
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
				set_module_pref('revPot',1);
			}
			if (get_module_pref('usPot')==1) {
				$potion = "";
				$x = 0;
				$b = translate_inline("Reverse Potion - Mindpower");
				$vloc = array();
				$vname = getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] = "village";
				$vloc = modulehook("validlocation", $vloc);
				if (is_module_active('newbieisland')) {
					$t = get_module_setting('villagename','newbieisland');
					unset($vloc[$t]);
				}
				ksort($vloc);
				reset($vloc);
				$i = explode(',',get_module_setting('notAllowed'));
				foreach ($i as $val) {
					if ($val!='') {
						if (isset($vloc[$val])) unset($vloc[$val]);
					}
				}
				$c = translate_inline("Mind Power cannot be used here.");
				foreach($vloc as $loc=>$val) {
					$x++;
					if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "superuser")) {
						$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
						$potion .="<img src=\"./images/reversepotion/powerclear.gif\" title=\"$b\" alt=\"$b\" style=\"border:0;\">";
						$potion .="</div>";
					} else {
						$b = translate_inline("Mind Power for %s");
						$b = str_replace('%s',$loc,$b);
					  	if ($session['user']['location']!=$loc) {
						  	$c=translate_inline("Summon power for ").$loc;
						  	$c=str_replace("'","\'",$c);
						  	$c=str_replace('"','\"',$c);
						  	$stuff="<a border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=reversepotion&op=use&w=".urlencode($loc)."\"><img src=\"./images/reversepotion/power.gif\" title=\"$b\" alt=\"$b\" style=\"border:0;\"></a>";
						  	addnav("","runmodule.php?module=reversepotion&op=use&w=".urlencode($loc));
					  	} else {
						  	$c=translate_inline("Your current location");
						  	$stuff="<a border='0' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=reversepotion&op=use&w=".urlencode($loc)."\"><img src=\"./images/reversepotion/powerclear.gif\" title=\"$b\" alt=\"$b\" style=\"border:0;\"></a>";
					  	}
					  	$potion.=$stuff;
						if ($x>=3) {
							$x=0;
							$potion.="\n<br/>";
						}
					}
				}
				addcharstat("Vital Info");
				addcharstat("Reverse Potion Info",reversepotion_left());
			} else {
				if (get_module_pref('revPot')>0) {
					$potion="";
					$c = translate_inline("Reverse potions cannot be used here");
					if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "superuser")) {
						$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
						$potion .="<img src=\"./images/reversepotion/potionclear.gif\" title=\"$c\" alt=\"$c\" style=\"border:0;\">";
						$potion .="</div>";
					} else {
						$x = get_module_pref('revPot');
						$y = 0;
						$c = translate_inline("Drink the reverse potion...");
						while ($x>0) {
							$y++;
							$x--;
							$potion.="<a border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=reversepotion&op=start\"><img src=\"./images/reversepotion/potion.gif\" title=\"$c\" alt=\"$c\" style=\"border:0;\"></a>";
							addnav("","runmodule.php?module=reversepotion&op=start");
							if ($y>=3) {
								$y=0;
								$potion.="\n<br/>";
							}
						}
					}
				} else {
					$potion="";
				}
			}
			addcharstat("Click and use Items");
			if ($potion!="") addcharstat("Reverse Potions", $potion);
		break;
		case "potionshop-list":
			if (get_module_setting('revbuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$rev=array();
				$rev['gold']=$price;
				$rev['avail']=translate_inline("In Stock");
				$rev['nav']=translate_inline("Buy a `@Reverse`0 Potion");
				$rev['effects']=translate_inline("Allows you to buy a potion that lasts %s 'outsider' minutes, that can take you from town to town.");
				$rev['effects']=str_replace('%s',get_module_setting('tLast'),$rev['effects']);
				$rev['link']="runmodule.php?module=reversepotion&op=shop";
				$rev['name']=translate_inline("Reverse Potions");
				$args[]=$rev;
			}
		break;
		default:
			if (get_module_pref('usPot')==1&&$session['user']['alive']==1) {
				if (reversepotion_check()===true) {
					redirect("runmodule.php?module=reversepotion&op=end","Reverse Potion Finished");
				}
			}
		break;
	}
	return $args;
}

function reversepotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "start":
			page_header("You drink a potion..");
			set_module_pref('usPot',1);
			set_module_pref('revPot',get_module_pref('revPot')-1);
			villagenav();
			$secs = get_module_setting('tLast')*60;
			set_module_pref('secLast',$secs);
			set_module_pref('start',time());
			output("`@Gulping down a potion that feels as cold as ice.. your vision distorts, shattering into a thousand tiny falling pieces.`nYou seem to be falling backwards into an eternal pit of empty blackness, cold as the grave..`nA bright spark appears in front of you, elusively beckoning.. what is this power, strong enough to banish the dark..`nYour memory returns.. it must be the magical energy of the potion you drank.. your mind feels strong enough to move wherever ye must...");
			page_footer();
		break;
		case "use":
			$w = httpget('w');
			$vloc = array();
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$vloc[$vname] = "village";
			$vloc = modulehook("validlocation", $vloc);
			if (is_module_active('newbieisland')) {
				$t = get_module_setting('villagename','newbieisland');
				unset($vloc[$t]);
			}
			if (isset($vloc[$w])) {
				$session['user']['location']=$w;
				page_header("Power of mind..");
				output("`@Feeling the power of your mind, enhanced with magical energy from that yet great potion, you reach for the darkness, melding it into a bridge, to step to another realm, as easily as walking from one stone to yet another.");
				addnav("Ford the Black Bridge","village.php");
			} else {
				page_header("Lost yet found..");
				output("`@Probing the power of your mind, melded with magical energy from that yet great potion, you wrench for the darkness, yet nothing stirs.. what could this then be?");
				output("`n`n`@`c`bYou haven't moved..`b`c");
				villagenav();
			}
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('revPot',get_module_pref('revPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing `^%s`@ gold to %s, he slowly moves to a shelf, and, with great difficulty, removes a sparkling potion bottle..`n`3\"`&Take this within a village, and ye can use the power of yer mind to move to any village... for %s minutes in the time of the outsiders, ye should know what that is, player of my world... after the %s minutes, ye will be sprung to yer home city with a bit of damage, not enough teh kill, no matter what ye were doing..`3\"",$price,"`#CortalUX`@",get_module_setting('tLast'),get_module_setting('tLast'));
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
		case "end":
			page_header("Ouch!!!");
			if (is_module_active("cities")) {
				$session['user']['location'] = get_module_pref("homecity","cities");
				// We don't need to change the users location if the cities module is not installed
			}
			$am=$session['user']['hitpoints']/2;
			if ($am<=0) $am=1;
			$session['user']['hitpoints']=round($am);
			output("`@Walking onwards, a great rip appears in the air around you, seemingly trying to wrench the skin from your bones, with air as cold as the deepest well..`nColours pale, senses fade.. your mind loses power, and yet cannot let go.. your mind that holds the power is wrenched away, and you lose half your hitpoints... you are home.");
			$x = get_module_setting('ffReset');
			if ($x>0) {
				$session['user']['turns']-=$x;
				if ($session['user']['turns']<=0) $session['user']['turns']=0;
				output("`nSlowed by this, you lose %s turns.",$x);
			}
			set_module_pref('usPot',0);
			villagenav();
			page_footer();
		break;
	}
}

function reversepotion_check() {
	$lasts = get_module_pref('secLast');
	$start = get_module_pref('start');
	$time = time();
	$end = $start+$lasts;
	if ($time>=$end) return true; // If it's later than when it should end, return true.
	$time = date("h:i",time());
	$end = date("h:i",get_module_pref('start')+get_module_pref('secLast')); // We don't tell the user the seconds, so we act on the minutes
	if ($time==$end) return true;
	return false;
}

function reversepotion_left() {
	$lastm = date("i",get_module_pref('secLast'));
	$lasth = date("g",get_module_pref('secLast'));
	$minutes = translate_inline(" minutes");
	$hours = translate_inline(" hours");
	$minute = translate_inline(" minute");
	$hour = translate_inline(" hour");
	$wordm=$minutes;
	if ($lastm==1) $wordm=$minute;
	$wordh=$hours;
	if ($lasth==1) $wordh=$hour;
	$string="";
	if ($lasth!=0) $string=$lasth.$wordh;
	if ($lasth!=0&&$lastm!=0) $string.=translate_inline(" and");
	if ($lastm!=0) $string.=" ".$lastm.$wordm;
	$start = date("h:i",get_module_pref('start'));
	$time = date("h:i",time());
	$end = date("h:i",get_module_pref('start')+get_module_pref('secLast'));
	$string = translate_inline("`&Reverse Potions last `^").$string.translate_inline(" `&, you took yours at `^").$start.translate_inline("`&, the time is `^").$time.translate_inline("`&, so your reverse power will end at `^").$end."`&.";
	return $string;
}
?>