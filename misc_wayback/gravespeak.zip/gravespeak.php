<?php

//Adapted some code for the multiple village selection from the scry.php

require_once("lib/commentary.php");
function gravespeak_getmoduleinfo(){
	$info = array(
		"name"=>"Grave Speak",
		"author"=>"Chris Vorndran",
		"version"=>"0.9",
		"category"=>"Graveyard",
		"download"=>"http://dragonprime.net/users/Sichae/gravespeak.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows for dead players to be able to speak to the living.",
		"settings"=>array(
			"Grave Speak Settings,title",
			"cost"=>"Cost to speak from dead to living `iin favor`i,int|30",
			"take"=>"Does access get taken away after one visits the commentary area,bool|0",
		),
		"prefs"=>array(
			"Grave Speak Prefs,title",
			"access"=>"Does this user have access to talk to the living,bool|0",
		)
		);
	return $info;
}
function gravespeak_install(){
	module_addhook("ramiusfavors");
	module_addhook("footer-shades");
	module_addhook("newday");
	return true;
}
function gravespeak_uninstall(){
	return true;
}
function gravespeak_dohook($hookname,$args){
	global $session;
	$op = httpget('op');
	$cost = get_module_setting("cost");
	$access = get_module_pref("access");
	switch ($hookname){
		case "ramiusfavors":
				if ($session['user']['deathpower'] >= $cost){
					addnav("Ramius Favors");
					addnav(array("Access Mortal Realm (%s Favor)",$cost),"runmodule.php?module=gravespeak&op=purchase");
				}
				break;
		case "footer-shades":
			if ($access == 1){
				addnav("Places");
				addnav("Speak to the Living","runmodule.php?module=gravespeak&op=changeup");
				}
				break;
		case "newday":
			if ($access == 1){
				set_module_pref("access",0);
			}
			break;
		}
	return $args;
}
function gravespeak_run(){
	global $session;
	addcommentary();
	$op = httpget('op');
	$area = httpget("area");
	$village = httpget("village");
	$cost = get_module_setting("cost");
	$access = get_module_pref("access");
	$city = getsetting("villagename", LOCATION_FIELDS);
	page_header("Graveyard Speaking");
	switch ($op){
		case "purchase":
			if (get_module_pref("access") == 0){
			output("`\$Ramius looks at you with a smirk.");
			output(" \"`)So, you have such a longing for the Living Realm, that you chose to come to me?`\$\"");
			output(" He grins and traces a finger down his cheek.");
			output(" \"`)Well, I guess this can be arranged, for `&%s Favor`).`\$\"`n`n",$cost);
			output("Ramius walks up to you and hands you a small coupon, and then steals away `&%s Favor`\$.",$cost);
			output("He then points towards the Shades, \"`)There is where you shall find your link to the Living World.`\$\"");
			if (get_module_setting("take") == 1){
				output("`n`n`\$Ramius notes that once you go into this commentary area, your access shall be revoked, and you must purchase a new pass.");
			}
			$session['user']['deathpower']-=$cost;
			$access++;
			set_module_pref("access",$access);
		}else{
			output("`\$Ramius looks at you and arches a brow.");
			output(" \"`)You have already purchased your pass to the real world... why do you come back here?`\$\"");
			output("He points towards the Shades.");
		}
		break;
		case "changeup":
			if (is_module_active("cities")){
				output("`\$Ramius appears next to you and arches a brow.");
				output(" \"`)To which city do you wish to speak?`\$\"");
				$vloc = array();
				$vname = getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] = "village";
				$vloc = modulehook("validlocation", $vloc);
				ksort($vloc);
				reset($vloc);
				foreach($vloc as $loc=>$val) {
					addnav("Projecting");
					addnav(array("Project in %s", $loc), "runmodule.php?module=gravespeak&op=speak&area=".htmlentities($val)."&village=".htmlentities($loc));
			}
			}else{
				if (get_module_setting("take") == 1){
					set_module_pref("access",0);
				}
				output("`\$While staring into the mortal realm, you are able to make out the people of %s:`n`n",$city);
				viewcommentary("village","Project",25,"speaks from beyond");
			}
			break;
		case "speak":
			if (get_module_setting("take") == 1){
			set_module_pref("access",0);
			}
			output("`\$While staring into the mortal realm, you are able to make out the people of %s:`n`n", $village);
			viewcommentary($area,"Project",25,"speaks from beyond");
			break;
	}
	addnav("Return");
	addnav("Return to the Shades","shades.php");
	addnav("Return to the Graveyard","graveyard.php");
page_footer();
}
?>