<?php
require_once("lib/commentary.php");

function dc_getmoduleinfo(){
	$info = array(
		"name"=>"Dead City",
		"author"=>"Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Graveyard",
		"download"=>"http://dragonprime.net/users/Sichae/dc.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Adds something fun for the Graveyard. A city in which a player can drink and other things. Provides three hooks, so that other modules can hook here.",
		"settings"=>array(
			"Dead City Settings,title",
			"dk"=>"How many dragonkills are needed before the dead city becomes active?,int|5",
			"pcost"=>"Cost for a poe (`iin favor`i),int|5",
			"vname"=>"Name of the dead city,text|Wolfenstein",
			"iname"=>"Name of the Tavern,text|Ghouls and Goblies",
			"dval"=>"Drunkeness value before no more is allowed?,int|60",
		),
		"prefs"=>array(
			"Dead City Prefs,title",
			"poe"=>"Has this users rented a Poe?,bool|0",
			"poe-color"=>"Color of the Poe and it's text,text|`Q",
			"booned"=>"Was the player booned by Esmerelda today?,bool|0",
		),
		"requires"=>array(
			"drinks"=>"Exotic Drinks, part of Core Download",
		),
	);
	return $info;
}
function dc_install(){
	module_addhook("footer-shades");
	module_addhook("newday");
	module_addhook("moderate");
	return true;
}
function dc_uninstall(){
	return true;
}
function dc_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "footer-shades":
			if ($session['user']['dragonkills'] >= get_module_setting("dk")){
				addnav("Places");
				addnav(array("Journey to %s",get_module_setting("vname")),"runmodule.php?module=dc&op=enter");
			}
			break;
		case "newday":
			if ($session['user']['alive'] != true || get_module_pref("poe")){
				output("`n`)Your poe wanders away from you...`0");
				set_module_pref("poe",0);
			}
			set_module_pref("booned",0);
			break;
		case "moderate":
			$args['dc-kfield'] = "Dead City - The Killing Fields";
			break;
		}
	return $args;
}
function dc_run(){
	global $session;
	checkday();
	addcommentary();
	$op = httpget('op');
	$ch = httpget('ch');
	$pcost = get_module_setting("pcost");
	$city = get_module_setting("vname");
	$pc = get_module_pref("poe-color");
	$dr = get_module_pref("drunkeness","drinks");
	$order = httpget('order');
	page_header(array("%s",$city));
	switch ($op){
		case "enter":
			output("`)Wandering into the dead city, a shiver runs down your spine.");
			output("You feel as if there are spirits looming around you... as you are one of their kind.");
			output("Around you, small Poes are circling around the city, carrying lanterns.");
			output("You take your next step, looking up into the dismal sky.");
			output("\"`7Dark... it always has to be so dark down here...`)\"");
			if (!get_module_pref("poe")){
				addnav(array("Rent a Poe (%s Favor)",$pcost),"runmodule.php?module=dc&op=poe");
			}else{
				output("`n`n`)Your Poe races over to you and bows.");
				output("It flicks on it's little lantern, allowing you to see all of the shoppes around.");
				addnav("Gray Avenue");
				addnav("The Gypsy's Tent","runmodule.php?module=dc&op=gypsy");
				modulehook("dc-gray");
				addnav("Black Terrace");
				addnav("Killing Fields","runmodule.php?module=dc&op=kfield");
				modulehook("dc-black");
			}
			addnav("Leave");
			addnav("Return to the Shades","shades.php");
			break;
		case "poe":
			switch ($ch){
				case "":
					output("`)A gigantic Poe drifts over to you and in a loud bellow, it begins to speak.");
					output("\"`\$So... ye wish to rent a Poe? They serve as a good source of light, for navigating %s.`)\"",$city);
					addnav("Yes","runmodule.php?module=dc&op=poe&ch=yes");
					addnav("No","runmodule.php?module=dc&op=poe&ch=no");
					break;
				case "yes":
					if ($session['user']['deathpower'] >= $pcost){
						$c = array(1=>"`6","`\$","`3","`2","`7","`)","`Q");
						$o = e_rand(1,count($c));
						set_module_pref("p-color",$c[$o]);
						output("`)A tiny %sPoe `)rushes to your side.",$pc);
						output("\"%sGlad to be at ye're service matey!`)\"",$pc);
						set_module_pref("poe",1);
						output("`n`n`)The gigantic Poe floats to you, and places his lantern to the small of your back.");
						$session['user']['deathpower']-=$pcost;
						debuglog("traded $pcost favor for a poe in the Dead City");
						output("You feel an intense heat, as you lose `\$%s `)Favor.",$pcost);
						output("\"`\$'Tis a fine Poe ye got there... I hope it serves ye well...`)\"");
					}else{
						output("`)The Gigantic Poe looms over you and points you to the `7Graveyard`).");
					}
					break;
				case "no":
					output("`)The gigantic poe simple shakes a little bit and drifts away.");
					output("You shrug it off, and depart for the city.");
					break;
				}
			break;
		case "gypsy":
			page_header("The Gypsy's Tent");
			output("`)Your Poe walks you in, and begins to dictate.");
			output("\"%sThis is the house of `@Esmerelda%s, the Idoliter.",$pc,$pc);
			output("She was placed down here, due to her transgressions against `\$Ramius%s.",$pc);
			output("She had tried to launch a war against her, but was unsuccessful.`)\"");
			output("`n`nOut from the shadows, `@Esmerelda`) appears.");
			output("Her eyes dash about, and they land on you...");
			if (!get_module_pref("booned")){
				set_module_pref("booned",1);
				switch (e_rand(1,4)){
					case 1:
						if ($session['user']['gravefights']){
							$session['user']['gravefights']--;
							output("`2Out of pure fear, you lose a torment!");
							debuglog("lost a torment to Esmerelda");
						}else{
							$fl = e_rand(1,10);
							output("`@Esmerelda `)presses her finger to your forehead, and you lose `\$%s `)Favor.",$fl);
							$session['user']['deathpower']-=$fl;
							debuglog("lost $fl favor to Edmerelda");
						}
						break;
					case 2:
						output("`@Esmerelda `)smiles, \"`2I like your candor... here...`)\"");
						output("She taps your chest, and you receive `\$1 `)Torment.");
						$session['user']['gravefights']++;
						debuglog("gained one torment from Esmerelda.");
						break;
					case 3:
						output("`@Esmerelda's `)eyes go wide.");
						output("\"`2Ye are in league with Ramius!`)\"");
						output("She pushes you over, and you are injured badly...");
						$session['user']['soulpoints']=1;
						debuglog("lost most soulpoints due to Esmerelda pushing over.");
						break;
					case 4:
						output("`@Esmerelda `)looks you over.");
						output("She shrugs, and hits your poe... making it vanish.");
						set_module_pref("poe",0);
						break;
					}
				}else{
					output("`@Esmerelda `)just glances a smile, before returning to her masterwork.");
				}
			break;
		case "kfield":
			page_header("The Killing Fields");
			output("`)Your Poe smiles, as he begins to teach you about the dead city.");
			output("\"%sThe life of a soldier is short.",$pc);
			output("They go off to battle, and most are never seen again.");
			output("They all end up here, in the Killing Fields.");
			output("The final resting place for all warriors.`)\"`n`n");
			viewcommentary("dc-kfield","Ask advice of the fallen warriors",15,"speaks");
			addnav("Ghoulish Haunts");
			addnav(array("%s",get_module_setting("iname")),"runmodule.php?module=dc&op=tav");
			modulehook("dc-ghoul");
			break;
		case "tav":
			page_header(array("%s",get_module_setting("iname")));
			if ($order == ""){
				output("`)You walk into a small, dank, damp tavern that is only lit by a few lantern-carrying poes.");
				output("You mosey on over to the bar and bang your fist down, \"`3What does a dead person have to do to get a friggin' drink around here?`)\"");
				output("The bartender floats on over to you and asks you, \"`#Name yer poison!`)\"");
				if ($dr > get_module_setting("dval")){
					output("`n`n`)The bartender looks down at you, as you bang your mug on the counter.");
					output("\"`#I be sorry, but I cannae be servin' ya any more...`)\"");
				}else{
					addnav("Ghoulish Brew","runmodule.php?module=dc&op=tav&order=brew");
					addnav("Blood Bath","runmodule.php?module=dc&op=tav&order=blood");
					addnav("Fires of Hell","runmodule.php?module=dc&op=tav&order=foh");
				}
			}else{
				switch ($order){
					case "brew":
						output("`)The bartender brings over your `7Ghoulish Brew`), and bangs it down in front of you.");
						output("You nod to him and tip your head back, as all the brew slides down your throat.");
						output("You smile, set your mug down, wipe your chin and head out... feeling a little bit more drunk.");
						break;
					case "blood":
						output("`)The bartender sets down your `\$Blood Bath`), and walks away.");
						output("You quickly down the drink, and your eyes go wide for a second.");
						output("Your fingers begin to tingle, as you feel a bit more happy.");
						break;
					case "foh":
						output("`)The bartender sets down your `\$F`4i`^r`&e`)s of Hell, and wipes his own brow.");
						output("You grin as you down the entire thing, your esophogus burning.");
						output("You jerk around a bit and fall to the floor, waking up moments later.");
						break;
				}
				$v = e_rand(1,20);
				set_module_pref("drunkeness",$dr+$v,"drinks");
				if ($dr < get_module_setting("dval")) addnav("Return to the Counter","runmodule.php?module=dc&op=tav");
			}
			break;
	}
	addnav("Leave");
	if ($op != "enter") addnav(array("Return to %s",$city),"runmodule.php?module=dc&op=enter");
page_footer();
}
?>