<?php
/*
Details:
 * This allows users to buy recharge potions for their skills
History Log:
 * Version 1.0
  o Seems Stable
 * Version 1.1
  o Fixed image
 * Version 1.2:
  o Now uses the 'potionshop' module
*/
require_once("lib/commentary.php");
require_once("lib/villagenav.php");

function rechargepotion_getmoduleinfo(){
	$info = array(
		"name"=>"Recharge Potions",
		"version"=>"1.2",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/rechargepotion.zip",
		"allowanonymous"=>true,
		"override_forced_nav"=>false,
		"settings"=>array(
			"Recharge Potions - Settings,title",
			"recbuy"=>"Allow users to buy recharge potions?,bool|1",
			"pCost"=>"Cost of recharge potions?,int|1500",
			"adminPotion"=>"Admin have unlimited access to recharge potions?,bool|1",
			"(admin are those that can edit users),note",
			"Recharge Potions - Location Settings,title",
			"recbuyloc"=>"Allow users to buy recharge potions from ALL cities?,bool|1",
			"recbuylocw"=>"If no- then which one?,location|".getsetting("villagename", LOCATION_FIELDS),
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"recPot"=>"Recharge potions?,int|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
		),
	);
	return $info;
}

function rechargepotion_install(){
	if (!is_module_active('rechargepotion')) {
		output("`n`Q`b`cInstalling Recharge Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Recharge Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	return true;
}

function rechargepotion_uninstall(){
	output("`n`Q`b`cUninstalling Recharge Potions Module.`c`b`n");
	return true;
}

function rechargepotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('recPot')>0) {
					output("`n`^You have `@%s`^ Recharge Potions...`n",get_module_pref('recPot'));
				}
			}
		break;
		case "charstats":
			$potion="";
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
				set_module_pref('recPot',1);
			}
			if (get_module_pref('recPot')>0) {
				$c = translate_inline("Recharge Potions cannot be used here");
				if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "forest")&&!strstr($SCRIPT_NAME, "superuser")||$session['user']['specialinc']!=""&&$session['user']['specialmisc']!="") {
					$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
					$potion .="<img src=\"./images/rechargepotion/potionclear.gif\" title=\"$c\" alt=\"$c\">";
					$potion .="</div>";
				} else {
					$x = get_module_pref('recPot');
					$y = 0;
					$c = translate_inline("Drink the Recharge Potion...");
					while ($x>0) {
						$y++;
						$x--;
						$potion.="<a style='border:0;' border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=rechargepotion&op=use\"><img src=\"./images/rechargepotion/potion.gif\" style='border:0;' title=\"$c\" alt=\"$c\"></a>";
						addnav("","runmodule.php?module=rechargepotion&op=use");
						if ($y>=3) {
							$y=0;
							$potion.="\n<br/>";
						}
					}
				}
			}
			addcharstat("Click and use Items");
			if ($potion!="") addcharstat("Recharge Potions", $potion);
		break;
		case "potionshop-list":
			if (get_module_setting('recbuyloc')==0&&get_module_setting('hook','potionshop')==1) set_module_setting('recbuyloc',0);
			if (get_module_setting('recbuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$rec=array();
				$rec['gold']=$price;
				$rec['name']=translate_inline("Recharge Potions");
				if (get_module_setting('recbuy')==1&&get_module_setting('recbuyloc')==1||get_module_setting('recbuy')==1&&get_module_setting('recbuyloc')==1&&$session['user']['location']==get_module_setting('recbuylocw')) {
					$rec['link']="runmodule.php?module=rechargepotion&op=shop";
					$rec['avail']=translate_inline("In Stock");
					$rec['avail']=str_replace('%s',get_module_setting('recbuylocw'),$rec['avail']);
				} else {
					$rec['avail']=translate_inline("Only available in %s..");
					$rec['link']="";
				}
				$rec['nav']=translate_inline("Buy a `^Recharge`0 Potion");
				$rec['effects']=translate_inline("Recharges your innate skills.");
				$args[]=$rec;
			}
		break;
	}
	return $args;
}

function rechargepotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			require_once('lib/increment_specialty.php');
			page_header("You gulp a potion..");
			set_module_pref('recPot',get_module_pref('recPot')-1);
			villagenav();
			output("`@You drink a flaming red potion that burns your lungs.. searing your bones, as they turn to molten lead.. enhancing your natural skills..");
			increment_specialty($session['user']['specialty']);
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('recPot',get_module_pref('recPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing %s gold to %s, he hands you a potion, \"`&This is a recharge potion.. I explained it te yeh already..`3\"",$price,"`#CortalUX`@");
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
	}
}
?>