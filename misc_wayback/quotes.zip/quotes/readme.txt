Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Speech-bubble image by:
sixf00t4

Q image by:
CortalUX

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a quotes module for LotGD 0.9.8.
It allows you to add random quotes, and choose
where they appear.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy 'quotes.php' into your Modules folder.
Copy 'quotes.png' into your Images folder.
Copy 'quotes.gif' into your Images folder.
Login to the Superuser Grotto and Install / Activate it.
You can change the placement of the quotes in the Grotto.
All users that can edit users can add quotes.
All other users must have the preference set
in the Grotto.
You can then add quotes either in the editor,
one by one, from the commentary (through the
button), or from the commentary list in the
quotes editor.