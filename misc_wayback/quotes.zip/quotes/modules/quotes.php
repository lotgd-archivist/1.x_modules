<?php
/*
Details:
 * This allows you to show Random Quotes
History Log:
 v1.0:
 o Seems to be Stable
 v1.1:
 o Fixed bug with Apostrophes
 v1.2:
 o Deleted unneeded code
 v1.3:
 o Added a feature to put stuff right in from commentary
 v1.4:
 o Added an easier delete function (B)
 v1.5:
 o Fixed a bug with delete function A
 o Fixed a bug with the edit function
 v1.6:
 o Added a 'Q' button next to names in commentary
 v1.7:
 o Now has two Quote images.. use the one you prefer
 o Image 2 (.gif) designed by Sixf00t4
 v1.8:
 o Now uses the new 'check_' preferences code
 o Fixed a bug with HTMLEntities
*/
require_once("lib/commentary.php");
require_once("lib/sanitize.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function quotes_getmoduleinfo(){
	$info = array(
		"name"=>"Random Quotes",
		"version"=>"1.8",
		"author"=>"`@CortalUX",
		"category"=>"General",
		"override_forced_nav"=>true,
		"download"=>"http://dragonprime.net/users/CortalUX/quotes.zip",
		"settings"=>array(
			"Quotes - General,title",
			"footer"=>"Show on the Footer of pages,bool|1",
			"header"=>"Show on the Header of pages,bool|0",
			"Quotes - Where,title",
			"epage"=>"Show on every page?,bool|1",
			"(these only applies if you don't want quotes to display on every page:),note",
			"index"=>"Show on index page?,bool|1",
			"village"=>"Show in the village?,bool|1",
			"shades"=>"Show in the shades?,bool|1",
			"Quotes - Other,title",
			"(this is how the quotes are stored in your DB),note",
			"(you edit these in the.. editor at the bottom of the page- no way to edit them here),note",
			"quotes"=>"Quotes?,viewonly|",
		),
		"prefs"=>array(
			"Quotes - Preferences,title",
			"canadd"=>"Can this user add quotes?,bool|0",
			"(overridden- all SU_EDIT_USER admin can do this),note",
			"user_squotes"=>"Show Random Quotes?,bool|1",
			"check_img"=>"Speech-bubble image or Q image?,enum,0,Speech-bubble (.gif),1,Q Image (.png),3,I don't want to see any image|1",
		),
	);
	return $info;
}

function quotes_install(){
	if (!is_module_active('quotes')){
		output("`n`c`b`QQuotes Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QQuotes Module - Updated`0`b`c");
	}
	module_addhook("everyfooter");
	module_addhook("shades");
	module_addhook("village");
	module_addhook("footer-home");
	module_addhook("everyheader");
	module_addhook("header-shades");
	module_addhook("header-village");
	module_addhook("header-home");
	module_addhook("superuser");
	module_addhook("viewcommentary");
	module_addhook("checkuserpref");
	return true;
}

function quotes_uninstall(){
	output("`n`c`b`QQuotes Module - Uninstalled`0`b`c");
	return true;
}
	
function quotes_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	$s = false;
	if ($hookname=='viewcommentary') {
		if ($session['user']['superuser']&SU_EDIT_USERS||get_module_pref('canadd')==1) {
			$x = translate_inline("Quote This");
			$quote = $args['commentline'];
			addnav("runmodule.php?module=quotes&op=csave&q=".urlencode($quote));
			if (get_module_pref('check_img')==1) $args['commentline']="<a target='_blank' alt='$x' href='runmodule.php?module=quotes&op=csave&author=".urlencode($name)."&q=".urlencode($quote)."' onClick=\"".popup("runmodule.php?module=quotes&op=csave&q=".urlencode($quote)).";return false;\"><img border='0' src=\"images/quotes.png\"/></a> ".$args['commentline'];
			if (get_module_pref('check_img')==0) $args['commentline']="<a target='_blank' alt='$x' href='runmodule.php?module=quotes&op=csave&author=".urlencode($name)."&q=".urlencode($quote)."' onClick=\"".popup("runmodule.php?module=quotes&op=csave&q=".urlencode($quote)).";return false;\"><img border='0' src=\"images/quotes.gif\"/></a> ".$args['commentline'];
		}
	}
	if (get_module_setting('header')==1) {
		switch ($hookname) {
			case "everyheader":
				if (get_module_setting('epage')==1) $s = true;
			break;
			case "header-shades":
				if (get_module_setting('epage')==0&&get_module_setting('shades')==1) $s = true;
			break;
			case "header-village":
				if (get_module_setting('epage')==0&&get_module_setting('village')==1) $s = true;
			break;
			case "header-home":
				if (get_module_setting('epage')==0&&get_module_setting('index')==1) $s = true;
			break;
		}
	}
	if (get_module_setting('footer')==1) {
		switch ($hookname) {
			case "everyfooter":
				if (get_module_setting('epage')==1) $s = true;
			break;
			case "shades":
				if (get_module_setting('epage')==0&&get_module_setting('shades')==1) $s = true;
			break;
			case "village":
				if (get_module_setting('epage')==0&&get_module_setting('village')==1) $s = true;
			break;
			case "footer-home":
				if (get_module_setting('epage')==0&&get_module_setting('index')==1) $s = true;
			break;
		}
	}
	if (get_module_pref('user_squotes')==0) {
		$s=false;
	}
	if ($hookname=='checkuserpref') {
		$s=false;
		if ($session['user']['superuser']&SU_EDIT_USERS||get_module_pref('canadd')==1) {
			$args['allow']=true;
		} else {
			$args['allow']=false;
		}
	}
	if ($s) {
		if ($session['user']['superuser']&SU_EDIT_USERS||get_module_pref('canadd')==1&&$session['user']['specialinc']=="") {
				output_notl("`n`c[<a href='runmodule.php?module=quotes&op=list'>Quote Editor</a>]`c",true);
				addnav("","runmodule.php?module=quotes&op=list");
		}
		rawoutput(quotes_return(),true);
	}
	if ($hookname=='superuser'&&$session['user']['superuser']&SU_EDIT_USERS) {
		addnav("Editors");
		addnav("Quote Editor","runmodule.php?module=quotes&op=list");
	}
	return $args;
}

function quotes_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "multidelete":
			page_header("Multi Quotes Deletion");
			$quotes =(array) httppost('quote');
			if (count($quotes)>0) {
				$stuff = explode('|@&@|',get_module_setting('quotes'));
				$a = array();
				$n = 0;
				foreach ($stuff as $val) {
					if ($val!="") {
						$n++;
						$a[$n]=$val;
					}
				}
				foreach ($quotes as $s => $val) {
					if (isset($a[$s])) unset($a[$s]);
				}
				$x = join("|@&@|", $a);
				set_module_setting('quotes',$x);
				output("`c`b`@Quotes Deleted.`0`b`c");
			} else {
				output("`b`^You didn't check any quotes for deletion...`b`n`7");
			}
		case "list":
			if ($op=='list') page_header("Quotes List");
			addnav("Navigation");
			if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
				addnav("X?`bSuperuser Grotto`b","superuser.php");
			}
			addnav("Commentary Overview","runmodule.php?module=quotes&op=clist");
			if ($session['user']['alive']) villagenav();
			if (!$session['user']['alive']) addnav("S?Return to the Shades","shades.php");
			quotes_list($op);
			page_footer();
		break;
		case "delete":
			popup_header("Delete Quote");
			$stuff = explode('|@&@|',get_module_setting('quotes'));
			$z = "";
			$n = 0;
			$q = httpget('q');
			foreach ($stuff as $val) {
				if ($val!="") {
					$n++;
					if ($n!=$q) $z.="|@&@|".$val;
				}
			}
			set_module_setting('quotes',$z);
			output("`c`b`@Quote Deleted.`0`b`c");
			popup_footer();
		break;
		case "commentquote":
			page_header("Multi Quotes Add");
			$comment =(array) httppost('comment');
			if (count($comment)>0) {
				foreach ($comment as $s => $val) {
					$sql = "SELECT comment,author FROM " . db_prefix("commentary") . " WHERE commentid=$s";
					$result = db_query($sql);
					$row = db_fetch_assoc($result);
					db_free_result($result);
					$sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE acctid=".$row['author'];
					$result = db_query($sql);
					$n = db_fetch_assoc($result);
					$name = $n['name'];
					db_free_result($result);
					unset($n,$sql);
					$row['comment'] = comment_sanitize($row['comment']);
					if (substr($row['comment'],0,2)=="::"||substr($row['comment'],0,2)=="/me"||substr($row['comment'],0,1)==":") {
						$row['comment'] = "`&".$name."`0`& ".substr($row['comment'],1)."`0`n";
					} else {
						$row['comment'] = "`&".$name."`3 says, \"`#".$row['comment']."`3\"`0`n";
					}
					$quath = quotes_fix(quotes_r($name));
					$quote = quotes_fix(quotes_r($row['comment']));
					$x=get_module_setting('quotes')."|@&@|".$quath."|@^@|".$quote;
					set_module_setting('quotes',$x);	
				}
				output("`@Quotes Added.`7");
			} else {
				output("`b`^You didn't submit any quotes.`b`7");
			}
		case "clist":
			if ($op=='clist') page_header("Quotes List");
			tlschema("moderate");
			addcommentary();
			addnav("Navigation");
			if ($session['user']['alive']) villagenav();
			if (!$session['user']['alive']) addnav("S?Return to the Shades","shades.php");
			addnav("Main Quote Editor","runmodule.php?module=quotes&op=list");
			if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
				addnav("X?`bSuperuser Grotto`b","superuser.php");
			}
			addnav("Other");
			addnav("Commentary Overview","runmodule.php?module=quotes&op=clist");
			addnav("Commentary");
			addnav("Sections");
			addnav("Modules");
			addnav("Clan Halls");
			
			$area = httpget('area');
			$link = "runmodule.php?module=quotes&op=clist" . ($area ? "&area=$area" : "");
			$refresh = translate_inline("Refresh");
			rawoutput("<form action='$link' method='POST'>");
			rawoutput("<input type='submit' class='button' value='$refresh'>");
			rawoutput("</form>");
			addnav("", "$link");
			if ($area==""){
			talkform("X","says");
			quotes_viewcommentary("' or '1'='1","X",100);
			}else{
			quotes_viewcommentary($area,"X",100);
			talkform($area,"says");
			}
			
			
			addnav("Sections");
			tlschema("commentary");
			$vname = getsetting("villagename", LOCATION_FIELDS);
			addnav(array("%s Square", $vname), "runmodule.php?module=quotes&op=clist&area=village");
			
			if ($session['user']['superuser'] & ~SU_DOESNT_GIVE_GROTTO) {
			addnav("Grotto","runmodule.php?module=quotes&op=clist&area=superuser");
			}
			
			addnav("Land of the Shades","runmodule.php?module=quotes&op=clist&area=shade");
			addnav("Grassy Field","runmodule.php?module=quotes&op=clist&area=grassyfield");
			
			$iname = getsetting("innname", LOCATION_INN);
			// the inn name is a proper name and shouldn't be translated.
			tlschema("notranslate");
			addnav($iname,"runmodule.php?module=quotes&op=clist&area=inn");
			tlschema();
			
			addnav("MotD","runmodule.php?module=quotes&op=clist&area=motd");
			addnav("Veterans Club","runmodule.php?module=quotes&op=clist&area=veterans");
			addnav("Hunter's Lodge","runmodule.php?module=quotes&op=clist&area=hunterlodge");
			addnav("Gardens","runmodule.php?module=quotes&op=clist&area=gardens");
			addnav("Clan Hall Waiting Area","runmodule.php?module=quotes&op=clist&area=waiting");
			
			if (getsetting("betaperplayer", 1) == 1 && @file_exists("pavilion.php")) {
			addnav("Beta Pavilion","runmodule.php?module=quotes&op=clist&area=beta");
			}
			tlschema();
			
			if ($session['user']['superuser'] & SU_MODERATE_CLANS){
			addnav("Clan Halls");
			$sql = "SELECT clanid,clanname,clanshort FROM " . db_prefix("clans") . " ORDER BY clanid";
			$result = db_query($sql);
			// these are proper names and shouldn't be translated.
			tlschema("notranslate");
			while ($row=db_fetch_assoc($result)){
			addnav(array("<%s> %s", $row['clanshort'], $row['clanname']),
					"runmodule.php?module=quotes&op=clist&area=clan-{$row['clanid']}");
			}
			tlschema();
			}
			page_footer();
		break;
		case "add":
			popup_header("Quote Addition");
			rawoutput("<form action='runmodule.php?module=quotes&op=save' method='POST'>");
			addnav("","runmodule.php?module=quotes&op=save");
			output("`&`bQuote Author:`b ");
			rawoutput("<input name='qauth' value='$author'><br/>");
			output("`%Leave the author empty, for no author.`n");
			output("`&`bQuote:`b ");
			rawoutput("<input name='quote' value=''><br/>");
			$save = translate_inline("Save");
			rawoutput("<input type='submit' class='button' value=\"$save\">");
			rawoutput("</form>");
			popup_footer();
		break;
		case "csave":
			popup_header("Quote Addition");
			if (httpget('stage')!='1') {
				$quote = httpget('q');
				$author = $session['user']['login'];
				$img = "<img src='images/new.gif' alt=\'&gt;\' width=\'3\' height=\'5\' align=\'absmiddle\'> ";
				if (strpos($quote, $img)!==false) {
					str_replace($img,'',$quote);
				}
				if (strpos($quote, '</a>')!==false) {
					$quote = str_replace('style=\\\'text-decoration: none\\\'>','',strstr($quote, 'style=\\\'text-decoration: none\\\'>'));
					$quote = str_replace('</a>','',$quote);
				}
				$quote = quotes_fix(quotes_r($quote));
				$emots = array("*frown*"=>"images/frown.gif","*grin*"=>"images/grin.gif","*biggrin*"=>"images/grin2.gif","*happy*"=>"images/happy.gif","*laugh*"=>"images/laugh.gif","*love*"=>"images/loveface.gif","*angry*"=>"images/mad.gif","*mad*"=>"images/mad2.gif","*music*"=>"images/musicface.gif","*order*"=>"images/order.gif","*purple*"=>"images/purpleface.gif","*red*"=>"images/redface.gif","*rofl*"=>"images/rofl.gif","*rolleyes*"=>"images/rolleyes.gif","*shock*"=>"images/shock.gif","*shocked*"=>"images/shocked.gif","*slimer*"=>"images/slimer.gif","*spineyes*"=>"images/spineyes.gif","*sarcastic*"=>"images/srcstic.gif","*tongue*"=>"images/tongue.gif","*tongue2*"=>"images/tongue2.gif","*wink*"=>"images/wink.gif","*wink2*"=>"images/wink2.gif","*wink3*"=>"images/wink3.gif","*confused*"=>"images/confused.gif","*embarassed*"=>"images/embarassed.gif","*rose*"=>"images/rose.gif","*drool*"=>"images/drool.gif","*sick*"=>"images/sick.gif","*kiss*"=>"images/kiss.gif","*brokeheart*"=>"images/brokeheart.gif","*wimper*"=>"images/wimper.gif","*whew*"=>"images/whew.gif","*cry*"=>"images/cry.gif","*angel*"=>"images/angel.gif","*nerd*"=>"images/nerd.gif","*stop*"=>"images/stop.gif","*zzz*"=>"images/zzz.gif","*shhh*"=>"images/shhh.gif","*nottalking*"=>"images/nottalking.gif","*party*"=>"images/party.gif","*yawn*"=>"images/yawn.gif","*doh*"=>"images/doh.gif","*clap*"=>"images/clap.gif","*lie*"=>"images/lie.gif","*bateyes*"=>"images/bateyes.gif","*pray*"=>"images/pray.gif","*peace*"=>"images/peace.gif","*nono*"=>"images/nono.gif","*bow*"=>"images/bow.gif","*groove*"=>"images/groove.gif","*giggle*"=>"images/giggle.gif","*yakyak*"=>"images/yakyak.gif");
				if (is_module_active('emoticons')) {
					foreach ($emots as $shrt => $img) {
						$quote = str_replace("<IMG SRC=\"".$img."\">",$shrt,$quote);
					}
				}
				rawoutput("<form action='runmodule.php?module=quotes&op=csave&stage=1&quote=".urlencode($quote)."' method='POST'>");
				addnav("","runmodule.php?module=quotes&op=csave&stage=1&quote=".urlencode($quote));
				output("`&`bQuote Author:`b ");
				rawoutput("<input name='qauth' value='$author'><br/>");
				output("`%Leave the author empty, for no author.`n");
				output("`&`bQuote:`b ");
				output_notl($quote,true);
				$save = translate_inline("Save");
				rawoutput("<input type='submit' class='button' value=\"$save\">");
				rawoutput("</form>");
			} else {
				$author = quotes_r(httppost('author'));
				$quote = quotes_r(httpget('quote'));
				$x=get_module_setting('quotes')."|@&@|".$quath."|@^@|".$quote;
				set_module_setting('quotes',$x);
				output("`@Quote Added.");
				output_notl("`n<a href='runmodule.php?module=quotes&op=add'>%s</a>",translate_inline("Add another?"),true);
				addnav("","runmodule.php?module=quotes&op=add");
			}
			popup_footer();
		break;
		case "save":
			popup_header("Quote Addition");
			$quath = quotes_r(httppost('qauth'));
			$quote = str_replace('\"','"',str_replace("\'","'",quotes_r(httppost('quote'))));
			$x=get_module_setting('quotes')."|@&@|".$quath."|@^@|".$quote;
			set_module_setting('quotes',$x);
			output("`@Quote Added.");
			output_notl("`n<a href='runmodule.php?module=quotes&op=add'>%s</a>",translate_inline("Add another?"),true);
			addnav("","runmodule.php?module=quotes&op=add");
			popup_footer();
		break;
		case "esave":
			popup_header("Quote Editor");
			$q = httpget('q');
			$auth = quotes_r(httppost('auth'));
			$quote = quotes_r(httppost('quote'));
			$a = "";
			$stuff = explode('|@&@|',get_module_setting('quotes'));
			$z = "";
			$n = 0;
			if ($quote=='') {
				output("`@That quote is empty.");
				popup_footer();
				break;
			}
			foreach ($stuff as $val) {
				if ($val!="") {
					$n++;
					if ($n==$q) $a.="|@&@|".$auth."|@^@|".$quote;
					if ($n!=$q) $a.="|@&@|".$val;
				}
			}
			set_module_setting('quotes',$a);
			output("`@Quote updated.");
			popup_footer();
		break;
		case "edit":
			popup_header("Quote Editor");
			$stuff = explode('|@&@|',get_module_setting('quotes'));
			$z = "";
			$n = 0;
			$q = httpget('q');
			foreach ($stuff as $val) {
				if ($val!="") {
					$n++;
					if ($n==$q) $z=explode('|@^@|',$val);
				}
			}
			$author = (string)$z[0];
			$quote = (string)$z[1];
			rawoutput("<form action='runmodule.php?module=quotes&op=esave&q=".$q."' method='POST'>");
			addnav("","runmodule.php?module=quotes&op=esave&q=".$q);
			output("`&`bQuote Author:`b ");
			rawoutput("<input name='auth' value=\"".quotes_fix(quotes_r($author))."\" maxlength=\"70\"><br/>");
			output("`%Leave the author empty, for no author.`n");
			output("`&`bQuote:`b ");
			rawoutput("<input name='quote' value=\"".quotes_fix(quotes_r($quote))."\" maxlength=\"120\"><br/>");
			$save = translate_inline("Save");
			rawoutput("<input type='submit' class='button' value=\"$save\">");
			rawoutput("</form>");
			popup_footer();
		break;
	}
}

function quotes_r($q,$i=true) {
	$x = str_replace('\"','"',$q);
	if ($i) $y = str_replace("|@^@|","",$x);
	if ($i) $y = str_replace("|@&@|","",$y);
	$y = str_replace("\'","'",$y);
	return $y;
}

function quotes_return() {
	$stuff = explode('|@&@|',get_module_setting('quotes'));
	$n = 0;
	$y = array();
	foreach ($stuff as $val) {
		if ($val!="") {
			$n++;
			$y[$n]=$val;
		}
	}
	if ($n!=0) {
		$i=e_rand(1,$n);
		$x=$y[$i];
		$v = explode('|@^@|', $x);
		$q = quotes_r($v[1]);
		$q = quotes_fix($q);
		$emots = array("*frown*"=>"images/frown.gif","*grin*"=>"images/grin.gif","*biggrin*"=>"images/grin2.gif","*happy*"=>"images/happy.gif","*laugh*"=>"images/laugh.gif","*love*"=>"images/loveface.gif","*angry*"=>"images/mad.gif","*mad*"=>"images/mad2.gif","*music*"=>"images/musicface.gif","*order*"=>"images/order.gif","*purple*"=>"images/purpleface.gif","*red*"=>"images/redface.gif","*rofl*"=>"images/rofl.gif","*rolleyes*"=>"images/rolleyes.gif","*shock*"=>"images/shock.gif","*shocked*"=>"images/shocked.gif","*slimer*"=>"images/slimer.gif","*spineyes*"=>"images/spineyes.gif","*sarcastic*"=>"images/srcstic.gif","*tongue*"=>"images/tongue.gif","*tongue2*"=>"images/tongue2.gif","*wink*"=>"images/wink.gif","*wink2*"=>"images/wink2.gif","*wink3*"=>"images/wink3.gif","*confused*"=>"images/confused.gif","*embarassed*"=>"images/embarassed.gif","*rose*"=>"images/rose.gif","*drool*"=>"images/drool.gif","*sick*"=>"images/sick.gif","*kiss*"=>"images/kiss.gif","*brokeheart*"=>"images/brokeheart.gif","*wimper*"=>"images/wimper.gif","*whew*"=>"images/whew.gif","*cry*"=>"images/cry.gif","*angel*"=>"images/angel.gif","*nerd*"=>"images/nerd.gif","*stop*"=>"images/stop.gif","*zzz*"=>"images/zzz.gif","*shhh*"=>"images/shhh.gif","*nottalking*"=>"images/nottalking.gif","*party*"=>"images/party.gif","*yawn*"=>"images/yawn.gif","*doh*"=>"images/doh.gif","*clap*"=>"images/clap.gif","*lie*"=>"images/lie.gif","*bateyes*"=>"images/bateyes.gif","*pray*"=>"images/pray.gif","*peace*"=>"images/peace.gif","*nono*"=>"images/nono.gif","*bow*"=>"images/bow.gif","*groove*"=>"images/groove.gif","*giggle*"=>"images/giggle.gif","*yakyak*"=>"images/yakyak.gif");
		if (is_module_active('emoticons')&&get_module_pref('user_display','emoticons')==1) {
			foreach ($emots as $shrt => $img) {
				$q = str_replace($shrt,"<IMG SRC=\"".$img."\">",$q);
			}
		}
		$v[0]=str_replace("`&amp;","`&",htmlentities($v[0]));
		$z = "`c`i`6Quote:`i `^".$q."";
		if ($v[0]!='') $z.="`@`n--Added by ".quotes_r($v[0])."`0";
		if ($v[0]=='') $z.="`@`n--Anonymous`0";
		$z.="`c";
	}
	return appoencode($z,true);
}

function quotes_list() {
	$stuff = explode('|@&@|',get_module_setting('quotes'));
	$n = 0;
	output_notl("`c`b[<a target='_blank' href='runmodule.php?module=quotes&op=add' onClick=\"".popup("runmodule.php?module=quotes&op=add").";return false;\">".translate_inline("Add a Quote")."</a>]`b`c`n",true);
	if (count($stuff)>0) {
		output("`@There are the following quotes...`n");
	}
	output_notl("<form action='runmodule.php?module=quotes&op=multidelete' method='POST'>",true);
	addnav("","runmodule.php?module=quotes&op=multidelete");
	addnav("","runmodule.php?module=quotes&op=add");
	output_notl("<table><tr class='trhead'><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",translate_inline("Quote Deletion"),translate_inline("Quote"),translate_inline("Author"),translate_inline('Operations'),true);
	foreach ($stuff as $val) {
		if ($val!="") {
			$n++;
			$a = explode('|@^@|',$val);
			if ($a[0]=='') $a[0]=='None';
			$q =(string)quotes_r($a[1]);
			$q = quotes_fix($q);
			$emots = array("*frown*"=>"images/frown.gif","*grin*"=>"images/grin.gif","*biggrin*"=>"images/grin2.gif","*happy*"=>"images/happy.gif","*laugh*"=>"images/laugh.gif","*love*"=>"images/loveface.gif","*angry*"=>"images/mad.gif","*mad*"=>"images/mad2.gif","*music*"=>"images/musicface.gif","*order*"=>"images/order.gif","*purple*"=>"images/purpleface.gif","*red*"=>"images/redface.gif","*rofl*"=>"images/rofl.gif","*rolleyes*"=>"images/rolleyes.gif","*shock*"=>"images/shock.gif","*shocked*"=>"images/shocked.gif","*slimer*"=>"images/slimer.gif","*spineyes*"=>"images/spineyes.gif","*sarcastic*"=>"images/srcstic.gif","*tongue*"=>"images/tongue.gif","*tongue2*"=>"images/tongue2.gif","*wink*"=>"images/wink.gif","*wink2*"=>"images/wink2.gif","*wink3*"=>"images/wink3.gif","*confused*"=>"images/confused.gif","*embarassed*"=>"images/embarassed.gif","*rose*"=>"images/rose.gif","*drool*"=>"images/drool.gif","*sick*"=>"images/sick.gif","*kiss*"=>"images/kiss.gif","*brokeheart*"=>"images/brokeheart.gif","*wimper*"=>"images/wimper.gif","*whew*"=>"images/whew.gif","*cry*"=>"images/cry.gif","*angel*"=>"images/angel.gif","*nerd*"=>"images/nerd.gif","*stop*"=>"images/stop.gif","*zzz*"=>"images/zzz.gif","*shhh*"=>"images/shhh.gif","*nottalking*"=>"images/nottalking.gif","*party*"=>"images/party.gif","*yawn*"=>"images/yawn.gif","*doh*"=>"images/doh.gif","*clap*"=>"images/clap.gif","*lie*"=>"images/lie.gif","*bateyes*"=>"images/bateyes.gif","*pray*"=>"images/pray.gif","*peace*"=>"images/peace.gif","*nono*"=>"images/nono.gif","*bow*"=>"images/bow.gif","*groove*"=>"images/groove.gif","*giggle*"=>"images/giggle.gif","*yakyak*"=>"images/yakyak.gif");
			if (is_module_active('emoticons')&&get_module_pref('user_display','emoticons')==1) {
				foreach ($emots as $shrt => $img) {
					$q = str_replace($shrt,"<IMG SRC=\"".$img."\">",$q);
				}
			}
			$a = (string)quotes_r($a[0]);
			output_notl("<tr class='".($n%2?"trlight":"trdark")."'><td align='center'>[ <input type='checkbox' name='quote[".$n."]'> ]</td><td>`^%s</td><td>`@%s</td><td>`# [<a target='_blank' href='runmodule.php?module=quotes&op=edit&q=".$n."' onClick=\"".popup("runmodule.php?module=quotes&op=edit&q=".$n).";return false;\">".translate_inline("Edit")."</a>] - [<a target='_blank' href='runmodule.php?module=quotes&op=delete&q=".$n."' onClick=\"".popup("runmodule.php?module=quotes&op=delete&q=".$n).";return false;\">".translate_inline("Delete")."</a>] </td></tr>",$q,$a,true);
			addnav("","runmodule.php?module=quotes&op=edit&q=".$n);
			addnav("","runmodule.php?module=quotes&op=delete&q=".$n);
		}
	}
	if ($n==0) {
		output_notl("<tr class='trhilight'><td colspan='4'>`c%s`c</td></tr>",translate_inline("There are no quotes."),true);
	}
	output_notl('</table>',true);
	if ($n!=0) {
		$quote = HTMLEntities(translate_inline("Delete Checked Quotes"));
		output_notl("<input type='submit' class='button' value=\"".$quote."\"></form>",true);
	}
}

function quotes_fix($q) {
	$q = html_entity_decode($q);
	return $q;
}

function quotes_viewcommentary($section,$message="Interject your own commentary?",$limit=10,$talkline="says",$schema=false) {
	global $session,$REQUEST_URI,$doublepost, $translation_namespace;
	
	if ($schema === false)
	$schema=$translation_namespace;
	tlschema("commentary");
	
	$nobios = array("motd.php"=>true);
	if ($nobios[basename($_SERVER['SCRIPT_NAME'])])
	$linkbios=false;
	else
	$linkbios=true;
	
	if ($message=="X") $linkbios=true;
	
	if ($doublepost) output("`\$`bDouble post?`b`0`n");
	
	if ((int)getsetting("expirecontent",180)>0 && e_rand(1,1000)==1){
	$sql = "DELETE FROM " . db_prefix("commentary") . " WHERE postdate<'".date("Y-m-d H:i:s",strtotime("-".getsetting("expirecontent",180)." days"))."'";
	db_query($sql);
	}
	
	$clanrankcolors=array("`!","`#","`^","`&");
	
	$com=(int)httpget("comscroll");
	$cc = false;
	if (httpget("comscroll") !==false && (int)$session['lastcom']==$com+1)
	$cid = (int)$session['lastcommentid'];
	else
	$cid = 0;
	
	$session['lastcom'] = $com;
	
	if ($com > 0 || $cid > 0) {
	// Find newly added comments.
	$sql = "SELECT COUNT(commentid) AS newadded FROM " .
		db_prefix("commentary") . " LEFT JOIN " .
		db_prefix("accounts") . " ON " .
		db_prefix("accounts") . ".acctid = " .
		db_prefix("commentary"). ".author WHERE section='$section' AND " .
		db_prefix("accounts").".locked=0 AND commentid > '$cid'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$newadded = $row['newadded'];
	} else {
	$newadded = 0;
	}
	
	$commentbuffer = array();
	if ($cid == 0) {
	$sql = "SELECT ". db_prefix("commentary") . ".*, " .
		db_prefix("accounts").".name, " .
		db_prefix("accounts").".login, " .
		db_prefix("accounts").".clanrank, " .
		db_prefix("clans") .  ".clanshort FROM " .
		db_prefix("commentary") . " INNER JOIN " .
		db_prefix("accounts") . " ON " .
		db_prefix("accounts") .  ".acctid = " .
		db_prefix("commentary"). ".author LEFT JOIN " .
		db_prefix("clans") . " ON " .
		db_prefix("clans") . ".clanid=" .
		db_prefix("accounts") .
		".clanid WHERE section = '$section' AND " .
		db_prefix("accounts") .
		".locked=0 ORDER BY commentid DESC LIMIT " .
		($com*$limit).",$limit";
	if ($com==0)
		$result = db_query_cached($sql,"comments-{$section}");
	else
		$result = db_query($sql);
	while($row = db_fetch_assoc($result)) $commentbuffer[] = $row;
	} else {
	$sql = "SELECT " . db_prefix("commentary") . ".*, " .
		db_prefix("accounts").".name, " .
		db_prefix("accounts").".login, " .
		db_prefix("accounts").".clanrank, " .
		db_prefix("clans").".clanshort FROM " .
		db_prefix("commentary") . " INNER JOIN " .
		db_prefix("accounts") . " ON " .
		db_prefix("accounts") . ".acctid = " .
		db_prefix("commentary"). ".author LEFT JOIN " .
		db_prefix("clans") . " ON " . db_prefix("clans") . ".clanid=" .
		db_prefix("accounts") .
		".clanid WHERE section = '$section' AND " .
		db_prefix("accounts") .
		".locked=0 AND commentid > '$cid' " . 
		"ORDER BY commentid ASC LIMIT $limit";
	$result = db_query($sql);
	while ($row = db_fetch_assoc($result)) $commentbuffer[] = $row;
	$commentbuffer = array_reverse($commentbuffer);
	}
	
	$rowcount = count($commentbuffer);
	if ($rowcount > 0)
	$session['lastcommentid'] = $commentbuffer[0]['commentid'];
	else
	$session['lastcommentid'];
	
	$counttoday=0;
	for ($i=0; $i < $rowcount; $i++){
	$row = $commentbuffer[$i];
	$row['comment'] = comment_sanitize($row['comment']);
	$commentids[$i] = $row['commentid'];
	if (date("Y-m-d",strtotime($row['postdate']))==date("Y-m-d")){
		if ($row['name']==$session['user']['name']) $counttoday++;
	}
	$x=0;
	$ft="";
	for ($x=0;strlen($ft)<3 && $x<strlen($row['comment']);$x++){
		if (substr($row['comment'],$x,1)=="`" && strlen($ft)==0) {
			$x++;
		}else{
			$ft.=substr($row['comment'],$x,1);
		}
	}
	
	$link = "bio.php?char=" . rawurlencode($row['login']) .
		"&ret=".URLEncode($_SERVER['REQUEST_URI']);
	
	if (substr($ft,0,2)=="::")
		$ft = substr($ft,0,2);
	elseif (substr($ft,0,1)==":")
		$ft = substr($ft,0,1);
	
	$row['comment'] = holidayize($row['comment']);
	$row['name'] = holidayize($row['name']);
	if ($row['clanrank'])
		$row['name'] = ($row['clanshort']>""?"{$clanrankcolors[$row['clanrank']]}&lt;`2{$row['clanshort']}{$clanrankcolors[$row['clanrank']]}&gt; `&":"").$row['name'];
	if ($ft=="::" || $ft=="/me" || $ft==":"){
		$x = strpos($row['comment'],$ft);
		if ($x!==false){
			if ($linkbios)
				$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0<a href='$link' style='text-decoration: none'>\n`&{$row['name']}`0</a>\n`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
			else
				$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0`&{$row['name']}`0`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
			$rawc[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0`&{$row['name']}`0`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
		}
	}
	if ($op[$i]=="")  {
		if ($linkbios)
			$op[$i] = "`0<a href='$link' style='text-decoration: none'>`&{$row['name']}`0</a>`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
		else
			$op[$i] = "`&{$row['name']}`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
		$rawc[$i] = "`&{$row['name']}`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
	}
	$session['user']['prefs']['timeoffset'] = round($session['user']['prefs']['timeoffset'],1);
	if ($session['user']['prefs']['timestamp']==1) {
		$time = strtotime("+{$session['user']['prefs']['timeoffset']} hours",strtotime($row['postdate']));
		$s=date("`7[m/d h:ia]`0 ",$time);
		$op[$i] = $s.$op[$i];
	}elseif ($session['user']['prefs']['timestamp']==2) {
		$s=reltime(strtotime($row['postdate']));
		$op[$i] = "`7($s)`0 ".$op[$i];
	}
	if ($message=="X")
		$op[$i]="`0({$row['section']}) ".$op[$i];
	if ($row['postdate']>=$session['user']['recentcomments'])
		$op[$i]="<img src='images/new.gif' alt='&gt;' width='3' height='5' align='absmiddle'> ".$op[$i];
	addnav("",$link);
	$auth[$i] = $row['author'];
	$rawc[$i] = full_sanitize($rawc[$i]);
	$rawc[$i] = htmlentities($rawc[$i], ENT_QUOTES);
	}
	$i--;
	$outputcomments=array();
	$sect="x";
	
	for (;$i>=0;$i--){
	$out="";
	$out.="`0[ <input type='checkbox' name='comment[{$commentids[$i]}]'> ]&nbsp;";
	$matches=array();
	preg_match("/[(]([^)]*)[)]/",$op[$i],$matches);
	$sect=trim($matches[1]);
	if (substr($sect,0,5)!="clan-" || $sect==$section){
		if (substr($sect,0,4)!="pet-"){
			$out.=$op[$i];
			if (!is_array($outputcomments[$sect]))
				$outputcomments[$sect]=array();
			array_push($outputcomments[$sect],$out);
		}
	}
	}
	
	$quote = HTMLEntities(translate_inline("Quote Checked Comments"));
	output_notl("<form action='runmodule.php?module=quotes&op=commentquote&area=".httpget("area")."' method='POST'>",true);
	addnav("","runmodule.php?module=quotes&op=commentquote&area=".httpget('area'));
	output_notl("<input type='submit' class='button' value=\"".$quote."\">",true);
	
	//output the comments
	ksort($outputcomments);
	reset($outputcomments);
	$sections = commentarylocs();
	$needclose = 0;
	
	while (list($sec,$v)=each($outputcomments)){
	if ($sec!="x") {
		if($needclose) modulehook("}collapse");
		output_notl("`n<hr><a href='runmodule.php?module=quotes&op=clist&area=%s'>`b`^%s`0`b</a>`n", $sec, $sections[$sec], true);
		addnav("", "runmodule.php?module=quotes&op=clist&area=$sec");
		modulehook("collapse{",array("name"=>"com-".$sec));
		$needclose = 1;
	} else {
		modulehook("collapse{",array("name"=>"com-".$section));
		$needclose = 1;
	}
	reset($v);
	while (list($key,$val)=each($v)){
		$args = array('commentline'=>$val);
		$args = modulehook("viewcommentary", $args);
		$val = $args['commentline'];
		output_notl($val, true);
	}
	}
	
	if ($needclose) {
	modulehook("}collapse");
	$needclose = 0;
	}
	
	output_notl("`n");
	rawoutput("<input type='submit' class='button' value=\"$quote\">");
	rawoutput("</form>");
	output_notl("`n");
	
	$args = modulehook("insertcomment");
	if ($message!="X"){
	$message="`n`@$message`n";
	output($message);
	talkform($section,$talkline,$limit,$schema);
	}
	
	$firstu = translate_inline("&lt;&lt; First Unseen");
	$prev = translate_inline("&lt; Previous");
	$ref = translate_inline("Refresh");
	$next = translate_inline("Next &gt;");
	$lastu = translate_inline("Last Page &gt;&gt;");
	if ($rowcount>=$limit || $cid>0){
	$sql = "SELECT count(*) AS c FROM " . db_prefix("commentary") . " WHERE section='$section' AND postdate > '{$session['user']['recentcomments']}'";
	$r = db_query($sql);
	$val = db_fetch_assoc($r);
	$val = round($val['c'] / $limit + 0.5,0) - 1;
	if ($val>0){
		$first = comscroll_sanitize($REQUEST_URI)."&comscroll=".($val);
		$first = str_replace("?&","?",$first);
		if (!strpos($first,"?")) $first = str_replace("&","?",$first);
		$first .= "&refresh=1";
		output_notl("<a href=\"$first\">$firstu</a>",true);
		addnav("",$first);
	}else{
		output_notl($firstu,true);
	}
	output_notl("`@");
	$req = comscroll_sanitize($REQUEST_URI)."&comscroll=".($com+1);
	$req = str_replace("?&","?",$req);
	if (!strpos($req,"?")) $req = str_replace("&","?",$req);
	$req .= "&refresh=1";
	output_notl("<a href=\"$req\">$prev</a>",true);
	addnav("",$req);
	}else{
	output_notl("$firstu $prev",true);
	}
	$last = comscroll_sanitize($REQUEST_URI)."&refresh=1";
	$last = str_replace("?&","?",$last);
	if (!strpos($last,"?")) $last = str_replace("&","?",$last);
	output_notl("&nbsp;<a href=\"$last\">$ref</a>&nbsp;",true);
	addnav("",$last);
	if ($com>0 || ($cid > 0 && $newadded > $limit)){
		$req = comscroll_sanitize($REQUEST_URI)."&comscroll=".($com-1);
		$req = str_replace("?&","?",$req);
		if (!strpos($req,"?")) $req = str_replace("&","?",$req);
		$req .= "&refresh=1";
		output_notl(" <a href=\"$req\">$next</a>",true);
		addnav("",$req);
		output_notl(" <a href=\"$last\">$lastu</a>",true);
	}else{
		output_notl("$next $lastu",true);
	}
	if (!$cc) db_free_result($result);
	tlschema();
	if ($needclose) modulehook("}collapse");
}
?>