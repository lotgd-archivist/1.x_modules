<?php
/*
Details:
 * This is an easter bank
 * It is part of the easter pack
 * Based upon 'icebank' by Shannon Brown
History Log:
 v1.0:
 o Seems to be Stable
*/

require_once("lib/systemmail.php");
require_once("lib/sanitize.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function easterbank_getmoduleinfo(){
	$info = array(
		"name"=>"Easter Bank",
		"version"=>"1.1",
		"author"=>"`@CortalUX",
		"category"=>"Village",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/easterpack.zip",
		"settings"=>array(
			"Easter Bank - General,title",
			"allowdep"=>"Allow deposit?,bool|0",
			"allowtx"=>"Allow transfer?,bool|0",
			"bankloc"=>"Where does the bank appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"(overridden if eastertown is installed),note",
		),
	);
	return $info;
}

function easterbank_install(){
	module_addhook("changesetting");
	module_addhook("village");
	return true;
}

function easterbank_uninstall(){
	return true;
}

function easterbank_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("bankloc")) {
					set_module_setting("bankloc", $args['new']);
				}
			}
		break;
		case "village":
			if (is_module_active('eastertown')) {
				set_module_setting('bankloc',get_module_setting('villagename','eastertown'));
			}
			if ($session['user']['location'] == get_module_setting("bankloc")) {
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				addnav("E?The Egg Bank","runmodule.php?module=easterbank");
			}
		break;
	}
	return $args;
}

function easterbank_run(){
	global $session;
	$op = httpget("op");
	$allowdep=get_module_setting("allowdep");
	$allowtx=get_module_setting("allowtx");
	page_header("Whittons Egg Bank");
	output("`^`c`bEgg Bank`b`c");
	$op = httpget('op');
	if ($op==""){
		checkday();
		output("`QYou stroll through the engraved saloon doors, to find a large balding man standing behind a counter.`n`n");
		output("`Q\"`&Hello %s,`Q\" Whitton says, with a large smile",$session['user']['sex']?"Miss":"Miladdo");
		if ($session['user']['goldinbank']>=0){
			output("`Q\"`&I've got %s gold of yours, y'want it back? ",$session['user']['goldinbank']);
		}else{
			output("`Q\"`&You've got `^%s`& bits of mah gold, tak' your time! ",abs($session['user']['goldinbank']));
		}
		output("Wha can I do fo' ye?`Q\"");
		modulehook("easterbank-text");
	}elseif($op=="transfer" && $allowtx){
		output("`Q`bTransfer Money`b:`n");
		if ($session['user']['goldinbank']>=0){
			output("`QWhitton tells you, \"`&Sorreh, but I've onli got a small cart, so I can only transfer `^%s`& gold for each level that yah friend has git.",getsetting("transferperlevel",25));
			$maxout = $session['user']['level']*getsetting("maxtransferout",25);
			output("And ah can't send mor'en `^%s`& gold each day.`Q\"`n",$maxout);
			if ($session['user']['amountouttoday'] > 0) {
				output("`QWhitton looks out of a side window, and says \"`&Meh Cart's alreddy got `^%s`& bits of yeh gold tahday.`Q\"`n",$session['user']['amountouttoday']);
			}
			output_notl("`n");
			$preview = translate_inline("Preview Transfer");
			rawoutput("<form action='runmodule.php?module=easterbank&op=transfer2' method='POST'>");
			output("Transfer how much: ");
			rawoutput("<input name='amount' id='amount' width='5'>");
			output_notl("`n");
			output("To: ");
			rawoutput("<input name='to'>");
			output(" (partial names are ok, you will be asked to confirm the transaction before it occurs).`n");
			rawoutput("<input type='submit' class='button' value='$preview'></form>");
			rawoutput("<script language='javascript'>document.getElementById('amount').focus();</script>");
			addnav("","runmodule.php?module=easterbank&op=transfer2");
		}else{
			output("`Q\"`QI'm sorry, I can't let yeh transfer monneh to someone who is already borrowin mah monneh.`Q\"");
		}
	}elseif($op=="transfer2" && $allowtx){
		output("`Q`bConfirm Transfer`b:`n");
		$string="%";
		$to = httppost('to');
		for ($x=0;$x<strlen($to);$x++){
			$string .= substr($to,$x,1)."%";
		}
		$sql = "SELECT name,login FROM " . db_prefix("accounts") . " WHERE name LIKE '".addslashes($string)."' AND locked=0 ORDER by login='$to' DESC, name='$to' DESC, login";
		$result = db_query($sql);
		$amt = abs((int)httppost('amount'));
		if (db_num_rows($result)==1){
			$row = db_fetch_assoc($result);
			$msg = translate_inline("Complete Transfer");
			rawoutput("<form action='runmodule.php?module=easterbank&op=transfer3' method='POST'>");
			output("`QTransfer `^%s`Q to `&%s`Q.",$amt,$row['name']);
			rawoutput("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='$msg'></form>",true);
			addnav("","runmodule.php?module=easterbank&op=transfer3");
		}elseif(db_num_rows($result)>100){
			output("`QWhitton smiles at you, and says that he don't know how he's gonna send monneh to so many people, and that perhaps you could help him a bit.`n`n");
			$msg = translate_inline("Preview Transfer");
			rawoutput("<form action='runmodule.php?module=easterbank&op=transfer2' method='POST'>");
			output("Transfer how much: ");
			rawoutput("<input name='amount' id='amount' width='5' value='$amt'><br>");
			output("To: ");
			rawoutput("<input name='to' value='$to'>");
			output(" (partial names are ok, you will be asked to confirm the transaction before it occurs).`n");
			rawoutput("<input type='submit' class='button' value='$msg'></form>");
			rawoutput("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
			addnav("","runmodule.php?module=easterbank&op=transfer2");
		}elseif(db_num_rows($result)>1){
			rawoutput("<form action='runmodule.php?module=easterbank&op=transfer3' method='POST'>");
			output("`QTransfer `^%s`Q to ",$amt);
			rawoutput("<select name='to' class='input'>");
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				rawoutput("<option value=\"".HTMLEntities($row['login'])."\">".full_sanitize($row['name'])."</option>");
			}
			$msg = translate_inline("Complete Transfer");
			rawoutput("</select><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='$msg'></form>");
			addnav("","runmodule.php?module=easterbank&op=transfer3");
		}else{
			output("`QWhitton frowns, \"`&Sorreh, %s but I ken't find tha person.`Q\"",$session['user']['sex']?"Miss":"Miladdo");
		}
	}elseif($op=="transfer3" && $allowtx){
		$amt = abs((int)httppost('amount'));
		$to = httppost('to');
		output("`Q`bTransfer Completion`b`n");
		if ($session['user']['gold']+$session['user']['goldinbank']<$amt){
			output("`QWhitton frowns, \"`&Sorreh, I can't send `^%s`& gold, I onleh hold  `^%s`& for you.`Q\"",$amt,$session['user']['gold']+$session['user']['goldinbank']);
		}else{
			$sql = "SELECT name,acctid,level,transferredtoday FROM " . db_prefix("accounts") . " WHERE login='$to'";
			$result = db_query($sql);
			if (db_num_rows($result)==1){
				$row = db_fetch_assoc($result);
				$maxout = $session['user']['level']*getsetting("maxtransferout",25);
				$maxtfer = $row['level']*getsetting("transferperlevel",25);
				if ($session['user']['amountouttoday']+$amt > $maxout) {
					output("`QWhitton looks at you with a crinkled brow, \"`&Sorreh, I ken't transfer no more'n `^%s`& gold total per day.`Q\"",$maxout);
				}else if ($maxtfer<$amt){
					output("`QWhitton looks at you with a crinkled brow, \"`&Sorreh, `&%s`& may kin onleh receive up'tah `^%s`& gold per day.`Q\"",$row['name'],$maxtfer);
				}else if($row['transferredtoday']>=getsetting("transferreceive",3)){
					output("`QWhitton looks at you with a crinkled brow, \"`&Sorreh, `&%s`& has bin sent a lotta monneh, I kin't send no more.`Q\"",$row['name']);
				}else if($amt<(int)$session['user']['level']){
					output("`QWhitton looks at you with a crinkled brow, \"`&Sorreh, \"`&I kin onleh transfer at least as much as yeh level.`Q\"");
				}else if($row['acctid']==$session['user']['acctid']){
					output("`QWhitton looks at you with a crinkled brow, \"`&Ok, I've sent the money from yerself to yerself, and I din't even need ta move.`Q\"");
				}else{
					debuglog("transferred $amt gold to", $row['acctid']);
					$session['user']['gold']-=$amt;
					if ($session['user']['gold']<0){
						//withdraw in case they don't have enough on hand.
						$session['user']['goldinbank']+=$session['user']['gold'];
						$session['user']['gold']=0;
					}
					$session['user']['amountouttoday']+= $amt;
					$sql = "UPDATE ". db_prefix("accounts") . " SET goldinbank=goldinbank+$amt,transferredtoday=transferredtoday+1 WHERE acctid='{$row['acctid']}'";
					db_query($sql);
					output("`QWhitton smiles, his eyes twinkling, \"`&I've put that monneh fer tha transfer in mah cart!`Q\"");
					$subj = array("`^You have received a money transfer!`0");
					$body = array("`&%s`Q has transferred `^%s`Q gold to your bank account, via Whitton's Carting service!",$session['user']['name'],$amt);
					systemmail($row['acctid'],$subj,$body);
				}
			}else{
				output("`QWhitton cups a hand to his ear, and apologizes, \"`&Sorreh %s, I din't hear that, I'm a bit deaf in one ear.t believe I caught that. Speak up an you tell me again what ya would like tah transfer?`Q\"",$session['user']['sex']?"Miss":"Sonneh");
			}
		}
	}elseif($op=="deposit" && $allowdep){
		output("`0");
		rawoutput("<form action='runmodule.php?module=easterbank&op=depositfinish' method='POST'>");
		$balance = translate_inline("`QWhitton says, \"`&I've got `^%s`& gold in mah bank.`Q\"`n");
		$debt = translate_inline("`QWhitton says, \"`&You've got `^%s`& bitsa mah gold.`Q\"`n");
		output_notl($session['user']['goldinbank']>=0?$balance:$debt,abs($session['user']['goldinbank']));
		output("`QSearching through all your pockets and pouches, you calculate that you currently have `^%s`Q gold on hand.`n`n", $session['user']['gold']);
		$dep = translate_inline("`^Deposit how much?");
		$pay = translate_inline("`^Pay off how much?");
		output_notl($session['user']['goldinbank']>=0?$dep:$pay);
		$dep = translate_inline("Deposit");
		rawoutput(" <input id='input' name='amount' width=5 > <input type='submit' class='button' value='$dep'>");
		output("`n`iEnter 0 or nothing to deposit it all`i");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>",true);
		addnav("","runmodule.php?module=easterbank&op=depositfinish");
	}elseif($op=="depositfinish" && $allowdep){
		$amount = abs((int)httppost('amount'));
		if ($amount==0){
			$amount=$session['user']['gold'];
		}
		$notenough = translate_inline("`\$ERROR: Not enough gold in hand to deposit.`n`n`^You plunk your `&%s`^ gold on the counter and declare that you would like to deposit all `&%s`^ gold of it.`n`n`QWhitton smiles at you and says ya dohn't have that much.");
		$depositdebt = translate_inline("`QWhitton nods, and say's he'll remember that deposit of `^%s `Qgold. \"`&Thank yeh Kindleh, `&%s`&.  Yeh are now borrohin `\$%s`& bitsa mah gold and yeh have `^%s`& gold in ya hand.`Q\"");
		$depositbalance= translate_inline("`QWhitton nods, and say's he'll remember that deposit of `^%s `Qgold. \"`&Thank yeh Kindleh, `&%s`&.  I now have `^%s`& o yeh gold in mah bank and yeh have `^%s`& gold in hand.`Q\"");
		if ($amount>$session['user']['gold']){
			output($notenough,$session['user']['gold'],$amount);
		}else{
			debuglog("deposited " . $amount . " gold in the bank");
			$session['user']['goldinbank']+=$amount;
			$session['user']['gold']-=$amount;
			output($session['user']['goldinbank']>=0?$depositbalance:$depositdebt,$amount,$session['user']['name'], abs($session['user']['goldinbank']),$session['user']['gold']);
		}
	}elseif($op=="borrow"){
		$maxborrow = $session['user']['level']*getsetting("borrowperlevel",20);
		$borrow = translate_inline("Borrow");
		$balance = translate_inline("`QWhitton thinks for a moment, \"`&I have `^%s`& gold in mah bank.`Q\"`n");
		$debt = translate_inline("`QWhitton thinks for a moment, \"`&Yeh have `^%s`& bitsa mah gold.`Q\"`n");
		rawoutput("<form action='runmodule.php?module=easterbank&op=withdrawfinish' method='POST'>");
		output($session['user']['goldinbank']>=0?$balance:$debt,abs($session['user']['goldinbank']));
		output("`Q\"`&Ow much would yeh like to borreh?  At your level, I ken letyi borroh `^%s`& gold from mah bank.`Q\"`n`n", $maxborrow);
		rawoutput(" <input id='input' name='amount' width=5 > <input type='hidden' name='borrow' value='x'><input type='submit' class='button' value='$borrow'>");
		output("`n(Money will be withdrawn until you have none left, the remainder will be borrowed)");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>");
		addnav("","runmodule.php?module=easterbank&op=withdrawfinish");
	}elseif($op=="withdraw"){
		$withdraw = translate_inline("Withdraw");
		$balance = translate_inline("`QWhitton thinks for a moment, \"`&I have `^%s`& gold in mah bank.`Q\"`n");
		$debt = translate_inline("`QWhitton thinks for a moment, \"`&Yeh have `^%s`& bitsa mah gold.`Q\"`n");
		rawoutput("<form action='runmodule.php?module=easterbank&op=withdrawfinish' method='POST'>");
		output($session['user']['goldinbank']>=0?$balance:$debt,abs($session['user']['goldinbank']));
		output("`Q\"`&How much would you like to withdraw `&%s`&?\"`n`n",$session['user']['name']);
		rawoutput("<input id='input' name='amount' width=5 > <input type='submit' class='button' value='$withdraw'>");
		output("`n`iEnter 0 or nothing to withdraw it all`i");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>");
		addnav("","runmodule.php?module=easterbank&op=withdrawfinish");
	}elseif($op=="withdrawfinish"){
		$amount=abs((int)httppost('amount'));
		if ($amount==0){
			$amount=abs($session['user']['goldinbank']);
		}
		if ($amount>$session['user']['goldinbank'] && httppost('borrow')=="") {
			output("`\$ERROR: Not enough gold in the bank to withdraw.`^`n`n");
			output("`QHaving been tole' that you have `^%s`Q gold in Whittons bank, you say that you would like to withdraw all `^%s`Q of it.`n`n", $session['user']['goldinbank'], $amount);
			output("Whitton crinkles his brow, suggests you rethink that. You realize your mistake and think you should try again.");
		}else if($amount>$session['user']['goldinbank']){
			$lefttoborrow = $amount;
			$didwithdraw = 0;
			$maxborrow = $session['user']['level']*getsetting("borrowperlevel",20);
			if ($lefttoborrow<=$session['user']['goldinbank']+$maxborrow){
				if ($session['user']['goldinbank']>0){
					output("`QYou withdraw your remaining `^%s`Q gold.", $session['user']['goldinbank']);
					$lefttoborrow-=$session['user']['goldinbank'];
					$session['user']['gold']+=$session['user']['goldinbank'];
					$session['user']['goldinbank']=0;
					debuglog("withdrew $amount gold from the bank");
					$didwithdraw = 1;
				}
				if ($lefttoborrow-$session['user']['goldinbank'] > $maxborrow){
					if ($didwithdraw) {
						output("`QAdditionally, you ask to borrow `^%s`Q gold.", $leftoborrow);
					} else {
						output("`QYou ask to borrow `^%s`Q gold.", $lefttoborrow);
					}
					output("Whitton thinks for a moment, frowns, and informs you that you may only borrow up to `^%s`Q gold from him.", $maxborrow);
				}else{
					if ($didwithdraw) {
						output("`QAdditionally, you borrow `^%s`Q gold.", $lefttoborrow);
					} else {
						output("`QYou borrow `^%s`Q gold.", $lefttoborrow);
					}
					$session['user']['goldinbank']-=$lefttoborrow;
					$session['user']['gold']+=$lefttoborrow;
					debuglog("borrows $lefttoborrow gold from the bank");
					output("`QWhitton memorizes your withdrawal of `^%s `Qgold. \"`&Thank yeh kindli, `&%s`&.  You now have `\$%s`& bitsa mah gold and `^%s`& gold in yeh hand.`Q\"", $amount,$session['user']['name'], abs($session['user']['goldinbank']),$session['user']['gold']);
				}
			}else{
				output("`QConsidering the `^%s`Q gold in your account, you ask to borrow `^%s`Q. Whitton thinks for a moment, frowns, and informs you (in his stumbling way) that you may only borrow up to `^%s`Q gold at your level.", $session['user']['goldinbank'], $lefttoborrow-$session['user']['goldinbank'], $maxborrow);
			}
		}else{
			$session['user']['goldinbank']-=$amount;
			$session['user']['gold']+=$amount;
			debuglog("withdrew $amount gold from the bank");
			output("`QWhitton memorizes your withdrawal of `^%s `Qgold. \"`&Thank yeh Kindleh. `&%s`&.  I now have `^%s`& bitsa yer gold in mah bank and yeh have `^%s`& gold in yeh hand.`Q\"", $amount,$session['user']['sex']?"Miss":"Sonneh", abs($session['user']['goldinbank']),$session['user']['gold']);
		}
	}
	villagenav();
	addnav("Money");
	if ($session['user']['goldinbank']>=0){
		addnav("W?Withdraw","runmodule.php?module=easterbank&op=withdraw");
		if ($allowdep)
			addnav("D?Deposit","runmodule.php?module=easterbank&op=deposit");
		if (getsetting("borrowperlevel",20))
			addnav("L?Take out a Loan","runmodule.php?module=easterbank&op=borrow");
	}else{
		if ($allowdep)
			addnav("D?Pay off Debt","runmodule.php?module=easterbank&op=deposit");
		if (getsetting("borrowperlevel",20))
			addnav("L?Borrow More","runmodule.php?module=easterbank&op=borrow");
	}
	if ($allowtx){
		if ($session['user']['level']>=getsetting("mintransferlev",3) ||
				$session['user']['dragonkills']>0){
			addnav("M?Transfer Money","runmodule.php?module=easterbank&op=transfer");
		}
	}
	modulehook("easterbank-footer");
	page_footer();
}

?>