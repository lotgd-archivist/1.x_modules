<?php
/*
Details:
 * This is a module that allows you to run an easteregg hunt
 * Hall of Fame code based upon code by Billie Kennedy in the Orchard module
History Log:
 v1.0:
 o Unstable
 v1.1:
 o All stable excepting points reward code
 o Released, and will be bugfixed in next version
 v1.2:
 o Stable! Stable! Stable!!!
 v1.3:
 o Login redeeming FIXED!
*/
require_once('lib/villagenav.php');

function easteregghunt_getmoduleinfo(){
	$info = array(
		"name"=>"Easter Egg Hunt", 
		"version"=>"1.3",
		"author"=>"`@CortalUX", 
		"download"=>"http://dragonprime.net/users/CortalUX/easterpack.zip", 
		"category"=>"General",
		"settings"=>array(
			"Easter Egg Hunt - Distribution,title",
			"Abigail"=>"What letters does abigail sell?,text|abigail",
			"Abigail-gems"=>"How many gems does she charge for a letter,int|10",
			"Markun"=>"What letters does markun sell?,text|qrstuwxyzmakko",
			"Markun-gems"=>"How many gems does he charge for a letter,int|10",
			"Easter Egg Hunt - Points,title",
			"pointR"=>"Allow eggs to be redeemed?,bool|0",
			"pointsforname"=>"Points for making loginname?,int|10",
			"codeone"=>"Code one?,text|green",
			"pcodeone"=>"Points for making code one?,int|1",
			"codetwo"=>"Code two?,text|dragon",
			"pcodetwo"=>"Points for making code two?,int|2",
			"codethree"=>"Code three?,text|qexelcrag",
			"pcodethree"=>"Points for making code three?,int|3",
			"codefour"=>"Code four?,text|easter",
			"pcodefour"=>"Points for making code four?,int|4",
			"(only login redeeming can be turned off by setting points to 0),note",
			"Easter Egg Hunt - Points Rewards,title",
			"RPoi"=>"Allow points to be redeemed?,bool|0",
			"RPGem"=>"How many Gems per ten points?,int|1",
			"RPGold"=>"How much Gold per point?,int|2",
			"(users can choose to redeem one point for the gold reward or ten points for the gem reward,note",
			"Easter Egg Hunt - Pages,title",
			"hallfame"=>"Show users with most points in hall of fame?,bool|1",
			"pp"=>"Display how many pages in HoF listing?,range,1,100,1|10",
		),
		"prefs"=>array(
			"Easter Egg Hunt - Preferences,title",
			"letters"=>"Current Letters,text|",
			"(comma seperated left side is letter right side is amount),note",
			"vchance"=>"Vendor chances left?,int|3",
			"chance"=>"Seen all vendors?,bool|0",
			"curvendor"=>"Vendor?,enum,0,None,1,Abigail,2,Markun|0",
			"user_stats"=>"Show your eggs in your stats?,bool|1",
			"check_backpackshow"=>"Show info in your Backpack?,bool|1",
			"npoints"=>"Easter Egg Hunt points?,int|0",
			"predeemed"=>"Points redeemed?,int|0",
		),
		"requires"=>array(
			"eastertown" => "1.1|`@CortalUX, http://dragonprime.net/users/CortalUX/easterpack.zip",
			"easterbank" => "1.1|`@CortalUX, http://dragonprime.net/users/CortalUX/easterpack.zip",
		),
	);
	return $info;
}

function easteregghunt_install(){
	if (!is_module_active('easteregghunt')){
		output("`n`Q`b`cInstalling Easter Egg Hunt Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Easter Egg Hunt Module.`c`b`n");
	}
	module_addhook("checkuserpref");
	module_addhook("backpack");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("easterbank-text");
	module_addhook("easterbank-footer");
	module_addhook("footer-hof");
	module_addhook("charstats");
	module_addhook("training-victory");
	module_addhook("training-defeat");
	module_addhook("pvpwin");
	module_addhook("pvploss");
	module_addhook("battle-victory");
	module_addhook("battle-defeat");
	module_addeventhook("village","\$chance=get_module_pref(\"chance\", \"easteregghunt\");return (\$bought?0:50);");
	return true;
}

function easteregghunt_uninstall(){
	output("`n`Q`b`cUninstalling Easter Egg Hunt Module.`c`b`n");
	return true;
}

function easteregghunt_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "checkuserpref":
			$args['allow']=false;
			if (is_module_active('backpack')) {
				$args['allow']=true;
			}
		break;
		case "backpack":
			if (get_module_pref('check_backpackshow')) {
				output("`n`%You have the following amount of easter eggs...`n");
				output_notl(easteregghunt_getletters($session['user']['acctid'])."`n");
			}
		break;
		case "newday":
			set_module_pref("chance",0);
		break;
		case "villagetext":
			if (get_module_setting('pointR')==1&&$session['user']['location']==get_module_setting('villagename','eastertown')) {
				output("`n`Q`c`bRedeem your Easter Eggs in the Easter Bank!!!`b`c");
			}
			if (get_module_setting('RPoi')==1&&$session['user']['location']==get_module_setting('villagename','eastertown')) {
				output("`n`Q`c`bRedeem your Easter Egg Points in the Easter Bank!!!`b`c");
			}
			set_module_pref('curvendor',0);
		break;
		case "easterbank-text":
			if (get_module_setting('pointR')==1) {
				output("`n`Q\"`&By the way %s, I can redeem easter eggs for ye,`Q\" Whitton whispers, with a large smile.",$session['user']['sex']?"Miss":"Miladdo");
				output("`n`@Code one: `^%s",get_module_setting("codeone"));
				output("`n`@Code two: `^%s",get_module_setting("codetwo"));
				output("`n`@Code three: `^%s",get_module_setting("codethree"));
				output("`n`@Code four: `^%s",get_module_setting("codefour"));
				if (get_module_setting("pointsforname")>0) {
					output("`n`@And you can redeem your login.");
				}
			}
		break;
		case "easterbank-footer":
			addnav("Easter Egg Points");
			if (get_module_setting('pointR')==1) {
				addnav("Redeem Eggs","runmodule.php?module=easteregghunt&op=redeem");
			} else {
				addnav("Talk to Whitton","runmodule.php?module=easteregghunt&op=talk");
			}
			if (get_module_setting('RPoi')==1) {
				addnav("Redeem Egg Points","runmodule.php?module=easteregghunt&op=predeem");
			}
		break;
		case "footer-hof":
			if (get_module_setting('hallfame')==1) {
				addnav("Warrior Rankings");
				addnav("Easter Egg Hunt", "runmodule.php?module=easteregghunt&op=hallfame");
			}
		break;
		case "charstats":
			if (get_module_pref('user_stats')==1) {
				addcharstat("Personal Info");
				addcharstat("Easter Egg Letters",easteregghunt_getletters($session['user']['acctid']));
			}	
			if (get_module_setting('pointR')==1) {
				addcharstat("Easter Egg Points",(int)get_module_pref('npoints'));
			}
			if (get_module_setting('RPoi')==1) {
				addcharstat("Easter Egg Points Redeemed",(int)get_module_pref('predeemed'));
			}
		break;
		case "training-victory":
			$l = easteregghunt_inrletter("trainingwin");
			easteregghunt_addletter($session['user']['acctid'],$l,1);
			output("`n`^Your old Master hands you a letter `@%s`^ Egg for the Easter Egg hunt.",$l);
		break;
		case "training-defeat":
			$l = easteregghunt_inrletter("trainingdefeat");
			easteregghunt_addletter($session['user']['acctid'],$l,1);
			output("`n`^Your Master hands you a letter `@%s`^ Egg for the Easter Egg hunt.",$l);
		break;
		case "pvpwin":
			easteregghunt_addletter($session['user']['acctid'],"P",2);
			output("`n`^You find two letter `@P`^ Eggs lying on the ground for the Easter Egg hunt.");
		break;
		case "pvploss":
			$l = easteregghunt_inrletter("pvplose");
			if (easteregghunt_amletter($session['user']['acctid'],$l)>0) {
				easteregghunt_setletter($session['user']['acctid'],0,$l);
				output("`n`c`b`@While you keel over from losing the battle, you drop all your letter `^%s`@ eggs for the easter egg hunt.`b`c`0",$l);
			}
		break;
		case "battle-victory":
			if($args['type']=="forest"&&e_rand(1,10)==1) {
				$l = easteregghunt_inrletter("forestwin");
				easteregghunt_addletter($session['user']['acctid'],$l,1);
				output("`n`^You find a letter `@%s`^ egg lying on the ground for the Easter Egg hunt.",$l);
			}
		break;
		case "battle-defeat":
			if ($args['type']=="forest"&&e_rand(1,10)==1) {
				$l = easteregghunt_inrletter("forestlose");
				if (easteregghunt_amletter($session['user']['acctid'],$l)>0) {
					easteregghunt_setletter($session['user']['acctid'],0,$l);
					output("`n`c`b`@While you keel over from losing the battle, you drop all your letter `^%s`@ eggs for the easter egg hunt.`b`c`0",$l);
				}
			}
		break;
	}
	return $args;
}

function easteregghunt_run(){
	global $session;
	$op = httpget('op');
	set_module_pref('curvendor',0);
	switch ($op) {
		case "hallfame":
			easteregghunt_hallfame();
		break;
		case "redeem":
			easteregghunt_redeem();
		break;
		case "predeem":
			easteregghunt_predeem();
		break;
		case "talk":
			easteregghunt_talk();
		break;
	}
}

function easteregghunt_talk() {
	global $session;
	page_header("The Egg Bank");
	addnav("Navigation");
	addnav("R?Return to the Egg Bank","runmodule.php?module=easterbank");
	villagenav();
	output("`7\"`&I haven't started redeeming eggs yet....`7\" Whitton says.");
	page_footer();
}

function easteregghunt_redeem() {
	global $session;
	page_header("The Egg Bank");
	addnav("Navigation");
	addnav("R?Return to the Egg Bank","runmodule.php?module=easterbank");
	villagenav();
	addnav("Easter Eggs");
	$type = httpget('type');
	$conf = httpget('conf');
	if ($conf=="yes") {
		if ($type!='one') {
			$code = easteregghunt_filter($session['user']['login']);
			$points = get_module_setting("pointsforname");
			$n = "yer login";
		} else {
			$code = easteregghunt_filter(get_module_setting("code".$type));
			$points = get_module_setting("pcode".$type);
			$n = "code ".$type;
		}
		foreach (easteregghunt_str_split($code) as $x) {
			easteregghunt_remletter($session['user']['acctid'],$x,1);
		}
		set_module_pref('npoints',get_module_pref('npoints')+$points);
		output("`Q\"`&Here ye go, %s points for %s.`Q\" Whitton says, as he hands %s points to you.",$points,$n,$points);
	} else {
		output("`Q\"`&So, ye wan me ta redeem eggs for ye. I can redeem easter eggs for ye %s,`Q\" Whitton whispers, with a large smile.",$session['user']['sex']?"Miss":"Miladdo");
	}
	output("`n`@Code one: `^%s",easteregghunt_filter(get_module_setting("codeone")));
	output("`n`@Code two: `^%s",easteregghunt_filter(get_module_setting("codetwo")));
	output("`n`@Code three: `^%s",easteregghunt_filter(get_module_setting("codethree")));
	output("`n`@Code four: `^%s",easteregghunt_filter(get_module_setting("codefour")));
	output("`n`#Code one redeems %s points, code two redeems %s points, code three redeems %s points and code four redeems %s points.",get_module_setting('pcodeone'),get_module_setting('pcodetwo'),get_module_setting('pcodethree'),get_module_setting('pcodefour'));
	if (get_module_setting("pointsforname")>0) {
		output("`n`@Your Login Eggs are '`^%s`@' and I can redeem that fer `#%s`@ points.",easteregghunt_filter($session['user']['login']),get_module_setting("pointsforname"));
		if (easteregghunt_lcheck($session['user']['acctid'],easteregghunt_filter($session['user']['login']))) {
			output("`n`QYe have the eggs for %s.","yer login");
			addnav("Redeem Yer Login","runmodule.php?module=easteregghunt&op=redeem&type=login&conf=yes");
		} else {
			output("`n`%Ye haven't got the eggs for %s.",translate_inline("yer login"));
		}
	}
	if (easteregghunt_lcheck($session['user']['acctid'],easteregghunt_filter(get_module_setting("codeone")))) {
		output("`n`QYe have the eggs for %s.",translate_inline("code one"));
		addnav("Redeem Code One","runmodule.php?module=easteregghunt&op=redeem&type=one&conf=yes");
	} else {
		output("`n`%Ye haven't got the eggs for %s.",translate_inline("code one"));
	}
	if (easteregghunt_lcheck($session['user']['acctid'],easteregghunt_filter(get_module_setting("codetwo")))) {
		output("`n`QYe have the eggs for %s.",translate_inline("code two"));
		addnav("Redeem Code Two","runmodule.php?module=easteregghunt&op=redeem&type=two&conf=yes");
	} else {
		output("`n`%Ye haven't got the eggs for %s.",translate_inline("code two"));
	}
	if (easteregghunt_lcheck($session['user']['acctid'],easteregghunt_filter(get_module_setting("codethree")))) {
		output("`n`QYe have the eggs for %s.",translate_inline("code three"));
		addnav("Redeem Code Three","runmodule.php?module=easteregghunt&op=redeem&type=three&conf=yes");
	} else {
		output("`n`%Ye haven't got the eggs for %s.",translate_inline("code three"));
	}
	if (easteregghunt_lcheck($session['user']['acctid'],easteregghunt_filter(get_module_setting("codefour")))) {
		output("`n`QYe have the eggs for %s.",translate_inline("code four"));
		addnav("Redeem Code Four","runmodule.php?module=easteregghunt&op=redeem&type=four&conf=yes");
	} else {
		output("`n`%Ye haven't got the eggs for %s.",translate_inline("code four"));
	}
	page_footer();
}

function easteregghunt_runevent($type) {
	global $session;
	$vchance = get_module_pref('vchance');
	$chance = get_module_pref('chance');
	if ($vchance<=0) {
		set_module_pref('chance',1);
		set_module_pref('vchance',3);
	} elseif (get_module_pref('curvendor')!=0) {
		easteregghunt_vendor();
	} elseif (get_module_pref('curvendor')==0) {
		set_module_pref('vchance',$vchance-1);
		$t = e_rand(1,2);
		set_module_pref('curvendor',$t);
		easteregghunt_vendor();
	}
}

function easteregghunt_vendor() {
	global $session;
	$array=array();
	$array['1']['name']="Abigail";
	$array['1']['male']="Sir";
	$array['1']['female']="Madam";
	$array['1']['wear']="a diminutive elf in a green cloak";
	$array['1']['greet']="Happy Easter to ye, %s!";
	$array['2']['name']="Markun";
	$array['2']['male']="Miladdo";
	$array['2']['female']="Miss";
	$array['2']['wear']="a huge elf in a set of chainmail";
	$array['2']['greet']="Ello, me old footfungus! Stop staring %s!";
	$cur = get_module_pref('curvendor');
	$from = "village.php?";
	$gemword="gems";
	$cost=get_module_setting($array[$cur]['name']."-gems");
	if ($cost==1){
		$gemword="gem";
	}
	$op = httpget('op');
	if ($op == "") {
		output("`7While you are wandering idly, minding your own business, you are approached by %s.`n`n",$array[$cur]['wear']);
		$greeting = translate_inline($session['user']['sex']?$array[$cur]['female']:$array[$cur]['male']);
		output("\"`&".$array[$cur]['greet'], $greeting);
		output("`nCan I interest you in an egg for the competition?");
		if($session['user']['gems']<$cost){
			if($session['user']['gems']==0){
				output("`7".$array[$cur]['name']." stares at your empty hand.`n`n");
			} else {
				if($session['user']['gems']==1){
					output("`7".$array[$cur]['name']." stares at the single gem in your hand.`n`n");
				} else {
					output("`7".$array[$cur]['name']." stares at the %s gems in your hand.`n`n", $session['user']['gems']);
				}
			}
			output("`7How can you buy an egg without enough gems?");
			addnav("Walk Away",$from."op=leave");
		} else {
			$str = easteregghunt_filter(get_module_setting($array[$cur]['name']));
			$d="";
			if ($str=='') $str = 'abcdef';
			$i = 0;
			$x = strlen($str);
			while ($i<$x) {
				$d.=substr($str, $i, 1)." ";
					$i++;
			}
			output("`n`@I stock the following eggs... `^%s`n",$d);
			if ($cost == 1) {
				output("And, for you, only `%one`^ gem for an egg!");
			} else  {
				output("And, for you, only `%%s`^ gems for an egg!", $cost);
			}
			output_notl("`7\"`n`n");
			output("`7You try to decide which egg to choose..");
			output("`n`@Click to Choose:`^ ");
			foreach (easteregghunt_str_split(easteregghunt_filter(get_module_setting($array[$cur]['name']))) as $l) {
				output_notl("<a href='".$from."op=shop&l=%s'>%s</a> ",$l,$l,true);
				addnav("",$from."op=shop&l=$l");
			}
			addnav("Don't buy anything",$from."op=nope");
		}
		$session['user']['specialinc'] = "module:easteregghunt";
	}elseif($op=="nope"){
		output("`7You decide not to buy an egg from ".$array[$cur]['name'].".`n`n");
		$session['user']['specialinc'] = "";
		set_module_pref('curvendor',0);
	}elseif($op=="shop"){
		$l = httpget('l');
		set_module_pref("bought",1);
		$session['user']['gems']-=$cost;
		debuglog("spent $cost gems on the $l egg");
		if ($cost == 1) {
			output("`@Agreeing to buy the `^%s`@ egg, you hand over a gem.", $l);
		} else {
			output("`@Agreeing to buy the `^%s`@ egg, you hand over the `^%s`@ gems.", $l, $cost);
		}
		output("`n`^%s`@ gives you the `^%s`@ egg.`n`n", $array[$cur]['name'],$l);
		easteregghunt_addletter($session['user']['acctid'],$l,1);
		$session['user']['specialinc'] = "";
		villagenav();
		set_module_pref('curvendor',0);
	} elseif ($op == "leave") {
		output("`5Not having any gems to buy an egg for the competition, you walk away.`n`n");
		$session['user']['specialinc'] = "";
		set_module_pref('curvendor',0);
	}
}

function easteregghunt_hallfame() {
	global $session;
	$page = httpget('page');
	$type=httpget('type');
	if (httpget('type')=='') $type='npoints';
	page_header("Hall of Fame");
	$pp = get_module_setting("pp");
	$pageoffset = (int)$page;
	if ($pageoffset > 0) $pageoffset--;
	$pageoffset *= $pp;
	$limit = "LIMIT $pageoffset,$pp";
	$sql = "SELECT COUNT(userid) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'easteregghunt' AND setting = '$type' AND value >= 1";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	$count = db_num_rows($result);
	if (($pageoffset + $pp) < $total){
		$cond = $pageoffset + $pp;
	}else{
		$cond = $total;
	}
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name, ".db_prefix("accounts").".acctid FROM ".db_prefix("module_userprefs").",".db_prefix("accounts"). " WHERE acctid = userid AND modulename = 'easteregghunt' AND setting = '$type' AND value >= 1 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	rawoutput("<big>");
	if ($type=='npoints') {
		$poi = translate_inline("Egg Points");
		output("`c`b`^Easter Egg Points`b`c`0`n");
	} else {
		$poi = translate_inline("Egg Points Redeemed");
		output("`c`b`^Easter Egg Points Redeemed`b`c`0`n");
	}
	rawoutput("</big>");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' width='95%' align='center' >");
	rawoutput("<tr class='trhead'><td width='2%'>$rank</td><td>$name</td><td width='3%'>$poi</td></tr>");
	if (db_num_rows($result)>0){
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			} else {
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`c`@%s`c`0",$row['value']);
			rawoutput("</td></tr>");
		}
	} else {
		if ($type='points') {
			rawoutput("<tr class='trhilight'><td>0.</td><td colspan='2' class='colLtYellow'>".translate_inline("No one has any points...")."</td></tr>");
		} else {
			rawoutput("<tr class='trhilight'><td>0.</td><td colspan='2' class='colLtYellow'>".translate_inline("No one has redeemed any points...")."</td></tr>");
		}
	}
	rawoutput("</table>");
	if ($total>$pp){
		addnav("Pages");
		for ($p=0;$p<$total;$p+=$pp){
			addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=easteregghunt&op=hallfame&type=$type&page=".($p/$pp+1));
		}
	}
	addnav("Navigation");
	addnav("Back to HoF", "hof.php");
	villagenav();
	addnav("Other");
	addnav("Show Points", "runmodule.php?module=easteregghunt&type=npoints&op=hallfame");
	addnav("Show Redeemed Points", "runmodule.php?module=easteregghunt&type=predeemed&op=hallfame");
	page_footer();
}

function easteregghunt_getarray($user=1) {
	$letters = get_module_pref('letters','easteregghunt',$user);
	$x = explode(",", $letters);
	$z = array();
	foreach ($x as $val) {
		if ($val!="") {
			$y = explode("|", $val);
			$a = $y[0];
			$b = $y[1];
			if ($a!=""&&$b!="") $z[$a]=$b;
		}
	}
	return $z;
}

function easteregghunt_setarray($user=1,$array) {
	$w =(array)$array;
	$y = 0;
	$b=count($array);
	$x="";
	foreach ($w as $letter => $amount) {
		if ($letter!=""&&$amount!="") {
			$y++;
			if ($y==1) {
				$x=$letter."|".$amount;
			} else {
				$x.=",".$letter."|".$amount;
			}
		}
	}
	load_module_prefs('easteregghunt',$user); // Otherwise we get a weird 'duplicate key entry' error
	set_module_pref('letters',$x,'easteregghunt',$user);
	return $z;
}

function easteregghunt_getletters($user=1) {
	$x = easteregghunt_getarray($user);
	$pp = count($x);
	$y = 0;
	$z = $pp-1;
	$string="";
	foreach ($x as $letter => $amount) {
		if ($letter!=''&&$amount!=''&&is_numeric($amount)) {
			$y++;
			$string .= "`^$letter `@(`&$amount`@)";
			if ($y==$z) {
				$string.=" `&".translate_inline("and")." ";
			} elseif ($y==$pp) {
				$string.="`&.";
			} else {
				$string.="`&, ";
			}
		}
	}
	if ($y==0) {
		$string = "`%".translate_inline("You have no easter egg letters.");
	}
	return $string;
}

function easteregghunt_addletter($user=1,$letter="A",$amount=1) {
	$w = (array)easteregghunt_getarray($user);
	$x = strtoupper($letter);
	if (isset($w[$x])) {
		$w[$x]+=$amount;
	} else {
		$w[$x]=$amount;
	}
	easteregghunt_setarray($user,$w);
}

function easteregghunt_remletter($user=1,$letter="A",$amount=1) {
	$w = easteregghunt_getarray($user);
	$x = strtoupper($letter);
	if (isset($w[$x])) {
		$w[$x]-=$amount;
		if ($w[$x]<=0) {
			unset($w[$x]);
		}
	}
	easteregghunt_setarray($user,$w);
}

function easteregghunt_amletter($user=1,$letter="A") {
	$w = easteregghunt_getarray($user);
	$x = strtoupper($letter);
	if (isset($w[$x])) {
		$t=(int)$w[$x];
	} else {
		$t=(int)0;
	}
	return $t;
}

function easteregghunt_setletter($user=1,$amount=1,$letter="A") {
	$w = easteregghunt_getarray($user);
	$x = strtoupper($letter);
	$w[$x]=$amount;
	easteregghunt_setarray($user,$w);
}

function easteregghunt_outrletter($nletters) {
	$letters = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
	foreach ($nletters as $val) {
		if (in_array(strtoupper($val),$letters,true)) {
			$t = array_search($val, $letters);
			unset($letters[$t],$t);
		}
	}
	$z = array_rand($letters, 1);
	return $letters[$z];
}

function easteregghunt_inrletter($l) {
	$x = easteregghunt_str_split($l);
	$letters = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
	foreach ($letters as $val) {
		if (!in_array(strtoupper($val), $x,true)) {
			$t = array_search($val, $letters);
			unset($letters[$t],$t);
		}
	}
	$z = array_rand($letters, 1);
	return $letters[$z];
}

function easteregghunt_lcheck($user=1,$letters) {
	$x = easteregghunt_str_split(easteregghunt_filter($letters));
	$y = easteregghunt_getarray($user);
	$z = array();
	foreach ($x as $val) {
		if (isset($z[$val])) {
			$z[$val]++;
		} else {
			$z[$val]=1;
		}
	}
	$t = true;
	foreach ($z as $a => $b) {
		if ($y[$a]<$b) {
			echo $y[$a];
			$t = false;
		}
	}
	return $t;
}

function easteregghunt_filter($l="") {
	$letters = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
	$x = easteregghunt_str_split($l);
	$y = "";
	foreach ($x as $val) {
		if (in_array(strtoupper($val), $letters, true)===true) {
			$y.=strtoupper($val);
		}
	}
	return $y;
}

function easteregghunt_str_split($the_string="", $the_number=1) {
	// PHP5 has the 'easteregghunt_str_split' function
	// PHP4 which has the most common usage DOESN'T thought
	// The curly braces can also be substituted for the substr function
	// This function has slightly more load than easteregghunt_str_split in PHP5 does, so I'll have to remember not to use it too much.
	$startoff_nr = 0;
	$the_output_array = array();
	for($z = 1; $z < ceil(strlen($the_string)/$the_number)+1 ; $z++) {    
		$startoff_nr = ($the_number*$z)-$the_number;
		$the_output_array[] = strtoupper(substr($the_string, $startoff_nr, $the_number));
	}
	return($the_output_array);
}

function easteregghunt_predeem() {
	global $session;
	$type = httpget('type');
	page_header("The Egg Bank");
	$ten = get_module_setting('RPGem');
	$one = get_module_setting('RPGold');
	$points = get_module_pref('npoints');
	$redeemed = get_module_pref('predeemed');
	$spend = $points-$redeemed;
	if ($ten<=0) $ten=1;
	if ($one<=0) $one=1;
	if ($type=='one') {
		$spend--;
		$redeemed++;
		$session['user']['gold']+=$one;
		output("`@After redeeming a point with `QWhitton`@, he hands you %s Gold.`n`n",$one);
	} elseif ($type=='ten') {
		$spend-=10;
		$redeemed+=10;
		$session['user']['gems']+=$ten;
		$word = $ten.translate_inline(' Gems');
		if ($ten==1)$word = translate_inline('a Gem');
		output("`@After redeeming ten points with `QWhitton`@, he hands you %s.`n`n",$word);
	}
	addnav("Navigation");
	addnav("R?Return to the Egg Bank","runmodule.php?module=easterbank");
	villagenav();
	addnav("Easter Egg Points");
	output("`n`Q\"`&Ye've redeemed %s points, and ye have %s. Ye can redeem %s more points, %s.`Q\" Whitton whispers, with a large smile.",$redeemed,$points,$spend,$session['user']['sex']?"Miss":"Miladdo");
	if ($spend>=10) {
		addnav("Redeem Ten Points","runmodule.php?module=easteregghunt&op=predeem&type=ten");
		$word = $ten.translate_inline(' Gems');
		if ($ten==1)$word = translate_inline('a Gem');
		output("`n`Q\"`&Ye can spend ten points te gain %s.`Q\" Whitton explains.",$word);
	} else {
		$word = $ten.translate_inline(' Gems');
		if ($ten==1)$word = translate_inline('a Gem');
		output("`n`Q\"`&Ye haven't ten points to spend, for %s.`Q\" Whitton sighs.",$word);
	}
	if ($spend>=1) {
		addnav("Redeem One Point","runmodule.php?module=easteregghunt&op=predeem&type=one");
		output("`n`Q\"`&Ye can spend a point fer %s Gold.`Q\" Whitton explains.",$one);
	} else {
		output("`n`Q\"`&Ye haven't a point for %s Gold.`Q\" Whitton sighs.",$one);
	}
	set_module_pref('predeemed',$redeemed);
	page_footer();
}
?>