<?php
/*
Details:
 * This is an easter town
 * It is part of the easter pack
 * Based upon 'icetown' by Shannon Brown
History Log:
 v1.0:
 o Seems to be Stable
*/

function eastertown_getmoduleinfo(){
	$info = array(
		"name"=>"Easter Town",
		"version"=>"1.1",
		"author"=>"`@CortalUX",
		"category"=>"Village",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/easterpack.zip",
		"settings"=>array(
			"Easter Town - General Settings,title",
			"villagename"=>"Name for the Easter town|Haystable",
		),
		"prefs"=>array(
			"Easter Town - General Prefs,title",
			"vg"=>"Village guard text?,bool|0",
			"fg"=>"Forest guard text?,bool|0",
			"tg"=>"Travel guard text?,bool|1",
		),
	);
	return $info;
}

function eastertown_install(){
	module_addhook("villagetext");
	module_addhook("footer-forest");
	module_addhook("travel");
	module_addhook("validlocation");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("stabletext");
	module_addhook("footer-runmodule");
	return true;
}

function eastertown_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	return true;
}

function eastertown_dohook($hookname,$args){
	global $session,$resline;
	$city = get_module_setting("villagename");
	switch($hookname){
		case "travel":
			$capital = getsetting("villagename", LOCATION_FIELDS);
			$hotkey = substr($city, 0, 1);
			tlschema("module-cities");
			if ($session['user']['location']!=$city){
				addnav("More Dangerous Travel");
				// Actually make the travel dangerous
				addnav(array("%s?Go to %s", $hotkey, $city),
						"runmodule.php?module=cities&op=travel&city=$city&d=1");
			}
			if ($session['user']['superuser'] & SU_EDIT_USERS){
				addnav("Superuser");
				addnav(array("%s?Go to %s", $hotkey, $city),
						"runmodule.php?module=cities&op=travel&city=$city&su=1");
			}
			if (get_module_pref('tg')==0) {
				set_module_pref('tg',1);
				output("`n`@Upon leaving the village, guards hand your weapons back.");
			}
			tlschema();
		break;
		case "footer-runmodule":
			$module = httpget('module');
			if ($module=='worldmap') {
				if (get_module_pref('tg')==0) {
					set_module_pref('tg',1);
					output("`n`@Upon leaving the village, guards hand your weapons back.");
				}
			} elseif ($module=='estbreak'||$module=='breakin') {
				if (get_module_pref('vg')==1) {
					set_module_pref('vg',0);
					output("`n`@Hearing drunken Guards walk past along the street, you throw a stone at one of them, and he drops whatever he was carrying.");
					output("`nYou hear a clatter and sneak up to the Guards in the shadows, and, in a pile of weapons, you manage to take your %s`0`@ back, without anyone noticing.",$session['user']['weapon']);
				}
			}
		break;
		case "changesetting":
			// Ignore anything other than villagename setting changes
			if ($args['setting']=="villagename" && $args['module']=="eastertown") {
				if ($session['user']['location'] == $args['old']) {
					$session['user']['location'] = $args['new'];
				}
				$sql = "UPDATE " . db_prefix("accounts") . " SET location='" .
					$args['new'] . "' WHERE location='" . $args['old'] . "'";
				db_query($sql);
			}
		break;
		case "validlocation":
				$args[$city]="village-eastertown";
		break;
		case "moderate":
			if (is_module_active("cities")) {
				tlschema("commentary");
				$args["village-eastertown"]=sprintf_translate("%s, the Village of Easter", $city);
				tlschema();
			}
		break;
		case "footer-forest":
			if ($session['user']['location']==$city) {
				if (get_module_pref('fg')==0) {
					set_module_pref('fg',1);
					set_module_pref('vg',0);
					output("`n`@Upon entering the Forest the village guards hand you your weapons back.");
				}
			}
		break;
		case "footer-inn":
			if ($session['user']['location']==$city) {
				blocknav("pvp.php",true);
				if (httpget('act')=='listupstairs') {
					output("`nHowever, checking your belt, you remember you left your weapons with the Guards.");
				}
			}
		break;
		case "villagetext":
			if ($session['user']['location'] == $city){
				set_module_pref('tg',0);
				if (get_module_pref('fg')==1) {
					set_module_pref('fg',0);
				}
				if (get_module_pref('vg')==0) {
					set_module_pref('vg',1);
					output("`n`@Upon entering the village, guards force you to hand over your weapons, ignoring your armour.");
				}
				$args['text']=array("`Q`c`b%s, the town of Easter`b`c`n`^You stand in the centre of a small country village, having submitted your weapon to the Guards. All around you animals frolic, from Chickens in free-ranging paddocks, to Horses in their stables. The Villagers are warm and friendly, calmly settling their disputes. These people are safe from the Dragon, it has never yet approached them, and no one has ever found out why.`nOn one side of the Street, a local brewery stands, and a forest surrounds the eastern side of the village, while the western side of the village holds a magnificent stable.`n", $city, $city);
				$args['schemas']['text'] = "module-eastertown";
				$args['clock']="`n`7The clock on the stables reads `&%s`7.`n";
				$args['schemas']['clock'] = "module-eastertown";
				if (is_module_active("calendar")) {
					$args['calendar']="`n`7The calendar on the brewery reads `&%s`7, `&%s %s %s`7.`n";
					$args['schemas']['calendar'] = "module-eastertown";
				}
				$args['title']=array("%s, the Easter Town", $city);
				$args['schemas']['title'] = "module-eastertown";
				$args['sayline']="`3smiles, and says";
				$args['schemas']['sayline'] = "module-eastertown";
				$args['talk']="`n`&Nearby some visitors happily sit chatting:`n";
				$args['schemas']['talk'] = "module-eastertown";
				$args['newest'] = "";
				blocknav("lodge.php");
				blocknav("weapons.php");
				blocknav("pvp.php");
				blocknav("gypsy.php");
				blocknav("bank.php");
				blockmodule("tynan");
				blockmodule("spookygold");
				blockmodule("caravan");
				blockmodule("clantrees");
				blockmodule("peerpressure");
				$args['schemas']['newest'] = "module-eastertown";
				$args['gatenav']="Village Gates";
				$args['schemas']['gatenav'] = "module-eastertown";
				$args['fightnav']="The Donkey Fighter";
				$args['schemas']['fightnav'] = "module-eastertown";
				$args['marketnav']="Shop Street";
				$args['schemas']['marketnav'] = "module-eastertown";
				$args['tavernnav']="The Local Brewery";
				$args['schemas']['tavernnav'] = "module-eastertown";
				$args['section']="village-eastertown";
				$args['infonav']="The Nest";
				$args['schemas']['infonav'] = "module-eastertown";
			}
		break;
		case "footer-forest":
			blockmodule("dragonplace");
			blocknav("forest.php?op=dragon",true);
		break;
		case "stabletext":
			if ($session['user']['location'] != $city) break;
			$args['title'] = "Tanat's Stables";
			$args['schemas']['title'] = "module-eastertown";
			$args['desc'] = "`^You are standing in a stable on the western side of the village.`nAn Elf rushes up to you, and introduces herself as Tanat.`n. `3\"`QAh! %s, what can I do for you?`3\", she asks in a melodious tonal voice. \"`QWould you like to buy one of my Magnificent beasts?`3\" she says, fondly stroking a little pony. `^Nodding slightly, you indicate assent, and walk with Tanat.";
			$args['schemas']['desc'] = "module-eastertown";
			$args['lad']="Sir";
			$args['schemas']['lad'] = "module-eastertown";
			$args['lass']="Madam";
			$args['schemas']['lass'] = "module-eastertown";
			$args['nosuchbeast']="`3\"`QI'm sorry, I don't have such a creature.`3\", Tanat says, wrinkling her brow slightly.";
			$args['schemas']['nosuchbeast'] = "module-eastertown";
			$args['finebeast']=array(
				"`3\"`QOne of my favourite creatures, I'll miss it so much! I'll have to be paid in advance!`3\", says Tanat.`n`n",
				"`3\"`QAh, a fine creature!`3\", Tanat says, with a wide smile on her face.`n`n",
				"`3\"`QDoesn't this one catch your fancy?`3\". she asks.`n`n",
				"`3\"`QI suppose this one is OK...`3\". enunciates Tanat.`n`n",
				"`3\"`QSorry, this is nowhere near good enough for you. It's only half trained.`3\", grimaces Tanat.`n`n",
				);
			$args['schemas']['finebeast'] = "module-eastertown";
			$args['toolittle']="`%Tanat looks over the gold and gems you offer and turns up her nose, `3\"`QObviously you don't have enough. This %s costs `&%s `Qgold  and `%%s`Q gems.`3\"";
			$args['schemas']['toolittle'] = "module-eastertown";
			$args['replacemount']="`%Waving fondly at your `^%s`%, you hand the reins as well as the money for your new creature, and Tanat`% shows you the reins to a `&%s`%.";
			$args['schemas']['replacemount'] = "module-eastertown";
			$args['newmount']="`@You hand over the money for your new creature, and Tanat shows you the reins of to a new `&%s`@.";
			$args['schemas']['newmount'] = "module-eastertown";
			$args['nofeed']="`3\"`Q%s, I don't stock feed here. I'm not a common stable. Perhaps you should look elsewhere to feed your creature.`3\" Tanat sighs.";
			$args['schemas']['nofeed'] = "module-eastertown";
			$args['nothungry']="`&%s`^ picks briefly at the food and then ignores it.  Tanat, pockets the gold, and shakes her head.";
			$args['schemas']['nothungry'] = "module-eastertown";
			$args['halfhungry']="`&%s`^dives into the provided food and gets through about half of it before stopping.  \"`^Well, it wasn't as hungry as you thought.`^\" says Tanat as she keeps %s gold.";
			$args['schemas']['halfhungry'] = "module-eastertown";
			$args['hungry']="`^%s`^ seems to inhale the food provided.  %s`^, the greedy creature that it is, then starts to go snuffling at Tanat's pockets for more food. She takes `&%s`^ gold from you, and fondles your beast happily.";
			$args['schemas']['hungry'] = "module-eastertown";
			$args['mountfull']="`n`^\"`^Well, %s, your %s`^ was truly hungry today, but I've filled it up now.`^\", says Tanat.";
			$args['schemas']['mountfull'] = "module-eastertown";
			$args['nofeedgold']="`^\"`^I'm sorry, but that is just not enough money to pay for food here.`^\"  Tanat grimaces as you lead your %s away to find other places for feeding.";
			$args['schemas']['nofeedgold'] = "module-eastertown";
			$args['confirmsale']="`n`n`^Tanat eyes your mount up and down, checking it over carefully.  \"`^Are you sure you don't want to keep this fine creature?`^\"";
			$args['schemas']['confirmsale'] = "module-eastertown";
			$args['mountsold']="`^With but a single tear, you hand over the reins to your %s`^ to Tanat. She gives you %s in hand, and you look away.";
			$args['schemas']['mountsold'] = "module-eastertown";
			$args['offer']="`n`n`^Tanat offers you `&%s`^ gold and `%%s`^ gems for your %s`^.";
			$args['schemas']['offer'] = "module-eastertown";
		break;
		case "stablelocs":
			tlschema("mounts");
			$args[$city]=sprintf_translate("%s, the Village of Easter", $city);
			tlschema();
		break;
	}
	return $args;
}

function eastertown_run(){
}
?>
