<?php
/*
Details:
 * This is where all potions should hooj to
History Log:
 * Version 1.0:
   o Seems to be stable
   o DHTML tooltip script.. legal notice:
   /***********************************************
   * Cool DHTML tooltip script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
   * This notice MUST stay intact for legal use
   * Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
   ************************************************
*/
require_once("lib/commentary.php");
require_once("lib/villagenav.php");

function potionshop_getmoduleinfo(){
	$info = array(
		"name"=>"The Potion Shop",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/potionshop.zip",
		"allowanonymous"=>true,
		"override_forced_nav"=>false,
		"settings"=>array(
			"Potion Shop - Settings,title",
			"adminPotion"=>"Admin have access to all potions?,bool|1",
			"(admin are those that can edit users),note",
			"hook"=>"Hook the shop to a single place?,bool|0",
			"place"=>"If yes- Where is the Potion shoppe location?,location|".getsetting("villagename", LOCATION_FIELDS),
			"pMove"=>"Should the shoppe randomly move?,bool|0",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"check_show"=>"Show info in your Backpack?,bool|1",
		),
	);
	return $info;
}

function potionshop_install(){
	if (!is_module_active('movepotion')){
		output("`n`Q`b`cInstalling Potion Shop Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Potion Shop Module.`c`b`n");
	}
	module_addhook("checkuserpref");
	module_addhook("newday-runonce");
	module_addhook("changesetting");
	module_addhook_priority("potionshop-navs",1);
	module_addhook_priority("everyheader",1);
	module_addhook("village");
	module_addhook("moderate");
	return true;
}

function potionshop_uninstall(){
	output("`n`Q`b`cUninstalling Potion Shop Module.`c`b`n");
	return true;
}

function potionshop_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "checkuserpref":
			$args['allow']=false;
			if (is_module_active('backpack')) {
				if (get_module_pref('potions')!=''||get_module_pref('freepot')>0) {
					$args['allow']=true;
				}
			}
		break;
		case "newday-runonce":
			if (get_module_setting('pMove')==1) {
				$vloc = array();
				$vname = getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] = "village";
				$vloc = modulehook('validlocation', $vloc);
				$key = array_rand($vloc);
				set_module_setting('place',$key);
			}
		break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("place")) {
					set_module_setting("place", $args['new']);
				}
			}
		break;
		case "potionshop-navs":
			addnav("Navigation");
			villagenav();
			if (httpget('module')!='potionshop') addnav("Return to the Counter","runmodule.php?module=potionshop");
			addnav("Buy Potions");
		break;
		case "everyheader":
			$script = "<style type=\"text/css\">\n#dhtmltooltip{\ncolor:#000000;\nposition: absolute;\nwidth: 150px;\nborder: 2px solid black;\npadding: 2px;\nbackground-color: lightyellow;\nvisibility: hidden;\nz-index: 100;\nfilter: progid:DXImageTransform.Microsoft.Shadow(color=gray,direction=135);\n!important}\n</style>";
			$script .= "\n<div id=\"dhtmltooltip\"></div>";
			$script .= "\n<script type=\"text/javascript\">";
			$script .= "\nvar offsetxpoint=-60 //Customize x offset of tooltip";
			$script .= "\nvar offsetypoint=20 //Customize y offset of tooltip";
			$script .= "\nvar ie=document.all";
			$script .= "\nvar ns6=document.getElementById && !document.all";
			$script .= "\nvar enabletip=false";
			$script .= "\nif (ie||ns6)";
			$script .= "\nvar tipobj=document.all? document.all[\"dhtmltooltip\"] : document.getElementById? document.getElementById(\"dhtmltooltip\") : \"\"";
			$script .= "\n";
			$script .= "\nfunction ietruebody(){";
			$script .= "\nreturn (document.compatMode && document.compatMode!=\"BackCompat\")? document.documentElement : document.body";
			$script .= "\n}";
			$script .= "\n";
			$script .= "\nfunction ddrivetip(thetext, thecolor, thewidth){";
			$script .= "\nif (ns6||ie){";
			$script .= "\nif (typeof thewidth!=\"undefined\") tipobj.style.width=thewidth+\"px\"";
			$script .= "\nif (typeof thecolor!=\"undefined\" && thecolor!=\"\") tipobj.style.backgroundColor=thecolor";
			$script .= "\ntipobj.innerHTML=thetext";
			$script .= "\nenabletip=true";
			$script .= "\nreturn false";
			$script .= "\n}";
			$script .= "\n}";
			$script .= "\n";
			$script .= "\nfunction positiontip(e){";
			$script .= "\nif (enabletip){";
			$script .= "\nvar curX=(ns6)?e.pageX : event.x+ietruebody().scrollLeft;";
			$script .= "\nvar curY=(ns6)?e.pageY : event.y+ietruebody().scrollTop;";
			$script .= "\n//Find out how close the mouse is to the corner of the window";
			$script .= "\nvar rightedge=ie&&!window.opera? ietruebody().clientWidth-event.clientX-offsetxpoint : window.innerWidth-e.clientX-offsetxpoint-20";
			$script .= "\nvar bottomedge=ie&&!window.opera? ietruebody().clientHeight-event.clientY-offsetypoint : window.innerHeight-e.clientY-offsetypoint-20";
			$script .= "\n";
			$script .= "\nvar leftedge=(offsetxpoint<0)? offsetxpoint*(-1) : -1000";
			$script .= "\n";
			$script .= "\n//if the horizontal distance isn't enough to accomodate the width of the context menu";
			$script .= "\nif (rightedge<tipobj.offsetWidth)";
			$script .= "\n//move the horizontal position of the menu to the left by it's width";
			$script .= "\ntipobj.style.left=ie? ietruebody().scrollLeft+event.clientX-tipobj.offsetWidth+\"px\" : window.pageXOffset+e.clientX-tipobj.offsetWidth+\"px\"";
			$script .= "\nelse if (curX<leftedge)";
			$script .= "\ntipobj.style.left=\"5px\"";
			$script .= "\nelse";
			$script .= "\n//position the horizontal position of the menu where the mouse is positioned";
			$script .= "\ntipobj.style.left=curX+offsetxpoint+\"px\"";
			$script .= "\n";
			$script .= "\n//same concept with the vertical position";
			$script .= "\nif (bottomedge<tipobj.offsetHeight)";
			$script .= "\ntipobj.style.top=ie? ietruebody().scrollTop+event.clientY-tipobj.offsetHeight-offsetypoint+\"px\" : window.pageYOffset+e.clientY-tipobj.offsetHeight-offsetypoint+\"px\"";
			$script .= "\nelse";
			$script .= "\ntipobj.style.top=curY+offsetypoint+\"px\"";
			$script .= "\ntipobj.style.visibility=\"visible\"";
			$script .= "\n}";
			$script .= "\n}";
			$script .= "\n";
			$script .= "\nfunction hideddrivetip(){";
			$script .= "\nif (ns6||ie){";
			$script .= "\nenabletip=false";
			$script .= "\ntipobj.style.visibility=\"hidden\"";
			$script .= "\ntipobj.style.left=\"-1000px\"";
			$script .= "\ntipobj.style.backgroundColor=''";
			$script .= "\ntipobj.style.width=''";
			$script .= "\n}";
			$script .= "\n}";
			$script .= "\n";
			$script .= "\ndocument.onmousemove=positiontip";
			$script .= "\n";
			$script .= "\n</script>";
			rawoutput($script);
		break;
		case "village":
			$place = get_module_setting('place');
			$hook = get_module_setting('hook');
			if (get_module_setting('hook')==0||get_module_setting('place')==$session['user']['location']&&get_module_setting('hook')==1) {
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				addnav("Magical Potion Shoppe","runmodule.php?module=potionshop");
				output("`n`#A `!Magical Potion Shoppe`# sits in the village.");
			}
		break;
		case "moderate":
			$args['potionshop'] = 'Magical Potion Shoppe';
		break;
	}
	return $args;
}

function potionshop_run(){
	global $session;
	page_header("Magical Potion Shoppe");
	output("`@Entering this weird shoppe, you walk around it, staring at all the odd items..`n`3\"`&What do ye wish to buy? I am %s, master of `%Potions`&... look at ye list.`3\"","`#CortalUX`&");
	modulehook("potionshop-talk");
	modulehook("potionshop-navs");
	rawoutput("<br/><br/><hr width='80%'/><br/><table align='center' border='0' width='90%' style='text-align:center;'><tr class='trhead' style='text-decoration:bold;'><td>".translate_inline("Name")."</td><td>".translate_inline("Effects")."</td><td>".translate_inline("Cost")."</td><td>".translate_inline("Availability")."</td><td>".translate_inline("Link")."</td></tr>");
	$n=0;
	$list=array();
	$list = modulehook("potionshop-list",$list);
	foreach ($list as $val) {
		if (isset($val['gold'])&&!empty($val['gold'])&&is_numeric($val['gold'])) {
			$x = array('name','effects','avail','link');
			foreach ($x as $b) if (!isset($val[$b])||empty($val[$b])) $val[$b]=translate_inline("Unknown");
			$n++;
			rawoutput("<tr class='".($n%2?"trlight":"trdark")."'><td>".appoencode("`^".$val['name']."`0"));
			rawoutput("</td><td>".appoencode("`@".$val['effects']."`0"));
			rawoutput("</td><td class='colLtWhite'>".$val['gold']);
			rawoutput("</td><td>".appoencode("`Q".$val['avail']."`0"));
			rawoutput("</td><td>");
			if ($session['user']['gold']>=$val['gold']&&$val['link']!='') {
				$c = translate_inline("This costs %s Gold.");
				$c = str_replace('%s',$val['gold'],$c);
				rawoutput("<a class='colLtMagenta' onMouseover=\"ddrivetip('$c', 'ccffff')\"; onMouseout=\"hideddrivetip()\" href='".$val['link']."'>".translate_inline("Buy")."</a>");
				addnav("",$val['link']);
				if (isset($val['nav'])&&!empty($val['nav'])) {
					addnav("Buy Potions");
					addnav($val['nav'],$val['link']);
				}
			} elseif ($val['link']='') {
				output("`@This potion isn't in stock`0");
			} else {
				output("`@Too expensive...`0");
			}
			rawoutput("</td></tr>");
		}
	}
	if ($n==0) {
		rawoutput("<tr class='trhilite'><td colspan='5' style='text-align:center;' class='colLtYellow'>".translate_inline("There aren't any potions...")."</td></tr>");
	}
	rawoutput("</table><br/><hr width='80%'/>");
	addcommentary();
	output("`n`b`^As you walk around the room staring at the potions, you hear a kind of indistinct muttering..`b`n");
	viewcommentary("potionshop","`#Mutter?`@",25,"mutters");
	rawoutput('<br/>');
	page_footer();
}
?>