<?php
// Dead Cat 098
// 1.2 adds additional outcome
// 1.1 adds additional outcome

function deadcat_getmoduleinfo(){
	$info = array(
	"name"=>"Dead Cat",
	"version"=>"1.2",
	"author"=>"`2Robert",
	"category"=>"Graveyard Specials",
	"download"=>"http://dragonprime.net/users/robert/deadcat098.zip",
	);
	return $info;
}

function deadcat_install(){
	module_addeventhook("graveyard", "return 100;");
	return true;
}

function deadcat_uninstall(){
	return true;
}

function deadcat_dohook($hookname,$args){
	return $args;
}

function deadcat_runevent($type){
	global $session;
	output("`n`n`7 As you wander the graveyard, you see something running toward you. `n");
	output("You quickly step off to the side and toss a tombstone upon it. `n");
	switch(e_rand(1,5)){
	case 1: case 2:
	output("`7 Upon lifting the tombstone, you find out it was only a cat! `n`n");
	output("`& You know that `\$ Ramius `& is `i very pleased `i with you! ");
	$session['user']['gravefights']+=1;
	$session['user']['deathpower']+=e_rand(3,8);
	break;
	case 3:
	output("`7 Upon lifting the tombstone, you find nothing. `n`n Maybe you were seeing things?");
	break;
	case 4: case 5:
	output("`7 Upon lifting the tombstone, you find it was only a `b big hairy bug `b, silly you!");
	break;
}
}

function deadcat_run(){
}
?>