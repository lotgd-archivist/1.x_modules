<?php
// Gem Vault v1.2
// Aes (aes@ioerror.org)
// http://logd.ioerror.org
// 
// This module will allow your players to store gems in the bank
// to ensure safe keeping when they are killed in combat.  Gems
// are carried over after killing the dragon.  Future releases will
// allow you to define whether or not they should carry over.
//
//
// Install Instructions
//
// Copy this file into your modules directory.
// Login to the Superuser Grotto and Install / Activate it.
//
// Enjoy!

//add alt currency support

function bankgems_getmoduleinfo(){
	$info = array(
		"name"=>"Gem Vault",
		"version"=>"1.41",
		"author"=>"Aes<br>`3Bugfixes by: Lonny Luberts<br>`^Rewritten by: `QChris Vorndran",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Sichae/bankgems.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"This module allows the storage of Gems in the Bank.",
		"settings"=>array(
			"Gem Vault Settings,title",
				"gemaccountcost"=>"How much gold does it cost to open a gem account?,int|1000",
				"gemtransfercost"=>"How much gold does it cost to transfer a gem?,int|100",
				"maxgemsinbank"=>"What is the max gems they can have in the Vault?,int|500",
				"dktake"=>"Empty account at Dragonkill,bool|1",
		),
		"prefs"=>array(
			"Gem Vault User Preferences,title",
				"gemsinbank"=>"Amount of Gems in Bank,int|0",
				"hacc"=>"Has user created an account,bool|0",
		)
	);
	return $info;
}
function bankgems_install(){
	module_addhook("footer-bank");
	module_addhook("dragonkilltext");
	return true;
}
function bankgems_uninstall(){
	return true;
}
function bankgems_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "footer-bank":
			addnav("Gems");
			addnav("Gem Vault","runmodule.php?module=bankgems&op=enter");
			break;
		case "dragonkilltext":
			if (get_module_setting("dktake") == 1) set_module_pref("gemsinbank",0);
			set_module_pref("hacc",0);
			break;
		}
		return $args;
}
function bankgems_run(){
	global $session;
	$op = httpget("op");
	$amount = httppost('amount');
	page_header("Gem Vault");
	$gac = get_module_setting("gemaccountcost");
	$gtc = get_module_setting("gemtransfercost");
	$mgb = get_module_setting("maxgemsinbank");
	$gib = get_module_pref("gemsinbank");
	if ($gib > 0 && get_module_pref("hacc") == 0) set_module_pref("hacc",1);
	switch ($op){
		case "enter":
			output("`^`c`bWelcome to the Gem Vault.`b`c`n");
			output("`6Elessa leads you to the back of the bank and down into a dark tunnel lit only by the slivers of light from the bank floor above.");
			output("`6As she leads you through the dark damp infested labryinth with the light fading away, you think to yourself what an awful place this would be to get lost.");
			output("`6You finally reach your destination, a rather large chamber flickering with torch flames.");
			output("As you scan the room, you notice a very large ogre guarding what appears to be an entry way.`n`n");
			output("`6Elessa silently nods to the huge beast who then proceeds to push a boulder twice your size out of the way.`n");
			output("\"`@Please step inside.`6\" Elessa says smiling.`n`n");
				if (get_module_pref("hacc") == 1){
					output("`6Elessa pulls some books down from a shelf and begins to flip through them.");
					output("\"`@Aah, yes, here we are.  You have `5%s `@%s in our precious gem vault.",$gib,translate_inline($gib==1?"gem":"gems"));
					output("Is there anything else I can do for you?`6\"");
				}else{
					output("`cI'm afraid you do not have a gem vault account yet.`c`0");
				}		
			if (get_module_pref("hacc") == 0 && $session['user']['gems'] > 0) addnav(array("Open new account`0 (`^%s gold`0)",$gac),"runmodule.php?module=bankgems&op=nacc");
			if (get_module_pref("hacc") == 1){
				addnav("Transactions");
				if ($gib > 0) addnav("Withdraw Gems","runmodule.php?module=bankgems&op=wgems");
				if ($gib < $mgb && $session['user']['gems'] > 0) addnav("Deposit Gems","runmodule.php?module=bankgems&op=dgems");
			}
		break;
	case "nacc":
		if ($session['user']['gold'] < $gac){
			output("I'm sorry %s, but you do not appear to have enough money on you to open a new account.",translate_inline($session['user']['sex']?"madam":"sir"));
		}else{
			set_module_pref("gemsinbank",1);
			set_module_pref("hacc",1);
			$session['user']['gold']-=$gac;
			output("You have successfully opened a new account at our prestigious bank vault.  We have given you `^1`0 complementary gem.");	
			}
		break;
	case "dgems":
		if ($amount == ""){
			output("<form action='runmodule.php?module=bankgems&op=dgems' method='POST'>",true);
			output("`6Elessa says, \"`@You have a balance of `5%s `@%s in the bank.`6\"`n",$gib,translate_inline($gib==1?"gem":"gems"));
			output("`6Carefully reaching for your gem pouch you notice you have `5%s`6 gems on hand.`n`n", $session['user']['gems']);
			output("`^Deposit how much?");
			output("<input id='input' name='amount' width=5> <input type='submit' class='button' value='".translate_inline("Deposit")."'>",true);
			output("`n`iEnter 0 or nothing to deposit it all`i");
			output("</form>",true);
		}else{
			$amount = abs((int)$amount);
			if ($amount < 0) $amount = 0;
			if ($amount == 0)	$amount = $session['user']['gems'];
			if (($amount + $gib) > $mgb) $amount = ($mgb - $gib);
			if ($amount > $session['user']['gems']){
				output("Not enough gems on hand to deposit.");
			}else{
				debuglog("deposited $amount gems in the bank");
				$tamount = $gib + $amount;
				set_module_pref("gemsinbank",$tamount);
				$session['user']['gems']-=$amount;
			}
			output("`6Elessa records your deposit of gems in her ledger. \"`@You now have a balance of `^%s`@ gems in the bank.`6\"`n",$tamount);
		}
		addnav("","runmodule.php?module=bankgems&op=dgems");
		break;
	case "wgems":
		if ($amount == ""){
			output("<form action='runmodule.php?module=bankgems&op=wgems' method='POST'>",true);
			output("`6Elessa says, \"`@You have a balance of `^%s `@ %s in the bank.`6\"`n",$gib,translate_inline($gib==1?"gem":"gems"));
			output("`^How many would you like to withdraw?`n`n");
			output("<input id='input' name='amount' width=5> <input type='submit' class='button' value='".translate_inline("Withdraw")."'>",true);
			output("`n`iEnter 0 or nothing to withdraw it all`i");
			output("</form>",true);
		}else{
			$amount = abs((int)$amount);
			if ($amount < 0) $amount = 0;
			if ($amount==0) $amount = get_module_pref("gemsinbank");
			if ($amount > $gib){
				output("You don't have that many gems in the bank.");
			}else{
				debuglog("withdrew $amount gems from the bank");
				$tamount = $gib - $amount;
				set_module_pref("gemsinbank",$tamount);
				$session['user']['gems']+=$amount;
			}
			output("`6Elessa records your deposit of gems in her ledger. \"`@You now have a balance of `^%s `@%s in the bank.`6\"`n",$tamount,translate_inline($tamount==1?"gem":"gems"));
		}
		addnav("","runmodule.php?module=bankgems&op=wgems");
		break;
	}
addnav("Return");
if ($op == "enter") addnav("Return to Bank","bank.php");
if ($op != "enter") addnav("Return to Gem Vault","runmodule.php?module=bankgems&op=enter");
require_once("lib/villagenav.php");
villagenav();
page_footer(); 
}
?>