<?php

function kick_getmoduleinfo(){
	$info = array(
		"name"=>"Kick Player",
		"author"=>"Chris Vorndran",
		"category"=>"Administrative",
		"version"=>"1.0",
		"download"=>"http://dragonprime.net/users/Sichae/kick.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Adds a nav to a player's bio, so that they may be logged off from the game, and optionally have their account locked.",
		"settings"=>array(
			"lock"=>"Does kicking a player lock their account?,bool|0",
			"This should only be used in `bextreme`b cases.,note",
		),
	);
	return $info;
}
function kick_install(){
	if ($session['user']['superuser'] & SU_MANAGE_MODULES)
		output("`c`b`^This Module should only be used in EXTREME cases of disobedience.`b`c`0");
	module_addhook("biostat");
	return true;
}
function kick_uninstall(){
	return true;
}
function kick_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "biostat":
			global $target;
			if ($session['user']['superuser'] & SU_EDIT_USERS){
				addnav("Superuser");
				addnav("Kick Player","runmodule.php?module=kick&op=su&id=".$target['acctid']);
			}
			break;
		}
	return $args;
}
function kick_run(){
	global $session;
	$op = httpget('op');
	$i = httpget('i');
	$id = httpget('id');
	page_header("Kicking Player");
	switch ($op){
		case "su":
			if (!$i){
				output("`^Kicking a player is a simple way of automatically logging a player off that is being disruptive.");
				if (get_module_setting("lock")) output("This will also lock the players account, and should only be used in `bEXTREME`b cases.");
				output("`n`nDoes this player need this punishment?");
				addnav("Options");
				addnav("Kick","runmodule.php?module=kick&op=su&i=1&id=".$id);
			}else{
				$extra = "";
				if (get_module_setting("lock")) $extra = "AND locked=1";
				output("Player has been logged off%s",translate_inline(get_module_setting("lock")==1?" and locked.":"."));
				$sql = "UPDATE ".db_prefix("accounts")." SET loggedin=0 $extra WHERE acctid=$id";
				db_query($sql);
			}
			break;
		}
	villagenav();
page_footer();
}
?>