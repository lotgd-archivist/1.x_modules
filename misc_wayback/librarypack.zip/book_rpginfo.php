<?php

function book_rpginfo_getmoduleinfo(){
	$info = array(
		"name"=>"The Art of Roleplay (Book)",
		"author"=>"Script by WebPixie. Author: Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Library",
		"download"=>"http://dragonprime.net/users/Sichae/librarypack.zip",
	);
	return $info;
}

function book_rpginfo_install(){
	if (!is_module_installed("library")) {
         output("This module requires the Library module to be installed.");
         return false;
      }
	module_addhook("library");
	return true;
}

function book_rpginfo_uninstall(){
	return true;
}

function book_rpginfo_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "library":
			addnav("Book Shelf");
			addnav("The Art of Roleplay", "runmodule.php?module=book_rpginfo");
			break;
		}
	return $args;
}

function book_rpginfo_run(){
	global $session;
	$op = httpget('op');
	page_header("Town Library");
	output("`6`c`bThe Art of Roleplay`b`c`n");
	output("`6`cWritten by Sichae Saracen and Blackmyst Penarreal`c`n`n");

	switch ($op){
		case "start":
		output("`6`bStarting Off`b`n");
		output("`7Well, there are several keys to a good Roleplay. A relationship between oneself and his/her character is a must. The better you can be your character, the more likely you are to become better at RP. Now, every good character has a background that sets up the mood for the character. Such as, \"Blank's village was destroyed when he was a child.\" This shall evoke a kind of, anger and resentment in this character. Fun, huh?");
		break;
	case "1":
		output("`6`bAquiring an Alignment`b`n");
		output("`7This is choosing whether your character is good, evil or neutral. This may make things more complicated, yet all the more fun. A good character is bound to be nice and affectionate. While an evil character, wishes not to be around others. Keep these things in mind when developing a character of your own. ");
		break;
	case "2":
		output("`6`bDeveloping a Back Story`b`n");
		output("`7Now, it gets a tad more fun. We shall take a look, more in-depth, in developing a characters past. Most role-player's tend to choose a dark and dank past, as to it adds more options in a character. But, that is not always true. Take Sichae for example, she is kind and a wonderful person, yet, she came from a rough childhood. It all depends on the character's background, as to who they are today.");
		break;
	case "3":
		output("`6`bGenerating a Personality`b`n");
		output("`7A character's personality, ties everything together. Most basic character's, their puppet-masters share the same personality. Whether they be too lazy, or that is just all the more comfortable for them. Personality shall tie in with the character's alignment. Say for example, Johny is Evil. Well, Johny is most likely going to be sinister and condescending. He isn't going to be nice, he is going to be angry. Making sense?");
		break;
	case "4":
		output("`6`bCustomizing a Character`b`n");
		output("`7Now, to make your character your own, you must come up with a certain image for a character. Whether you decide to draw one out, or to come up with the specifics and leave it to imagination, it is all up to you. This customizing shall tie into your personality. Say for example, Exodus is an Elf. Well, elves be nature, tend to be kind and calm. So, you really aren't going to see a lot of Elvish Warlords, but they do come along. It depends on the alignment of your character.");
		break;
	case "5":
		output("`6`bWeaving of Words`b`n");
		output("`7Your character has been constructed, it sits in the corner. What now? Well, you must now begin to search for other RPers out there. You can find them lurking in message boards, RP Forums, MUDs and RPGs. Once you find a willing partner, begin to evoke a scene. Let your words be imagination's playground. But, to be spellbinding and captivating, you musn't use plain everyday words. Look to http://thesaurus.reference.com for a thesaurus, or keep one handy at your desk.");
		break;
	case "6":
		output("`6`bExamples of Word Weaving`b`n");
		output("`7Blackmyst interjects, \"But Sichae, you must have an example...\". Yes, you are quite right Blackmyst. For example, 'The jaded woman glanced at his face, her blank look giving away nothing.' I would rather see something like this...'The jaded female glanced for a diminutive second at the stunning gent's visage. The anger and bitterness that burned within her was not evident in the cold expressionless gaze she offered him' Doesn't that sound better?");

		output("`n`n`7Blackmyst sets into a derelict chair, adjacent to the fireplace, \"Sichae, teach them about replacing words.\" Again, good show Blackmyst. Okay, repeating words, such as fire every sentence, becomes rather redundant. Redundancy is a terrible way to RP. Now, pick up your thesaurus, and look for fire. You see, \"smoldering blaze, inferno.\" Try to use there, replacing fire. Now, let's try again. You overuse the word, \"hungry.\" What do you do? Thesaurus. You see as a synonym, \"wanton.\" Now, replace your overuse and you should be fine.");

		output("`n`n`7Blackmyst raises her hand. Sichae's eyes dash towards the newly risen hand. \"Sichae, what about the overuse of words? My, my, my, you are right. Okay, there are limits to the mind. Overusing the words, \"and, a, the, was\" can really wear on the eyes. Try using other words, instead of \"and\" you can use \"as well, also\", but it will take some contouring of words and sentence structure. A Word Usage Guide would be nice, and you can find one here http://www.uah.edu/colleges/liberal/english/shared/word_usage_guide.htm. But, in the end, your partner will find much more pleasure in the RP.");

		output("`n`n`7Blackmyst walks over and hands Sichae a note from the audience. The note reads, \"Okay man you gotta go over here and over there but you musn't do this and this but it is okay to do that, as long as you have a license oh yeah and be careful of the Dragon.\" Sichae begins to vomit. This is a terrible example of good RPing. Punctuation is your friend. Run-ons and incomplete thoughts can ruin any good RP.");
		break;

		}
	    addnav("Return Book to Shelf","runmodule.php?module=library&op=shelves");
	    addnav("Chapters");
	    addnav("Starting Off","runmodule.php?module=book_rpginfo&op=start");
	    addnav("Aquiring an Alignment","runmodule.php?module=book_rpginfo&op=1");
	    addnav("Developing a Back Story","runmodule.php?module=book_rpginfo&op=2");
	    addnav("Generating a Personality","runmodule.php?module=book_rpginfo&op=3");	    
	    addnav("Customizing a Character","runmodule.php?module=book_rpginfo&op=4");
	    addnav("Weaving of Words","runmodule.php?module=book_rpginfo&op=5");
	    addnav("Examples of Word Weaving","runmodule.php?module=book_rpginfo&op=6");
	page_footer();
}
?>