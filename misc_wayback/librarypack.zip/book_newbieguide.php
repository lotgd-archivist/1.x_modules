<?php

function book_newbieguide_getmoduleinfo(){
	$info = array(
		"name"=>"Farmies' Guide To The Lands (Book)",
		"author"=>"Script by WebPixie. Author Sichae",
		"version"=>"1.0",
		"category"=>"Library",
		"download"=>"http://dragonprime.net/users/Sichae/librarypack.zip",
	);
	return $info;
}

function book_newbieguide_install(){
	if (!is_module_installed("library")) {
         output("This module requires the Library module to be installed.");
         return false;
      }
	module_addhook("library");
	return true;
}

function book_newbieguide_uninstall(){
	return true;
}

function book_newbieguide_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "library":
				addnav("Book Shelf");
				addnav("Farmies' Guide To The Lands", "runmodule.php?module=book_newbieguide&op=read");
			break;
		}
	return $args;
}

function book_newbieguide_run(){
	global $session;
	$op = httpget('op');
	page_header("Town Library");

	output("`6`c`bFarmies' Guide To The Lands`b`c`n");
	output("`6`cWritten by Sichae Saracen`c`n`n");

	if ($op=="read"){
		output("`6`bTips Towards General Life in the Lands`b`n`n");
		output("`5`bNumber 1.`b `7Well first off, blowing all of your money, is HIGHLY recommended. Dump all of your extra cash into the bank, and wait for the next best weapon or armor. The game gets a tad less difficult, when you are able to max out your weapons. `n`n");
		output("`5`bNumber 2.`b `7If you see an open PvP, that you KNOW you can win, take it!. Seize the chance, before someone else does. Every little bit of EXP, can push you that much closer towards your next level. As well, it provides a buffer in case you are attacked in PvP. When you log back in, you won't lose as much, as if you were to just log off. `n`n");

		output("`5`bNumber 3.`b `7Heal! Often! No use in dying. Whenever you fall below half, unless you have some regeneration points, blow some cash on healing. Although, before level 8, healing can be stretched out. `n`n");

		output("`5`bNumber 4.`b `7If you are capable of resurrection, take it! The sooner you can come back, you can use your turns to gain back a small bit of EXP. It is better than sitting in the Shades, with a deficit of EXP. The EXP loss of being attacked and the EXP loss of getting killed in the forest, vary greatly.`n`n");

		output("`5`bNumber 5.`b `7The Inn, Resurrecting and Healing, all become a waste after around level 8. By that time, a small resurrection is insignificant, and it would be better off, if you just stayed dead. The Inn cost is based off of your level, and eventually...it gets really high in price. Dying in the fields and dying in the Inn share the same EXP loss. Do not worry about it, just follow these tips.`n`n");

		output("`5`bNumber 6.`b `7One final pointer, invest in mounts! The mounts are a grand way to get through the game. They may help you out in the area of stats, or it might just be a little help in defeating your foe. Each one is different, and each one is special. Treat it with respect and it shall pay you back greatly.`n`n");
		addnav("Return Book to Shelf","runmodule.php?module=library&op=shelves");

	}
	page_footer();
}
?>