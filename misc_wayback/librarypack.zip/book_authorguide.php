<?php

function book_authorguide_getmoduleinfo(){
	$info = array(
		"name"=>"Author's Alcove (Book)",
		"author"=>"Script by WebPixie",
		"version"=>"1.0",
		"category"=>"Library",
		"download"=>"http://dragonprime.net/users/Sichae/librarypack.zip",
	);
	return $info;
}

function book_authorguide_install(){
	if (!is_module_installed("library")) {
         output("This module requires the Library module to be installed.");
         return false;
      }
	module_addhook("library");
	return true;
}

function book_authorguide_uninstall(){
	return true;
}

function book_authorguide_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "library":
			addnav("Book Shelf");
			addnav("Author's Alcove", "runmodule.php?module=book_authorguide");
			break;
		}
	return $args;
}

function book_authorguide_run(){
	global $session;
	$op = httpget('op');
	page_header("Town Library");

	if ($op == "") {
		output("`6`c`bAuthor's Alcove`b`c`n");
		output("`7As you enter the dark alcove you notice a large notice posted on the wall. It reads:`n`n");
		rawoutput("<hr size=1 width=100% color=000000>");

		output("`6`c`bInformation on publishing your works in this library.`b`c`n`n");
		output("`7Are you a writer or poet looking to publish your works? You've come to the right spot. Our town library is looking for new books to be including in our growing collection.`n`n If you would like to have your stories or poems displayed in this library please submit your work.`n`n Just fill out a \"Petition For Help\" and you could become famous throughout the lands.`n`nHope to hear from you soon.`n`nSigned`nLord Gelting, Librarian");
		rawoutput("<hr size=1 width=100% color=000000>");
		}
	    addnav("Return to Shelves","runmodule.php?module=library&op=shelves");
	page_footer();
}
?>