<?php

function book_staffinfo_getmoduleinfo(){
	$info = array(
		"name"=>"Staff Primer (Book)",
		"author"=>"Chris Vorndran<br>`iWebpixie Template`i",
		"version"=>"1.0",
		"category"=>"Library",
		"download"=>"http://dragonprime.net/users/Sichae/librarypack.zip",
		"settings"=>array(
			"begin"=>"What is the beginning of the Primer say,textarea",
			"rule1"=>"What is rule one,textarea",
			"rule2"=>"What is rule two,textarea",
			"rule3"=>"What is rule three,textarea",
			"rule4"=>"What is rule four,textarea",
			"rule5"=>"What is rule five,textarea",
			"rule6"=>"What is rule six,textarea",
			"rule7"=>"What is rule seven,textarea",
			"rule8"=>"What is rule eight,textarea",
			"rule9"=>"What is rule nine,textarea",
			"rule10"=>"What is rule ten,textarea",
			"rule11"=>"What is rule eleven,textarea",
		),
	);
	return $info;
}

function book_staffinfo_install(){
	if (!is_module_installed("library")) {
         output("This module requires the Library module to be installed.");
         return false;
      }
	module_addhook("library");
	return true;
}

function book_staffinfo_uninstall(){
	return true;
}

function book_staffinfo_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "library":
			if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
				addnav("Book Shelf");
				addnav("Staff Primer", "runmodule.php?module=book_staffinfo");
			}
			break;
	}
	return $args;
}
function book_staffinfo_run(){
	global $session;
	$op = httpget('op');
	page_header("Town Library");
	output("`6`c`bStaff Primer`b`c`n");
	output("`6`cWritten by Head Administrator`c`n`n");

	if ($op == "") {
	output("`6`bBeginning`b`n");
	$begin=get_module_setting("begin");
		output("%s",$begin);
		}
	if ($op == "1") {
	output("`6`bRule One`b`n");
	$rule1=get_module_setting("rule1");
		output("`^Rule One States: `2%s",$rule1);
		}
	if ($op == "2") {
	output("`6`bRule Two`b`n");
	$rule2=get_module_setting("rule2");
		output("`^Rule Two States: `2%s",$rule2);
		}
	if ($op == "3") {
	output("`6`bRule Three`b`n");
	$rule3=get_module_setting("rule3");
		output("`^Rule Three States: `2%s",$rule3);
		}
	if ($op == "4") {
	output("`6`bRule Four`b`n");
	$rule4=get_module_setting("rule4");
		output("`^Rule Four States: `2%s",$rule4);
		}
	if ($op == "5") {
	output("`6`bRule Five`b`n");
	$rule5=get_module_setting("rule5");
		output("`^Rule Five States: `2%s",$rule5);
		}
	if ($op == "6") {
	output("`6`bRule Six`b`n");
	$rule6=get_module_setting("rule6");
		output("`^Rule Six States: `2%s",$rule6);
	}
	if ($op == "7") {
	output("`6`bRule Seven`b`n");
	$rule7=get_module_setting("rule7");
		output("`^Rule Seven States: `2%s",$rule7);
	}
	if ($op == "8") {
	output("`6`bRule Eight`b`n");
	$rule8=get_module_setting("rule8");
		output("`^Rule Eight States: `2%s",$rule8);
	}
	if ($op == "9") {
	output("`6`bRule Nine`b`n");
	$rule9=get_module_setting("rule9");
		output("`^Rule Nine States: `2%s",$rule9);
	}
	if ($op == "10") {
	output("`6`bRule Ten`b`n");
	$rule10=get_module_setting("rule10");
		output("`^Rule Ten States: `2%s",$rule10);
	}
	if ($op == "11") {
	output("`6`bRule Eleven`b`n");
	$rule11=get_module_setting("rule11");
		output("`^Rule Eleven States: `2%s",$rule11);
	}



	    addnav("Return Book to Shelf","runmodule.php?module=library&op=shelves");
	    addnav("Chapters");
	    addnav("Opening","runmodule.php?module=book_staffinfo");
		addnav("Rule One","runmodule.php?module=book_staffinfo&op=1");
	    addnav("Rule Two","runmodule.php?module=book_staffinfo&op=2");
	    addnav("Rule Three","runmodule.php?module=book_staffinfo&op=3");
	    addnav("Rule Four","runmodule.php?module=book_staffinfo&op=4");	    
	    addnav("Rule Five","runmodule.php?module=book_staffinfo&op=5");
	    addnav("Rule Six","runmodule.php?module=book_staffinfo&op=6");
	    addnav("Rule Seven","runmodule.php?module=book_staffinfo&op=7");
		addnav("Rule Eight","runmodule.php?module=book_staffinfo&op=8");
		addnav("Rule Nine","runmodule.php?module=book_staffinfo&op=9");
		addnav("Rule Ten","runmodule.php?module=book_staffinfo&op=10");
		addnav("Rule Eleven","runmodule.php?module=book_staffinfo&op=11");

	page_footer();
}

?>