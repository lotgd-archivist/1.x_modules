<?php
/*
Details:
 * This allows users to buy darts that they can throw at users for cool effects
History Log:
 * Version 1.0:
  o Seems Stable
 * Version 1.1:
  o Added a 'reconsider that target' nav
 * Version 1.2:
  o It now runs on any 'nonmodule' page
 * Version 1.3:
  o You can fire pretty much anywhere
 * Version 1.4:
  o You can buy a nullify/anti dart
 * Version 1.5:
  o You can buy an antidote for personal use if admins let you
  o Admins can limit the amount of darts that can be bought
 * Version 1.6 & 1.7:
  o Minor bugfixes
 * Version 1.8:
  o Now uses the correct version of addnews()
*/
require_once('lib/e_rand.php');

function dartpotion_getmoduleinfo(){
	$info = array(
		"name"=>"Dart Potions",
		"version"=>"1.8",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/dartpotion.zip",
		"settings"=>array(
			"Dart Potions - Settings,title",
			"datbuy"=>"Allow users to buy dart potions?,bool|1",
			"fName"=>"Name of the fey?,text|Xessa",
			"cLose"=>"Can users lose Charm?,bool|1",
			"antiBuy"=>"Can users buy antidotes for themselves?,bool|1",
			"Dart Potions - Darts,title",
			"dLimit"=>"`#Dart limit?,int|0",
			"`#(0 to disable),note",
			"pCost"=>"`#Cost of the dart potion vials?,int|200",
			"`#(users have to pay for the dart covering and the vial),note",
			"`%Mischief:,note",
			"pCost1"=>"`%Cost of the Drunk Dart?,int|500",
			"pCost2"=>"`%Cost of the SeeLike Dart?,int|600",
			"pCost3"=>"`%Cost of the Giant's Voice Dart?,int|700",
			"pCost4"=>"`%Cost of the Pixie Voice Dart?,int|800",
			"pCost5"=>"`%Cost of the Colour Dart?,int|900",
			"pCost6"=>"`%Cost of the Ugly Dart?,int|1000",
			"pCost7"=>"`%Cost of the Wind Dart?,int|1100",
			"`^Good:,note",
			"pCost8"=>"`^Cost of the Energy Dart?,int|500",
			"pCost9"=>"`^Cost of the Heal Dart?,int|600",
			"pCost10"=>"`^Cost of the Buff Dart?,int|700",
			"pCost11"=>"`^Cost of the Pretty Dart?,int|800",
			"pCost12"=>"`^Cost of the Protection Dart?,int|900",
			"pCost13"=>"`^Cost of the Aggression Dart?,int|1000",
			"pCost14"=>"`^Cost of the Ghost Dart?,int|1100",
			"pCost15"=>"`^Cost of the AntiDart?,int|500",
			"`Q(set the cost of a potion to 0 to make it free),note",
			"adminPotion"=>"`@Admin have unlimited access to darts?,bool|1",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"datPot"=>"Dart potions?,int|0",
			"datFire"=>"Darts fired?,int|0",
			"fireUpon"=>"Fired upon by?? Dart??,text|",
			"`%Mischief:,note",
			"pot1"=>"`%Is the Drunk Dart in effect?,bool|0",
			"pot2"=>"`%Is the SeeLike Dart in effect?,bool|0",
			"pot3"=>"`%Is the Giant's Voice Dart in effect?,bool|0",
			"pot4"=>"`%Is the Pixie Voice Dart in effect?,bool|0",
			"pot5"=>"`%Is the Colour Dart in effect?,bool|0",
			"pot6"=>"`%Is the Ugly Dart in effect?,bool|0",
			"pot7"=>"`%Is the Wind Dart in effect?,bool|0",
			"pot7F"=>"Farts?,hidden|3",
			"`#Good:,note",
			"pot8"=>"`#Is the Energy Dart in effect?,bool|0",
			"pot9"=>"`#Is the Heal Dart in effect?,bool|0",
			"pot10"=>"`#Is the Buff Dart in effect?,bool|0",
			"pot11"=>"`#Is the Pretty Dart in effect?,bool|0",
			"pot12"=>"`#Is the Protection Dart in effect?,bool|0",
			"pot13"=>"`#Is the Aggression Dart in effect?,enum,0,No,1,Yes,2,Done|0",
			"pot14"=>"`#Is the Ghost Dart in effect?,enum,0,No,1,Yes,2,Done|0",
			"`^Neutral:,note",
			"pot15"=>"`^Is the Anti Dart in effect?,bool|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
		),
	);
	return $info;
}

function dartpotion_install(){
	if (!is_module_active('dartpotion')) {
		output("`n`Q`b`cInstalling Dart Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Dart Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	module_addhook("pre-newday");
	module_addhook("newday");
	module_addhook("holiday");
	module_addhook_priority("commentary",1);
	module_addhook_priority("viewcommentary",1);
	module_addhook("everyheader");
	return true;
}

function dartpotion_uninstall(){
	output("`n`Q`b`cUninstalling Dart Potions Module.`c`b`n");
	return true;
}

function dartpotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME,$battle;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('datPot')>0) {
					output("`n`^You have `@%s`^ Dart Potions...`n",get_module_pref('datPot'));
				}
			}
		break;
		case "charstats":
			$potion="";
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) {
				set_module_pref('datPot',1);
			}
			if (get_module_pref('datPot')>0) {
				$i = false;
				if ($battle===false||!isset($battle)||empty($battle)) {
					if (httpget('module')==''&&$session['user']['specialinc']==''&&$session['user']['specialmisc']==''&&$session['user']['loggedin']==1&&isset($session['user']['loggedin'])) {
						$i=true;
					}
				}
				$c = translate_inline("Dart Potions cannot be used here");
				if ($i===false) {
					$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
					$potion .="<img src=\"./images/dartpotion/potionclear.gif\" title=\"$c\" alt=\"$c\">";
					$potion .="</div>";
				} else {
					$x = get_module_pref('datPot');
					$y = 0;
					$c = translate_inline("Make the Dart Potion...");
					while ($x>0) {
						$y++;
						$x--;
						$potion.="<a style='border:0;' border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=dartpotion&op=use\"><img src=\"./images/dartpotion/potion.gif\" style='border:0;' title=\"$c\" alt=\"$c\"></a>";
						addnav("","runmodule.php?module=dartpotion&op=use");
						if ($y>=3) {
							$y=0;
							$potion.="\n<br/>";
						}
					}
				}
			}
			addcharstat("Click and use Items");
			if ($potion!="") addcharstat("Dart Potions", $potion);
		break;
		case "potionshop-list":
			if (get_module_setting('datbuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$not=array();
				$not['gold']=$price;
				$not['name']=translate_inline("Dart Potions");
				$not['link']="runmodule.php?module=dartpotion&op=shop";
				$not['avail']=translate_inline("In Stock");
				$not['nav']=translate_inline("Buy a `QDart`0 Vial");
				$not['effects']=translate_inline("This Dart can be fired upon other users for a lot of weird and wonderful effects.");
				$args[]=$not;
				if (get_module_setting('antiBuy')==1) {
					$price = get_module_setting('pCost')+get_module_setting('pCost15');
					if ($price<=0) $price = 1;
					$not=array();
					$not['gold']=$price;
					$not['name']=translate_inline("Anti-Dart Vials");
					$not['link']="runmodule.php?module=dartpotion&op=anti";
					$not['avail']=translate_inline("In Stock");
					$not['nav']=translate_inline("Buy an `qAnti-Dart`0");
					$not['effects']=translate_inline("This anti-dart is for self-injection and will take effect immediately, as it's too unstable for you to keep... it'll nullify ALL effects, including good ones.");
					$args[]=$not;
				}
			}
		break;
		case "pre-newday":
			if (httpget('type')=='ghostdart') {
				set_module_pref('pot14',0);
				output("`c`b`QThe Ghost Dart resurrected you!!`b`c`n`n");
				require_once('lib/addnews.php');
				addnews("`^%s`@ was resurrected by a Ghost Dart!!!",$session['user']['name']);
				global $resurrection,$spirits;
				$args['resurrection']=false;
				$resurrection="false";
				httpset('resurrection',"false");
				$spirits=-6;
			}
		break;
		case "newday":
			set_module_pref('datFire',0);
			$pot2=get_module_pref('pot2'); // SeeLike Dart
			if ($pot2) {
				set_module_pref('pot2',0);
				output("`c`b`QThe SeeLike Dart wears off...`b`c`n`n");
			}

			$pot3=get_module_pref('pot3'); // Giant's Voice Dart
			if ($pot3) {
				set_module_pref('pot3',0);
				output("`c`b`QThe Giant's Voice Dart wears off...`b`c`n`n");
			}

			$pot4=get_module_pref('pot4'); // Pixie Voice Dart
			if ($pot4) {
				set_module_pref('pot4',0);
				output("`c`b`QThe Pixie Voice Dart wears off...`b`c`n`n");
			}

			$pot5=get_module_pref('pot5'); // Colour Voice Dart
			if ($pot5) {
				set_module_pref('pot5',0);
				output("`c`b`QThe Colour Dart wears off...`b`c`n`n");
			}

			$pot12=get_module_pref('pot12'); // Protection Dart
			if ($pot12==2) {
				$session['user']['defense']--;
				set_module_pref('pot12',0);
				output("`c`b`QThe Protection Dart wears off...`b`c`n`n");
			}

			$pot13=get_module_pref('pot13'); // Aggression Dart
			if ($pot13==2) {
				$session['user']['attack']--;
				set_module_pref('pot13',0);
				output("`c`b`QThe Aggression Dart wears off...`b`c`n`n");
			}
		break;
		case "holiday":
			$pot2=get_module_pref('pot2'); // SeeLike Dart
			if ($pot2) {
				$args['text'] = str_replace(". ",". Bork bork. ",$args['text']);
				$args['text'] = str_replace(", ",", bork, ",$args['text']);
				$args['text'] = str_replace(" h"," hoor",$args['text']);
				$args['text'] = str_replace(" v"," veer",$args['text']);
				$args['text'] = str_replace("g ","gen ",$args['text']);
				$args['text'] = str_replace(" p"," pere",$args['text']);
				$args['text'] = str_replace(" qu"," quee",$args['text']);
				$args['text'] = str_replace("n ","nen ",$args['text']);
				$args['text'] = str_replace("e ","eer ",$args['text']);
				$args['text'] = str_replace("s ","ses ",$args['text']);
			}
		break;
		case "commentary":
			$b=false;
			$pot3=get_module_pref('pot3'); // Giant's Voice Dart
			$pot4=get_module_pref('pot4'); // Pixie Voice Dart
			$pot5=get_module_pref('pot5'); // Colour Voice Dart
			$args['commentline']=str_replace('�','',$args['commentline']);
			if ($pot3) {
				$args['commenttalk'] .= translate_inline(" in a Giant's Voice")."�";
				$b=true;
			} elseif ($pot4) {
				$args['commenttalk'] .= translate_inline(" in a Pixie Voice")."�";
				$b=true;
			} elseif ($pot5) {
				$args['commenttalk'] .= translate_inline(" in a `@C`^o`#l`Qo`\$u`&r`%f`!u`ql`3 Voice");
				require_once('lib/sanitize.php');
				$v=color_sanitize($args['commentline']);
				$w=array(1=>"@",2=>"^",3=>"#",4=>"Q",5=>"\$",6=>"&",7=>"%",8=>"!");
				$x=strlen($v);
				$y=0;
				$z="";
				while ($y<$x) {
					$y++;
					$z.="`".$w[array_rand($w,1)].substr($v,($y-1),1);
				}
				$args['commentline']=$z;
				$b=true;
			}
			if ($b) {
				blockmodule('text_talk');
			}
		break;
		case "viewcommentary":
			$stuff=$args['commentline'];
			if (stristr($stuff,translate_inline(" in a Giant's Voice")."&laquo;")!==false) {
				$args['commentline']=str_replace("&laquo;","","<big>".$args['commentline']."</big>");
			} elseif (stristr($stuff,translate_inline(" in a Pixie Voice")."&laquo;")!==false) {
				$args['commentline']=str_replace("&laquo;","","<small>".$args['commentline']."</small>");
			}
		break;
		default:
			if ($battle===false||!isset($battle)||empty($battle)) {
				if (httpget('module')==''&&$session['user']['specialinc']==''&&$session['user']['specialmisc']==''&&$session['user']['loggedin']==1&&isset($session['user']['loggedin'])) {
					dartpotion_check();
				}
			}
		break;
	}
	return $args;
}

function dartpotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			page_header("Dart Potions!!!");
			$stage = httpget('stage');
			if ($stage=='') $stage=0;
			switch ($stage) {
				case "0":
					output("`@Opening the Dart Vial, you summon the Fay...");
					output("`n`3\"`&Who summoned me? My name is.. `^%s`&. I am bound with the power of strong magiks... I would do your bidding.. whoso art thee?`3\" says `^%s`3.`n`@You name yourself, and choose who to fire upon...",get_module_setting('fName'),get_module_setting('fName'));
				case "1":
					if (get_module_setting('dLimit')<=0||get_module_pref('datFire')>=get_module_setting('dLimit')) {
						dartpotion_form();
					} else {
						output("`n`3\"`&I have been told... %s does not think you need more dart fun... wait till tomorrow.`3\" says `^%s`3.","`#CortalUX`&",get_module_setting('fName'));
					}
				break;
				case "2":
					$ac=httpget('ac');
					$sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE acctid='$ac'";
					$result = db_query($sql);
					if (db_num_rows($result)==1){
						$row = db_fetch_assoc($result);
						output("`3\"`&I can find your target... now, I am bound to serve... choose an action... I will deliver the Gold to %s..`3\" `^%s`3 says...`n`n","`#CortalUX`&",get_module_setting('fName'));
						addnav("Mischief");
						addnav(array("`%%Drunk Dart `@(`^%s Gold`@)",get_module_setting('pCost1')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=1");
						addnav(array("`%%SeeLike Dart `@(`^%s Gold`@)",get_module_setting('pCost2')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=2");
						addnav(array("`%%Giant's Voice Dart `@(`^%s Gold`@)",get_module_setting('pCost3')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=3");
						addnav(array("`%%Pixie Voice Dart `@(`^%s Gold`@)",get_module_setting('pCost4')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=4");
						addnav(array("`%%Colour Dart `@(`^%s Gold`@)",get_module_setting('pCost5')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=5");
						addnav(array("`%%Ugly Dart `@(`^%s Gold`@)",get_module_setting('pCost6')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=6");
						addnav(array("`%%Wind Dart `@(`^%s Gold`@)",get_module_setting('pCost7')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=7");
						addnav("Good");
						addnav(array("`#Energy Dart `@(`^%s Gold`@)",get_module_setting('pCost8')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=8");
						addnav(array("`#Heal Dart `@(`^%s Gold`@)",get_module_setting('pCost9')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=9");
						addnav(array("`#Buff Dart `@(`^%s Gold`@)",get_module_setting('pCost10')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=10");
						addnav(array("`#Pretty Dart `@(`^%s Gold`@)",get_module_setting('pCost11')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=11");
						addnav(array("`#Protection Dart `@(`^%s Gold`@)",get_module_setting('pCost12')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=12");
						addnav(array("`#Aggression Dart `@(`^%s Gold`@)",get_module_setting('pCost13')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=13");
						addnav(array("`#Ghost Dart `@(`^%s Gold`@)",get_module_setting('pCost14')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=14");
						addnav("Neutral");
						addnav(array("`^Anti Dart `@(`^%s Gold`@)",get_module_setting('pCost15')),"runmodule.php?module=dartpotion&op=use&stage=3&ac=$ac&potion=15");
						addnav("Navigation");
						addnav("`@Reconsider the Target","runmodule.php?module=dartpotion&op=use&stage=1");
					} else {
						output("`3\"`&I cannot find that person... my magik binder is halted..`3\" %s`3 says...`n`n", get_module_setting('fName'));
						addnav("Navigation");
						addnav("`@Try Again","runmodule.php?module=dartpotion&op=use&stage=1");
					}
				break;
				case "3":
					$price = get_module_setting("pCost".httpget('potion'));
					$ac=httpget('ac');
					if ($session['user']['gold']>=$price||get_module_setting('adminPotion')==1&&$session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) {
						if ($session['user']['superuser']&SU_DOESNT_GIVE_GROTTO&&get_module_setting('adminPotion')==1||get_module_setting('adminPotion')==0) $session['user']['gold']-=$price;
						$sql = "SELECT name,login,alive,location,maxhitpoints,alive,loggedin,dragonkills,gold,gems,sex,level,weapon,armor,attack,defense FROM " . db_prefix("accounts") . " WHERE acctid='$ac'";
						$result = db_query($sql);
						if (db_num_rows($result)==1){
							$row = db_fetch_assoc($result);
							$n = $row['name'];
							unset($sql,$result,$row);
						} else {
							$n="Whatsisname";
						}
						switch (httpget('potion')) {
							// Mischief
							case "1": // Drunk Dart
								output("`^%s`@ nods as you complete your request, and a bottle of booze appears in your hand.`nOpening it up, you pour the contents of the bottle into the potion vial at the end of the dart, and fire the blowdart through a convenient reed, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `^Drunk Dart`@ upon `%%s`@!";
								$title="`^Drunk Dart!!!";
								$body="`@%s`^ was seen firing a `%Drunk Dart`^ upon you!";
								$dart = "Drunk Dart";
							break;
							case "2": // SeeLike Dart
								output("`^%s`@ dips its head, and a sparkling grey glob appears in the dart vial before you. Quickly closing it, you fire the blowdart through a convenient reed, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`&%s`^ has fired a `7SeeLike Dart`^ upon `%%s`^!";
								$title="`7SeeLike Dart!!!";
								$body="`@%s`^ was seen firing a `%SeeLike Dart`^ upon you!";
								$dart = "SeeLike Dart";
							break;
							case "3": // Giant's Voice Dart
								output("`^%s`@ grins as you complete your request, and a huge squishy giants tonsil appears on a platter before you... Yeuch!`nChopping it up, and squeezing the tonsil to extract the juice, you pour the tonsil fluid into the vial at the end of the blowdart, and fire the blowdart through a convenient reed, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `^Giant's Voice Dart`@ upon `%%s`@!";
								$title="`@Giant's Voice Dart!!!";
								$body="`@%s`^ was seen firing a `%Giant's Voice Dart`^ upon you!`nDo you `bknow`b how those things are made?";
								$dart = "Giant's Voice Dart";
							break;
							case "4": // Pixie Voice Dart
								output("`^%s`@ sighs as you state your request, and a pixie whistle appears in your hand..`nMelting it down, you extract a glowing substance from it, which you pour into a blowdart and fire at `%%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `^Pixie Voice Dart`@ upon `%%s`@!";
								$title="`^Pixie Dart!!!";
								$body="`@%s`^ was seen firing a `%Pixie Voice Dart`^ upon you!";
								$dart = "Pixie Dart";
							break;
							case "5": // Colour Dart
								output("`^%s`@ grimaces as you complete your request, and the innards of a Rainbow Fish appear in your hand, which you quickly squelch into a blowdart and fire at `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `^Colour Dart`@ upon `%%s`@!";
								$title="`^Colour Dart!!!";
								$body="`^%s`% was seen firing a `^Colour Dart`% upon you!";
								$dart = "Colour Dart";
							break;
							case "6": // Ugly Dart
								output("`^%s`@ giggles as you complete your request, and the vial at the end of the potion dart fills with an opaque, vile smelling `qmuddy`@ liquid... closing the dart quickly, you fire the blowdart through a convenient reed, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `qUgly Dart`@ upon `%%s`@!";
								$title="`qUgly Dart!!!";
								$body="`@%s`^ was seen firing an `qUgly Dart`^ upon you!";
								$dart = "Ugly Dart";
							break;
							case "7": //  Wind Dart
								output("`^%s`@ nods as you complete your request, and the dart closes itself, filling with a murky yellow fog.`nYou fire the blowdart through a convenient reed, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `3Wind Dart`@ upon `%%s`@!";
								$title="`3Wind Dart!!!";
								$body="`@%s`^ was seen firing a `3Wind Dart`^ upon you!";
								$dart = "Wind Dart";
							break;
							// Good
							case "8": //  Energy Dart
								output("`^%s`@ takes the potion dart from you, and fires a glowing yellow dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired an `3Energy Dart`@ upon `%%s`@!";
								$title="`^Energy Dart!!!";
								$body="`@%s`^ was seen firing an `3Energy Dart`^ upon you!";
								$dart = "Energy Dart";
							break;
							case "9": //  Heal Dart
								output("`^%s`@ takes the potion dart from you, and fires a glowing pink dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `3Heal Dart`@ upon `%%s`@!";
								$title="`%Heal Dart!!!";
								$body="`@%s`^ was seen firing a `3Heal Dart`^ upon you!";
								$dart = "Heal Dart";
							break;
							case "10": //  Buff Dart
								output("`^%s`@ takes the potion dart from you, and fires a vibrating blue dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `#Buff Dart`@ upon `%%s`@!";
								$title="`#Buff Dart!!!";
								$body="`@%s`^ was seen firing a `#Buff Dart`^ upon you!";
								$dart = "Buff Dart";
							break;
							case "11": //  Pretty Dart
								output("`^%s`@ takes the potion dart from you, and fires a smooth purple dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `%Pretty Dart`@ upon `%%s`@!";
								$title="`%Pretty Dart!!!";
								$body="`@%s`^ was seen firing a `%Pretty Dart`^ upon you!";
								$dart = "Pretty Dart";
							break;
							case "12": //  Protection Dart
								output("`^%s`@ takes the potion dart from you, and fires a glowing orange dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `QProtection Dart`@ upon `%%s`@!";
								$title="`QProtection Dart!!!";
								$body="`@%s`^ was seen firing a `QProtection Dart`^ upon you!";
								$dart = "Protection Dart";
							break;
							case "13": //  Aggression Dart
								output("`^%s`@ takes the potion dart from you, and fires a vibrating red dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired an `\$Aggression Dart`@ upon `%%s`@!";
								$title="`\$Aggression Dart!!!";
								$body="`@%s`^ was seen firing an `\$Aggression Dart`^ upon you!";
								$dart = "Aggression Dart";
							break;
							case "14": //  Ghost Dart
								output("`^%s`@ takes the potion dart from you, and fires an airy white dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired a `7Ghost Dart`@ upon `%%s`@!";
								$title="`7Ghost Dart!!!";
								$body="`@%s`^ was seen firing a `7Ghost Dart`^ upon you!";
								$dart = "Ghost Dart";
							break;
							case "15": //  Anti Dart
								output("`^%s`@ takes the potion dart from you, and fires a glowing black dart, hitting `^%s`@!",get_module_setting('fName'),$n);
								$news="`%%s`@ has fired an `7Anti Dart`@ upon `%%s`@!";
								$title="`7Ghost Dart!!!";
								$body="`@%s`^ was seen firing a `7Anti Dart`^ upon you, nullifying all effects!";
								$dart = "Anti Dart";
							break;
						}
						require_once('lib/addnews.php');
						addnews($news,$session['user']['name'],$n);
						require_once('lib/systemmail.php');
						$subject=translate_inline($subject);
						$body=array(translate_inline($body),$session['user']['name'],$n);
						systemmail($ac,$subject,$body);
						output("`n`n`@As it finishes speaking... `^%s`3 shrieks, `3\"`&Thank you! I am free! I will forever remember this boon!`3\" as it flies off, having pocketed the gold..`0`n`n",get_module_setting('fName'));
						set_module_pref('datPot',get_module_pref('datPot')-1);
						set_module_pref('pot'.httpget('potion'),1,'dartpotion',$ac);
						set_module_pref('fireUpon',$session['user']['acctid']."|".str_replace('|','',translate_inline($dart)),'dartpotion',$ac);
						set_module_pref('datFire',get_module_pref('datFire')+1);
					} else {
						output("`n`n`^%s`3 shrieks, `3\"`&You don't have enough gold!!!`3\"`0`n`n",get_module_setting('fName'));
						addnav("Navigation");
						addnav("`@Try Again","runmodule.php?module=dartpotion&op=use&stage=2&ac=".$ac);
					}
				break;
			}
			addnav("Navigation");
			villagenav();
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('datPot',get_module_pref('datPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing %s gold to %s, he hands you a dart potion, \"`&This is a dart potion vial.. I explained it te yeh already..`3\"",$price,"`#CortalUX`@");
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
		case "anti":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost')+get_module_setting('pCost15');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				$session['user']['gold']-=$price;
				set_module_pref('pot15',1);
				output("`@Handing %s gold to %s, he throws a dart into your side, \"`&I hope yeh're ready for it... bit late now.. ye should feel it take effect soon..`3\"",$price,"`#CortalUX`@");
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
	}
}

function dartpotion_form() {
	global $session;
	$n = httppost("n");
	rawoutput("<form action='runmodule.php?module=dartpotion&op=use&stage=1' method='POST'>");
	addnav("","runmodule.php?module=dartpotion&op=use&stage=1");
	if ($n!="") {
		$string="%";
		for ($x=0;$x<strlen($n);$x++){
			$string .= substr($n,$x,1)."%";
		}
		$sql = "SELECT login,name,acctid FROM ".db_prefix("accounts")." WHERE name LIKE '%$string%' AND acctid<>".$session['user']['acctid']." ORDER BY level,login";
		$result = db_query($sql);
		if (db_num_rows($result)!=0) {
			output("`@The dart potion vial will only disappear when you actually fire it..");
			output("`@These users were found `^(click on a name to decide what to do)`@:`n");
			rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
			rawoutput("<tr class='trhead'><td>Name</td></tr>");
			for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=dartpotion&op=use&stage=2&ac=".$row['acctid']."'>");
			output_notl($row['name']);
			rawoutput("</td></tr>");
			addnav("","runmodule.php?module=dartpotion&op=use&stage=2&ac=".$row['acctid']);
			}
			rawoutput("</table>");
		} else {
			output("`c`@`bA user was not found with that name.`b`c");
		}
		output_notl("`n");
	}
	output("`^`b`cDart Potions..`c`b");
	output("`nWho do you want to fire upon? (Don't worry about funny names.. you'll be asked to confirm it)");
	output("Name of user: ");
	rawoutput("<input name='n' id='n' maxlength='50' value=\"".htmlentities(stripslashes(httppost('n')))."\">");
	$apply = translate_inline("Visualize");
	rawoutput("<input type='submit' class='button' value='$apply'></form>");
	rawoutput("<script language='JavaScript'>document.getElementById('n').focus();</script>");
}

function dartpotion_check() {
	global $session;
	$fired = get_module_pref('fireUpon');
	if ($fired!='') {
		$fired=explode('|',$fired);
		$ac=$fired[0];
		$dart=$fired[1];
		$sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE acctid='$ac'";
		$result = db_query($sql);
		if (db_num_rows($result)==1){
			$row = db_fetch_assoc($result);
		 	$n=$row['name'];
	 	} else {
		 	$n=translate_inline("Whatsisname");
	 	}
	 	output("`4`c`bSpecial Event: \"`^You have been hit by a potion dart from the `!Magical Potion Shoppe`^! Pulling it out, you see it to be a `#%s`^. Looking around, you see %s`^ run for cover!\"`b`c`^`n`n",$dart,$n);
	 	set_module_pref('fireUpon','');
	}
	$pot1=get_module_pref('pot1'); // Drunk Dart
	if (is_module_active('drinks')&&$pot1) {
		set_module_pref('pot1',0);
		set_module_pref('drunkeness',100,'drinks');
		output("`c`b`QYou become DRUNK!!`b`c`n`n");
	}

	$pot6=get_module_pref('pot6'); // Ugly Dart
	if ($pot6) {
		set_module_pref('pot6',0);
		if ($session['user']['charm']>0&&get_module_setting('cLose')==1) {
			$session['user']['charm']--;
		} elseif ($session['user']['charm']<=0) {
			$session['user']['charm']=0;
		}
		output("`c`b`QYou lose CHARM!!`b`c`n`n");
	}

	$pot7=get_module_pref('pot7'); // Wind Dart
	if ($pot7) {
		$pot7F=get_module_pref('pot7F');
		$num=e_rand(1,20);
		if ($pot7F==3) $num=1;
		if ($pot7F>0&&$num==1) {
			$pot7F--;
		} elseif ($pot7F==0&&$num==1) {
			$pot7F=3;
			set_module_pref('pot7',0);
		}
		if ($num==1) {
			$loc=$session['user']['location'];
			$vloc = array();
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$vloc[$vname] = "village";
			$vloc = modulehook("validlocation", $vloc);
			if ($vloc[$loc]!='') {
				$sql = "INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$vloc[$loc]."',".$session['user']['acctid'].",\":".translate_inline("`@f`^a`@r`^t`@s `^v`@i`^o`@l`^e`@n`^t`@l`^y`@!`^!")."\")";
				db_query($sql);
				require_once('lib/addnews.php');
				addnews("`@%s `@f`^a`@r`^t`@s `^v`@i`^o`@l`^e`@n`^t`@l`^y`@! `&All around the world, people recoil in horror.",$session['user']['name']);
			}
			output("`c`b`QYou fart VIOLENTLY!!`b`c`n`n");
		}
		set_module_pref('pot7F',$pot7F);
	}

	$pot8=get_module_pref('pot8'); // Energy Dart
	if ($pot8) {
		set_module_pref('pot8',0);
		$session['user']['turns']++;
		output("`c`b`QYou gain a FOREST FIGHT!!`b`c`n`n");
	}

	$pot9=get_module_pref('pot9'); // Heal Dart
	if ($pot9) {
		if ($session['user']['hitpoints']<$session['user']['maxhitpoints']) {
			set_module_pref('pot9',0);
			$session['user']['hitpoints']=$session['user']['maxhitpoints'];
			output("`c`b`QYou get HEALED from the Heal Dart!!`b`c`n`n");
		}
	}

	$pot10=get_module_pref('pot10'); // Buff Dart
	if ($pot10) {
		set_module_pref('pot10',0);
		$num=e_rand(1,2);
		if ($num==1) {
			output("`c`b`QYou gain a Defense Buff!!`b`c`n`n");
			apply_buff('dartpotion-defense', array(
				"name"=>"`QBuff Dart (Defense)`0",
				"rounds"=>15,
				"defmod"=>1.05,
				"survivenewday"=>1,
				"roundmsg"=>"`QThe Buff Dart helps you...`0",
			));
		} else {
			output("`c`b`QYou gain an Attack Buff!!`b`c`n`n");
			apply_buff('dartpotion-attack', array(
				"name"=>"`QBuff Dart (Attack)`0",
				"rounds"=>15,
				"atkmod"=>1.05,
				"survivenewday"=>1,
				"roundmsg"=>"`QThe Buff Dart helps you...`0",
			));
		}
	}

	$pot11=get_module_pref('pot11'); // Pretty Dart
	if ($pot11) {
		if ($session['user']['charm']<=0) $session['user']['charm']=0;
		$session['user']['charm']++;
		set_module_pref('pot11',0);
		output("`c`b`QYou gain a CHARM POINT!!`b`c`n`n");
	}

	$pot12=get_module_pref('pot12'); // Protection Dart
	if ($pot12==1) {
		$session['user']['defense']++;
		set_module_pref('pot12',2);
		output("`c`b`QYou gain a temporary DEFENSE POINT!!`b`c`n`n");
	}

	$pot13=get_module_pref('pot13'); // Aggression Dart
	if ($pot13==1) {
		$session['user']['attack']++;
		set_module_pref('pot13',2);
		output("`c`b`QYou gain a temporary ATTACK POINT!!`b`c`n`n");
	}

	$pot14=get_module_pref('pot14'); // Ghost Dart
	if ($pot14==1&&$session['user']['alive']==0) {
		set_module_pref('pot14',2);
		redirect('newday.php?resurrection=true&type=ghostdart');
	}

	$pot15=get_module_pref('pot15'); // Anti Dart
	if ($pot15==1) {
		output("`c`b`QAll dart effects are nullified!!`b`c`n`n");
		$x=0;
		while ($x<15) {
			$x++;
			set_module_pref('pot'.$x,0);
		}
	}
}
?>