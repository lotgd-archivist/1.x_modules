<?

function lilypond_getmoduleinfo(){
	$info = array(
		"name"=>"Lily Pond",
		"author"=>"Shawn Strider<br>Converted by: `QChris Vorndran",
		"version"=>"1.0",
		"category"=>"Gardens",
		"download"=>"http://dragonprime.net/users/Sichae/lilypond.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"Lily Pond Settings,title",
			"charm"=>"How much charm is lost to the frogs,int|5",
			"turns"=>"Turns gained from Meditation,range,1,5,1|3",
			),
		"prefs"=>array(
			"Lily Pond Prefs,title",
			"visit"=>"Has user visited the Lily Pond today,bool|0",
			),
		"requires"=>array(
			"drinks"=>"1.1|By John J. Collins, from the core download",
			),
		);
	return $info;
}
function lilypond_install(){
	module_addhook("gardens");
	module_addhook("newday");
	return true;
}
function lilypond_uninstall(){
	return true;
}
function lilypond_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "gardens":
			addnav("Explore");
			addnav("The Lily Pond","runmodule.php?module=lilypond&op=enter");
			break;
		case "newday":
			set_module_pref("visit",0);
			break;
		}
	return $args;
}
function lilypond_run(){
	global $session;
	// strider's lily pads
	page_header("Lily Pond");
	output("`b`c`2The Lillies`0`c`b`n");
	$op = httpget('op');
	$d = get_module_pref("drunkeness","drinks");
	$drink = array(-1=>"lightly enchanted",
				 0=>"quite Enchanted",
				 1=>"calm",
				 2=>"pleasantly buzzed",
				 3=>"estranged",
				 4=>"dazed, drunk like ",
				 5=>"the world is spinning",
				 6=>"really bloody hammered",
				 7=>"like the world is spinning with LOTS of colors",
				 8=>"almost bloody unconscious",
				 );
	$drunk = round($d/10-.5,0);
	$rand = e_rand(1,10);
	switch ($op){
		case "enter":
			if ($d < 60 && get_module_pref("visit") == 0){	
				output("`#You enter a small yard filled with beautiful `&white lillies`# and a quiet little pond.");
				output("Crickets chirp in harmony while small fish swim about the stream, darting back and forth under the lily pads.");
				output("`n`n`7As you enjoy this moment of tranquility, you feel`3 %s`7.`n`n",$drink[$drunk]);
				addnav("Lily Pond");
				addnav("Enjoy the Scenery","runmodule.php?module=lilypond&op=enjoy");
				addnav("Return to the Gardens","gardens.php");
			}else{		
				output("`^You stumble to the Lilies and fall over drunk in a flowerbed.");
				output("Frogs make themselves at home in your armor and when you wake, you find a few warts."); 
				if ($session['user']['charm'] > get_module_setting("charm")){ 
					output(" `^( `3-%s charm`^ )",get_module_setting("charm"));
					$session['user']['charm']-=get_module_setting("charm");
					}
				addnews("`3Poor `^%s `3slept with the frogs and woke up a bit boggy.",$session['user']['name']);
				set_module_pref("drunkeness",$d-get_module_setting("charm"),"drinks");	
				addnav("Wake up","gardens.php");
			}		
		break;
	case "enjoy":
		set_module_pref("visit",1);
		addnav("Return to the Gardens","gardens.php");
		switch ($rand){
			case 1:		
				output(" `3You lay down to enjoy the flowers beside the pond, and suddenly a little bee lands on your nose.");
				output("You try to swat the little creature and suddenly - OUCH! It stung you!");
				output("Small hives start to develop on your cheeks and quickly you pull out the stinger.");
				output("`n `6You gain a few points of experience from this.");
				output("`n`n`^OUCH, that bee sting really hurts!");
					apply_buff('lilypond',
						array(
							"name"=>"`^Stings like a bee!",
							"rounds"=>5,
							"wearoff"=>"Ahh, the stinging has faded",
							"atkmod"=>.5,
							"roundmsg"=>"You try scratch the hives on your face from the bee sting!",
							)
						);
					break;
				case 2:
					output(" `3Ahh, calm, relaxing lily pond.");
					output("Perhaps there's more to life than killing in the forest.");
					output("After a few minutes of perfect refection, boredem sets in.");
					output("Soon, anxiety and bloodlust have built up and you find you have little more some something important, like killing.");
					output("`n`n`^You gain a turn!");
					$session['user']['turns']++;
					break;
				case 3:
					output(" `3Ahh, calm, relaxing lily pond.");
					output("You decide to meditate upon the mantras of this world and your spirit settles.");
					output("Somewhere, in the deep forest, an image of distant lands appears in your mind.");
					output("You hear the songs of the forest in `2gladesinging`3 and whispers.");
						apply_buff('lilypond',
							array(
								"name"=>"`#Meditation Focus",
								"rounds"=>5,
								"wearoff"=>"The world begins to crowd your focus",
								"atkmod"=>1.1,
								"roundmsg"=>"With a calm mind, you lash out at the enemy!",
								)
							);
					output("`n`n`^You feel focused on the journey beyond!");
					$session['user']['turns']+=get_module_setting("turns");
					break;
				case 4:
					output("`3You take a breath and feel `%PERCEPTIVE`3!");
					output("You notice something catching a ray of sunlight deep within the murky water.");
					output("You quickly reach down to grab a handful of coins.");
					output("`n`n`^You find `6%s `^gold coins with elvish runes!",$rand);
					$session['user']['gold']+=$rand;
					break;
				
				case 5:
					output("`3The tranquil beauty of this place flows over you.");
					output("Sitting against birch tree, you fall asleep by the pond to the sound of lapping waves.");
						apply_buff('lilypond',
							array(
								"name"=>"`#Rest",
								"rounds"=>5,
								"wearoff"=>"The world begins to crowd your focus",
								"atkmod"=>1.1,
								"roundmsg"=>"With a calm mind, you lash out at the enemy!",
								)
							);
					break;
				case 6:
					output("`3Walking along the lily Pond, you glance up and see a small `@frog `3jump into the water.");
					output("You wonder what else those murky waters might hold.");
					output("Perhaps, when you're perceptive enough, you should return.");
					break;
				case 7:
					output("`3Walking along the lily Pond, you glance up and see a beautiful young elf staring back at you.");
					output("You move to speak and the fey creature vanishes without a trace.");
					break;
				case 8:
				$city = getsetting("villagename",LOCATION_FIELDS);
					output("`3You wander along the banks of the lily pond and suddenly, you see an `6Eythgim Champion`3 in full battle gear.");
					output("A heavy broadsword glimmers in the distance and he glares across the water to your location.");
					output("You shout out for help and the `6Champion `3runs into the trees, somewhere inside `#%s`3.",$city);
					addnews("`3A shout was heard in `5%s`3! `^%s `3reports seeing an `6Eythgim Champion`3 spying on the village!",$city,$session['user']['name']);
					break;
				case 9:
				case 10:
					output("`3You inhale in the sweet scent of lillies and stretch your arms. This is indeed very relaxing.");
						apply_buff('lilypond',
							array(
								"name"=>"`#Rest",
								"rounds"=>5,
								"wearoff"=>"The world begins to crowd your focus",
								"atkmod"=>1.1,
								"roundmsg"=>"With a calm mind, you lash out at the enemy!",
								)
							);
						break;
			}
			break;
	}
page_footer();
}
?>