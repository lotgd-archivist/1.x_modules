<?php
/*
Details:
 * This contains 'speak like a Troll day'
History Log:
 * Version 1.0:
   o Seems stable
*/

function holiday_troll_getmoduleinfo(){
	$info = array(
		"name"=>"Holiday - Talk like a Troll day",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Holiday Texts",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/holiday_troll.zip",
		"settings"=>array(
			"Talk Like A Troll Day Settings,title",
			"activate"=>"Activation date (mm-dd)|9-19",
		),
		"prefs"=>array(
			"Talk Like A Troll Day User Preferences,title",
			"ignore"=>"Ignore Talk Like A Troll text,bool|0",
		),
	);
	return $info;
}

function holiday_troll_install(){
	module_addhook("holiday");
	module_addhook("holiday");
	return true;
}

function holiday_troll_uninstall(){
	return true;
}

function holiday_troll_munge($in) {
	$out = $in;
	$out = str_replace("you","'oo",$out);
	$out = str_replace("You","'oo",$out);
	$out = str_replace("the ", "t' ", $out);
	$out = str_replace("The ", "t' ", $out);
	$out = str_replace("your","oor",$out);
	$out = str_replace("Your","oor",$out);
	$out = str_replace("It's", "Ih a",$out);
	$out = str_replace("it's", "ih a",$out);
	if (e_rand(0,4) == 1) $out = str_replace("[^`]!",", unh!",$out);
	$out = str_replace("for", "f'r", $out);
	$out = str_replace("my ", "meh ", $out);
	$out = preg_replace("'(lot|lots|lotsa) '", "lorra ", $out);
	$out = str_replace(" of ", " uh ", $out);
	$out = str_replace(" one ", " eeny ", $out);
	$out = str_replace(" two ", " eeny eeny ", $out);
	$out = str_replace(" three ", " eeny eeny eeny ", $out);
	$out = str_replace(" four ", " miney ", $out);
	$out = str_replace(" five ", " miney eeny ", $out);
	$out = str_replace(" six ", " miney eeny eeny ", $out);
	$out = str_replace(" seven ", " miney eeny eeny ", $out);
	$out = str_replace(" eight ", " miney miney ", $out);
	$out = str_replace(" nine ", " miney miney eeny ", $out);
	$out = str_replace(" ten ", " miney miney miney ", $out);
	$out = str_replace(" is ", " ah ", $out);
	$out = preg_replace("'[^[:alpha:]]you[^[:alpha:]]'i"," oo' ",$out);
	$out = preg_replace("'([^ .,!?]+)ing '","\\1'ng ",$out);
	$out = preg_replace("/ [s]{0,1}he /i"," e' ",$out);
	$out = str_replace(" and "," ahn ",$out);
	$out = str_replace(" am ", " b' ", $out);
	$out = str_replace(" says "," sa's ",$out);
	$out = str_replace(" to ", " t' ", $out);
	if (e_rand(0,4) == 1)
		$out = str_replace(". ",",ug. ",$out);
	if (e_rand(0,4) == 1)
		$out = str_replace(", ",", ig, ",$out);
	if (e_rand(0,4) == 1)
		$out = str_replace(". ", ". Ag, ", $out);
	$out = str_replace("hello ", "eyo ", $out);
	$out = str_replace("speaks", "sez", $out);
	$out = str_replace("admin", "fodder", $out);
	$out = str_replace("Forest", "Grash", $out);
	$out = eregi_replace("new day", "Nu dah", $out);
	$out = preg_replace("'(gems|Gems) '", "Shi'nies ", $out);
	$out = str_replace("Hello ", "eyo ", $out);
	$out = preg_replace("'( |`.)(money|gold)( |`.)'", "\\1spahkewes\\3", $out);
	$out = preg_replace("'(Money|Gold) '", "Spahkewes ", $out);
	$out = str_replace("moon ah","moon i'",$out);
	return $out;
}

function holiday_troll_dohook($hookname,$args){
	switch($hookname){
		case "holiday":
			if(get_module_pref("ignore")) break;
			$mytime = get_module_setting("activate");
			list($amonth,$aday) = split("-", $mytime);
			$amonth = (int)$amonth;
			$aday = (int)$aday;
			$month = (int)date("m");
			$day = (int)date("d");
			if ($month == $amonth && $day == $aday) {
				$args['text'] = holiday_troll_munge($args['text']);
			}
		break;
	}
	return $args;
}

function holiday_troll_run(){

}
?>