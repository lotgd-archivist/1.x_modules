<?php
// Ready to deploy
function academy_getmoduleinfo(){
	$info = array(
		"name"=>"Dycedarg's Academy",
		"author"=>"Chris Vorndran<br>`6Idea by: `QMichael Caternolo",
		"version"=>"1.28",
		"category"=>"Village",
		"description"=>"Hire a Squire. Levels and fights alongside the user.",
		"download"=>"http://dragonprime.net/users/Sichae/academy.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"Dycedarg's Academy Settings,title",
				"cost"=>"Gem cost to indoctrinate a Squire,int|10",
				"re"=>"How much gold to rename Squire?,int|1000",
				"favor"=>"How much favor does it cost to revive a fallen squire?,int|25",
				"level"=>"How many of the user's level does it take for the squire to level,range,1,15,1|5",
				"knight"=>"At which level does the Squire become a Knight?,int|10",
				"warlord"=>"At which level does the Knight become a Warlord?,int|20",
				"max"=>"Max Level of a Indoctrinated Fighter,int|50",
				"exp"=>"How much EXP (%) is devoted `iin battle`i to the Squire's training,range,0,100,1|5",
				"pvp"=>"Does the Squire work in PVP?,bool|0",
				"training"=>"Does the Squire work in Training?,bool|0",
				"academyloc"=>"Location of the Academy?,location|".getsetting("villagename", LOCATION_FIELDS),
			"Squire's Stats,title",
				"names"=>"Available names,text|Sirius Menitiroso,Galahad Gallant,Tim Jones,John Smith,Brogarh Romthor",
				"Parse (seperate) each name with a comma.,note",
				"miss"=>"Max Accuracy (percent),range,0,100,5|85",
				"mindmg"=>"Base Minimum Damage,int|1",
				"maxdmg"=>"Base Maximum Damage,int|3",
				"ndchance"=>"Chance upon Newday that user is granted a buff,range,1,100,1|25",
				"boost-knight"=>"How much of an attack boost (%) does a Knight get,range,100,200,1|115",
				"boost-warlord"=>"How much of an attack boost (%) does a Warlord get,range,100,200,1|115",
			),
		"prefs"=>array(
			"Dycedarg's Academy Prefs,title",
				"user_showstats"=>"Would you like to see Squire's Stats?,bool|0",
				"user_bio"=>"Would you like other's to be able to see your Squire's name in your Bio?,bool|0",
				"active"=>"Has used indoctrinated a Squire?,bool|0",
				"dead"=>"Is user's squire dead?,bool|0",
				"name"=>"Squire's name,text|",
				"lsl"=>"How many levels has the user gained since the Squire leveled?,int|0",
				"level"=>"User's Squire's current Level,int|0",
				"acc"=>"Accuracy (percent),range,1,100,1|65",
				"This pref will evaluate if a squire has a bad battle or a good one.,note",
				"tacc"=>"Has user trained accuracy today?,bool|0",
				"class"=>"User's Squire's class,enum,0,Squire,1,Knight,2,Warlord|0",
			),
		);
	return $info;
}
function academy_install(){
	module_addhook("creatureencounter");
	module_addhook("newday");
	module_addhook("battle");
	module_addhook("battle-victory");
	// module_addhook("battle-defeat");
	module_addhook("training-victory");
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("charstats");
	module_addhook("shades");
	module_addhook("graveyard");
	module_addhook("biostat");
	return true;
}
function academy_uninstall(){
	return true;
}
function academy_dohook($hookname,$args){
	global $session;
	$pvp = get_module_setting("pvp");
	$classarray = array(
		0=>translate_inline("Squire"),
		1=>translate_inline("Knight"),
		2=>translate_inline("Warlord")
	);
	$maxarray = array(
		0=>get_module_setting("knight"),
		1=>get_module_setting("warlord"),
		2=>get_module_setting("max")
	);
	$class = get_module_pref("class");
	if (get_module_setting("exp") != 0){
		$exp = 1-(get_module_setting("exp")/100);
	}else{
		$exp = 1;
	}
	$min = get_module_setting("mindmg");
	$max = get_module_setting("maxdmg");
	// Apply flux based on Squire's level and class
	$bk = (get_module_setting("boost-knight")/100);
	$bw = (get_module_setting("boost-warlord")/100);
	$minion = 1;
	$mindmg = $min+get_module_pref("level");
	switch (get_module_pref("class")){
		case 0:
			$maxdmg = $max+get_module_pref("level");
			break;
		case 1:
			$maxdmg = round($max+get_module_pref("level")*$bk);
			break;
		case 2:
			$maxdmg = round($max+get_module_pref("level")*$bw);
			$minion = 2; // Two Blades
			break;
		}
	$minstat = $mindmg;
	$maxstat = $maxdmg;
	// Applying miss calculation
	if (e_rand(1,100) > get_module_pref("acc")){
		$mindmg = 0;
		$maxdmg = $max;
	}
	switch ($hookname){
		case "creatureencounter":
			$buffarray = array(0=>1.05,1=>$bk,2=>$bw);
			if (get_module_pref("active") && !get_module_pref("dead")){
				$args['creatureexp'] = round($args['creatureexp']*$exp,0);
				$args['creatureattack'] = round($args['creatureattack']*($buffarray[$class]));
				$args['creaturedefense'] = round($args['creaturedefense']*($buffarray[$class]));
			}
			break;
		case "newday":
			if (get_module_pref("active") && !get_module_pref("dead")){
				$nd = get_module_setting("ndchance");
				if (e_rand(1,100) <= $nd){
					apply_buff("academy", array(
							"name"=>"Squire's Melody",
							"roundmsg"=>"The tune of your Squire's melody empowers you.",
							"rounds"=>e_rand(5,25),
							"atkmod"=>1.1,
							"defmod"=>1.1,
							"wearoff"=>"The tune of your Squire's melody slowly fades amongst the wind...",
						)
					);
				}
			}
			set_module_pref("tacc",0);
			break;
		case "battle":
			if (get_module_pref("active") && !get_module_pref("dead")){
				if ((!$pvp && $args['type'] == "pvp") || 
					($args['type'] == "train" && !get_module_setting("train"))){ 
					// do nothing
				}else{
					apply_buff("battle-academy", array(
						"name"=>get_module_pref("name"),
						"startmsg"=>sprintf_translate("%s `6readies his weapon.",get_module_pref("name")),
						"rounds"=>-1,
						"minioncount"=>$minion,
						"minbadguydamage"=>$mindmg,
						"maxbadguydamage"=>$maxdmg,
						"effectmsg"=>sprintf_translate("`%%s `6strikes `\${badguy} `6for `^{damage}`6 damage!",get_module_pref("name")),
					    "effectnodmgmsg"=>sprintf_translate("`\${badguy} `6narrowly dodges the weapon of `%%s",get_module_pref("name")),
						"effectfailmsg"=>sprintf_translate("`\${badguy} `6narrowly dodges the weapon of `%%s",get_module_pref("name")),
						)
					);
				}
			}
			break;
		case "battle-victory":
			strip_buff("battle-academy");
			break;
		// case "battle-defeat":
		case "shades":
		case "graveyard":
			if (get_module_pref("active") && httpget('module') != "battlearena"){
				if (!get_module_pref("dead")){
					output("`n`n`)Sadly, %s `)has lost his life, trying to defend your body.`n",get_module_pref("name"));
					debuglog("'s Squire is dead.");
				}
				set_module_pref("dead",1);
			}
			strip_buff("battle-academy");
			break;
		case "biostat":
			$name = get_module_pref("name","academy",$args['acctid']);
			$class = get_module_pref("class","academy",$args['acctid']);
			if ($name != "")	output("`^%s's Name: `@%s`0`n",$classarray[$class],$name);
			break;
		case "training-victory":
			if (get_module_pref("active") && !get_module_pref("dead")){
				$levelsetting = get_module_setting("level");
				$levelpref = get_module_pref("level");
				$levelsincelevel = get_module_pref("lsl");
				if ($levelpref < $maxarray[$class]){
					if ($levelsincelevel != $levelsetting){
						output("`n`%%s `^is slowly becoming stronger!`n",get_module_pref("name"));
						$levelsincelevel++;
						set_module_pref("lsl",$levelsincelevel);
					}else{
						output("`n`%%s `^should be able to level up now!`n",get_module_pref("name"));
					}
				}else{
					output("`n%s has become the strongest he can be...`n",get_module_pref("name"));
				}
			}
			break;			
		case "village":
			if ($session['user']['location'] == get_module_setting("academyloc")){
				tlschema($args['schemas']['fightnav']);
				addnav($args['fightnav']);
				tlschema();
				addnav("Dycedarg's Academy","runmodule.php?module=academy&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting("academyloc")){
					set_module_setting("academyloc",$args['new']);
				}
			}
			break;
		case "charstats":
			$classarray = array(0=>translate_inline("Squire"),1=>translate_inline("Knight"),2=>translate_inline("Warlord"));
			if (get_module_pref("user_showstats") && get_module_pref("active")){
				$title = sprintf("%s Info",$classarray[$class]);
				$name = translate_inline("Name");
				$status = translate_inline("Status");
				$level = translate_inline("Level");
				$attack = translate_inline("Damage");
				$ready = translate_inline("Ready to Level");
				$train = translate_inline("Train Accuracy");
				$acc = translate_inline("Accuracy");
				setcharstat($title,$name,get_module_pref("name"));
				setcharstat($title,$status,translate_inline(get_module_pref("dead")==1?"Dead":"Alive"));
				setcharstat($title,$level,get_module_pref("level"));
				setcharstat($title,$attack,$minstat."-".$maxstat);
				setcharstat($title,$acc,get_module_pref("acc")."%");
				$cond = translate_inline("No");
				if (get_module_pref("lsl") == get_module_setting("level")) $cond = translate_inline("Yes");
				setcharstat($title,$ready,$cond);
				setcharstat($title,$train,translate_inline(get_module_pref("tacc")==1?"Unable":"Able"));
			}
			break;
		}
	return $args;
}
function academy_run(){
	global $session;
	$op = httpget('op');
	$dead = get_module_pref("dead");
	$active = get_module_pref("active");
	$name = get_module_pref("name");
	$classarray = array(0=>translate_inline("Squire"),1=>translate_inline("Knight"),2=>translate_inline("Warlord"));
	$max = array(0=>get_module_setting("knight"),1=>get_module_setting("warlord"),2=>get_module_setting("max"));
	$class = get_module_pref("class");
	
	page_header("Dycedarg's Academy");
	switch ($op){
		case "enter":
			output("`6You wander into a grand hall.");
			output("Gazing at the ceiling, you suddenly lose track of your footing.");
			output("All of a sudden, a tall knight stands before you.");
			output("He glares gently at you, as your eyes scan over him.");
			output("You note a large Lion on his cape, his cut physique and his well-groomed beard.");
			output("`n`n\"`&Hello, my name is Dycedarg Beoulve... may I ask what you think you are doing in my Academy?`6\"");
			output("`n`nHe takes a step back and turns his back to you, ushering you forward with a single finger.");
			output("`n`nHis voice booms throughout the halls, \"`&Here, we take pride in the development of a warrior.");
			output("Our Squires are taught the most powerful techniques, the strongest moves and they are trained to their fullest potential.");
			output("If you are interested in purchasing one of my fine protege's, you shall have to pay up `%%s `&Gems.",get_module_setting("cost"));
			output("Once you pay for your Squire, it shall be indoctrinated to you.");
			output("It shall serve you until death.`6\"");
			addnav("Venture");
			addnav("Training Hall","runmodule.php?module=academy&op=hall");
			if ($active && !$dead){
				output("`n`n`6Dycedarg scans his eyes over you and tilts his head to the side.");
				output("\"`&My... I didn't see you there...");
				output("Please step forward, `^%s`&.`6\"",$name);
				output("You take a quick look at your warrior and Dycedarg smiles.");
			}elseif($dead){
				output("`n`n`6Dycedarg notes the limp body in your arms.");
				output("\"`&I see... Well, if you will follow me into the Training Hall... I shall be able to sort this all out.`6\"");
			}
			break;
		case "hall":
			addnav("Training Hall");
			if (!$active){
				output("`6Dycedarg marches you into the Training Hall.");
				output("\"`&Here, we strive for perfection.");
				output("Not one of our student's is out of line...`6\"");
				output("`n`nJust then, fire erupts from his fingertips and flies towards one of the misbehaving students.");
				output("\"`&He was looking at my cock-eyed...");
				output("Now then, would you like to Indoctrinate a Squire?`6\"");
				addnav("Indoctrinate Squire","runmodule.php?module=academy&op=buy");
			}else{
				output("`6Dycedarg looks at you, \"`&How many I be of service outside of renaming your Squire for `^%s `&gold?`6\"",get_module_setting("re"));
				addnav(array("Rename %s",$name),"runmodule.php?module=academy&op=train&type=rename");
				if ($dead){
					addnav(array("Revive %s (%s Favor)",$classarray[$class],	get_module_setting("favor")),
						"runmodule.php?module=academy&op=train&type=revive");
					output("`n`n`6Dycedarg frowns and looks solemn.");
					output("\"`&It is quite sad that we have to meet once more on this occasion... ");
					output("As I am your %s's master, I would like to do the honors in reviving him.",$classarray[$class]);
					output("It will cost `\$%s `&Favor.`6\"",get_module_setting("favor"));
				}
				if (get_module_pref("lsl") >= get_module_setting("level") && !$dead){
					addnav(array("Train %s",$classarray[$class]),"runmodule.php?module=academy&op=train&type=level");
					output("`n`n`6Dycedarg smiles, \"`&So, I see that %s has grown quite strong.",$name);
					output("I shall allow him to level, IF he can best me in battle.");
					output("Would you care to submit him into battle?`6\"");					
				}
				if (get_module_pref("level") == $max[$class] && !$dead){
					output("`n`n`6\"`&Splendid, simply splendid!");
					output("If you come with me, we shall make your servant much better!`6\"");
					addnav("Advance Class","runmodule.php?module=academy&op=train&type=upgrade");
				}
				if (!get_module_pref("tacc") && !$dead){
					output("`n`n`6\"`&I see... so, you would like to train your servant's accuracy today.");
					output("Very well then...`6\"");
					addnav("Train Accuracy","runmodule.php?module=academy&op=train&type=acc");
				}
			}
			break;
		case "buy":
			if ($session['user']['gems'] >= get_module_setting("cost")){
				$names = array();
				$names = explode(",",get_module_setting("names"));
				$i = e_rand(1,count($names));
				$name = $names[$i];
				set_module_pref("name",$name);
				set_module_pref("active",1);
				set_module_pref("dead",0);
				output("`6Dycedarg fetches a Squire from the wall and returns.");
				output("\"`&This one's name is %s. Say hello to your new owner...`6\"",$name);
				output("The Squire bows and stands at your side.");
				$session['user']['gems']-=get_module_setting("cost");
			}else{
				output("`6Dycedarg snatches you from the scruff of the neck and tosses you to the ground.");
				output("\"`&One of the things that we teach here is honesty.... now get out!`6\"");
			}
			break;
		case "train":
			switch (httpget('type')){
				case "revive":
					if ($session['user']['deathpower'] >= get_module_setting("favor")){
						output("`6Dycedarg looks to the sky and spreads his arms.");
						output("His eyes roll to the back of his skull and low murmers escape his throat.");
						output("Suddenly, your %s's body rises into thin air and a light pierces him.",$classarray[$class]);
						set_module_pref("dead",0);
						$session['user']['deathpower']-=get_module_setting("favor");
						output("`n`nDycedarg looks at you, \"`&It is done...`6\"");
					}else{
						output("`6Dycedarg frowns, \"`&With not enough favor, I am unable to make a bargain with Ramius.");
						output("Please come back when you have more favor.`6\"");
					}
					break;
				case "level":
					// Sanity check
					if (get_module_pref("lsl") < get_module_setting("level")){
						output("`6Dycedarg looks stunned, \"`&I don't know who you are trying to fool... but your %s is not strong enough to face me.`6\"",$classarray[$class]);
					}else{
						$excesslevel = get_module_pref("lsl")-get_module_setting("level");
						set_module_pref("lsl",$excesslevel);
						// This makes sure to carry over any levels.
						// Even though extra lsl's can not be gained
						// It is best to keep this in, just in case
						// If it equates to 0, that is what we want. :)
						set_module_pref("level",get_module_pref("level")+1);
						output("`6Dycedarg shows you into a small room, that is highly decorated with little furnishing.");
						output("He pulls out his sword and looks at %s, \"`&Come at me!`6\"",$name);
						output("Your %s runs at Dycedarg and slashes him across the front.",$classarray[$class]);
						output("Dycedarg stands and pokes %s in the forehead, making him topple over.",$name);
						output("Your %s wipes the blood from his chin and strikes against Dycedarg once more.",$classarray[$class]);
						output("Amazingly, he is able to strike Dycedarg down!");
						output("\"`&Very good, my faithful servant.`6\"");
						output("`n`n%s gained a level!",$name);
						output("His attack has increased!");
					}
					break;
				case "acc":
					if (get_module_pref("acc") <= get_module_setting("miss")){
						output("`6\"`&So, you would like to train your %s's accuracy?`6\"",$classarray[$class]);
						output("`6Dycedarg draws up a target on the wall.");
						output("\"`&Now, %s, focus your energy on the center, and let's see if you can hit the target.`6\"`n`n",$name);
						output("`6You can see that %s is straining on the target.",$name);
						output("Your eyes begin to strain and you begin to see a red dot circling around the target.");
						switch(e_rand(1,4)){
							case 1: case 2: case 3:
								output("For a brief instant, the dot stays in the center and Dycedarg smiles.");
								output("\"`&Very good job...`6\"");
								set_module_pref("acc",get_module_pref("acc")+1);
								set_module_pref("tacc",1);
								break;
							case 4:
								output("`6You can see that %s is unable to focus on the target.",$name);
								output("After five minutes, Dycedarg takes down the target and retreats into the back room.");
								break;
							}
					}else{
						output("`6Dycedarg looks at %s.",$name);
						output("\"`&He is about as accurate as he is going to get.`6\"");
					}
					break;
				case "rename":
					$newname = httppost('name');
					$set = translate_inline("Set Name");
					if ($session['user']['gold'] >= get_module_setting("re")){
						if ($newname ==	""){
							output("`6Dycedarg walks forward, looking at you.");
							output("\"`&Let's get this over with.");
							output("Write the name you want here, and I shall transfer it over.`6\"`n`n");
							rawoutput("<form action='runmodule.php?module=academy&op=train&type=rename' method='post'>");
							rawoutput("<input name='name' size='20'>");
							rawoutput("<input type='submit' class='button' value='$set'></form>");
						}else{
							output("`6\"`&There we go, your %s has been renamed to %s`&.`6\"",$classarray[$class],$newname);
							set_module_pref("name",$newname."`0");
							$session['user']['gold']-=get_module_setting("re");
						}
					}else{
						output("`6\"`&What do you think this is, a free clinic?");
						output("Get out of here before I rend your limbs from your body.`6\"");
					}
					addnav("","runmodule.php?module=academy&op=train&type=rename");
					break;
				case "upgrade":
					$advance = httpget('ad');
					$current = $classarray[$class];
					$next = $classarray[$class+1];
					// Sanity Check
					if (get_module_pref("level") != $max[$class]){
						output("`6\"`&I have no idea how you got in here, but I want you out!`6\"");
					}else{
						if ($advance == ""){
							output("`6You approach Dycedarg, your %s at your side.",$current);
							if($class == 2){
								output("`6Dycedarg shakes his head, \"`&I am sorry, but %s is as strong as he will ever be.`6\"",$name);
							}else{
								output("`6Dycedarg looks at your %s, \"`&Ah... so I see that %s would like to train for a new class.",$current,$name);
								output("You do know that class would happen to be %s and is far more powerful than your %s class?`6\"",$next,$current);
								output("`n`nYou nod in agreement.");
								output("\"`&So then, let's get started...`6\"");
								addnav(array("Upgrade to %s",$next),"runmodule.php?module=academy&op=train&type=upgrade&ad=yes");
							}
						}elseif($advance == "yes"){
							$class++;
							set_module_pref("class",$class);
							set_module_pref("lsl",0);
							set_module_pref("level",0);
							output("`6%s heads into another room with Dycedarg.",$name);
							output("You hear clanging of weapons and the breaking of skin.");
							output("A cloth rips and you hear liquid hit the floor.");
							output("Hours later, he returns with a heavily inked tattoo on his arm.");
							output("\"`&Meet your new %s.`6\"",$next);
						}
					}
					break;
				}
			break;
		}
	addnav("Leave");
	villagenav();
page_footer();
}
?>