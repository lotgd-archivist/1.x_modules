<?php
/*
Details:
 * This module checks the amount of navigations a user has and allows them to fix their navigations if they have 0
 * You can also set a price to pay for users to summon the demon at any time
History Log:
 * Version 1.0:
   o Seems stable
 * Version 1.1:
   o Works with LotGD 1.0
*/
require_once('lib/villagenav.php');

function navigationdemon_getmoduleinfo(){
	$info = array(
		"name"=>"Navigation Demon",
		"version"=>"1.1",
		"author"=>"`@CortalUX",
		"category"=>"General",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/navigationdemon.zip",
		"settings"=>array(
			"Navigation Demon - Settings,title",
			"price"=>"Price to fix navigation?,int|1500",
			"(users can do this for free if their navigations are definately broken- but you can allow users to break out of a specialinc in the forest or the village- for a fee),note",
			"(set the price to 0 to turn off),note",
		),
		"prefs"=>array(
			"Navigation Demon - Information,title",
			"times"=>"Amount of times that the demon has been summoned?,int|0",
		),
	);
	return $info;
}

function navigationdemon_install(){
	if (!is_module_active('navigationdemon')){
		output("`n`c`b`QNavigation Demon Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QNavigation Demon Module - Updated`0`b`c");
	}
	module_addhook("everyfooter");
	module_addhook("charstats");
	return true;
}

function navigationdemon_uninstall(){
	output("`n`c`b`QNavigation Demon Module - Uninstalled`0`b`c");
	return true;
}

function navigationdemon_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch ($hookname) {
		case "everyfooter":
			$x = navcount();
			if ($x<=0) {
				output_notl("`n`n`c`@%s`n%s`n`b<a href='runmodule.php?module=navigationdemon&op=fix' class='colLtOrange'>%s</a>`b`c",translate_inline("Your navigations appear to be corrupt."),str_replace("%s","`#CortalUX`@",translate_inline("Potion Master %s gave you a demon summoning Vial.. maybe this will help.")),translate_inline("Summon the Navigation Demon!"),true);
				addnav("","runmodule.php?module=navigationdemon&op=fix");
			}
		break;
		case "charstats":
			$price = get_module_setting('price');
			if ($price>0&&$session['user']['gold']>=$price) {
				$script = substr($SCRIPT_NAME,0,strrpos($SCRIPT_NAME,"."));
				if ($script=='village'||$script=='forest') {
					if ($session['user']['specialinc']!=''||$session['user']['specialmisc']!='') {
						$t = translate_inline("Navigation");
						$y = str_replace("%s",$price,translate_inline("Summon the Navigation Demon!`n%s Gold"));
						$demon="<a href='runmodule.php?module=navigationdemon&op=payfix' align='center' class=\"charinfo\" style=\"font-size:10px\">".$y."</a>";
						addcharstat("Extra Info");
						addcharstat($t, $demon);
						addnav("","runmodule.php?module=navigationdemon&op=payfix");
					}
				}
			}
		break;
	}
	return $args;
}

function navigationdemon_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "payfix":
		 	page_header("A Dark Vial");
			$price = get_module_setting('price');
			$session['user']['gold']-=$price;
			output("`@Remembering an ancient chant, you speak..`nOpening a hole into time and space, you place %s gold upon a golden counter, and buy a Transport Potion from %s, which you put within your %s, before remembering why you bought it... you wish you could make gates big enough to step through.`n",$price,"`#CortalUX`@",$session['user']['armor']);
		case "fix":
			if ($op=='fix') page_header("A Dark Vial");
			set_module_pref('times',get_module_pref('times')+1);
			output("`@Removing a small and unassuming dark black vial from within your %s`@, you stare at the swirling grey mist within, noticing for the first time the embossed letters on the strange container... Recalling %s's instructions, you run your fingers upon the characters, and they begin to glow a faint red. Reading the letters, they at first seem to be absolute nonsense.. before they elusively shift into other forms, before you finally manage to understand them..`nReading the vial, you say the instructions aloud.`n`3\"`&If you want to hit the road Jack, hit the floor with me.`3\" you speak...`n`@Throwing the bottle to the floor, the vial shatters with a noise that sounds uncannily like a doorbell.. ding dong.. before spreading into a mist made out of a thousand glass pieces, augmented by the thick oily mist that had been within the broken container.`nA sinisterly booming voice shouts \"`^You rang?`@\"`nNodding nervously, the creature, that you assume to be a transportation demon, sighs, clicks it's fingers, and says \"`^Where'd you wanna go? Hurry up, my link to multimap won't last all day.`@\"`nWondering what this 'multimap' is, you speak the name of %s, before gasping in astonishment as a tripledecker bus appears from a large green whirlwind that erupts from the sky.`nAs you stand looking in amazement, the demon, now dressed as a conductor, waves it's hands, directing the flow of the shardlike mist, which then carries you to the bus, as the demon yells \"`^I couldn't wait all day mate! Time is money, find yerself a seat, get onto the bus.`@\"`nLooking exasperated, the demon shouts vaguely in the direction of a wizardlike group of passengers, staring at a skinny boy with a scar on his forehead, \"`^Oi, potter, move over!`@\"`nOnce you are seated on a slimy, worn, brown leather couch, the demon rings the bell, and the bus starts with a lurch.`nA few moments later, the demon yells, \"`^Next stop %s!`@\" before shoving you out of the door, in the direction of the square. \"`^Next time mate, bring a map!`@\" it sniggers.`nHead a-whirling, the bus seemingly evaporates, and a small black vial drops into your hand, which you then put within your %s`@.",$session['user']['armor'],"`#CortalUX`@",$session['user']['location'],$session['user']['location'],$session['user']['armor']);
			villagenav();
			$session['user']['specialinc']="";
			$session['user']['specialmisc']="";
			$session['user']['badguy']="";
			/*
			We reset the specialinc, specialmisc, and badguy..
			the user shouldn't need them..
			If the user got this error from, say, within the 'worldmap'
			module, or the 'house' module, the location wouldn't be a
			name of a village, however this will be sorted out by
			'village.php' anyway.
			*/
		break;
	}
	page_footer();	
}
?>