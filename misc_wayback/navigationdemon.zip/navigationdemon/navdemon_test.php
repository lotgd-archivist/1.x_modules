<?php
/*
Details:
 * This module is just so you can test out the navigation demon
History Log:
 * Version 1.0:
   o Seems stable
*/
function navdemon_test_getmoduleinfo(){
	$info = array(
		"name"=>"Navigation Demon - Test",
		"author"=>"`@CortalUX",
		"version"=>"1.0",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/navigationdemon.zip",
		"requires"=>array(
			"navigationdemon" => "1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/navigationdemon.zip",
		),
	 );
	return $info;	
}
function navdemon_test_install(){
	module_addhook("village");
	return true;
}
function navdemon_test_uninstall(){
	return true;
}
function navdemon_test_dohook($hookname,$args){
	global $session;
	if ($session['user']['superuser']&SU_EDIT_USERS) {
		addnav("Test out the Navigation Demon","runmodule.php?module=navdemon_test");
	}
	return $args;
}

function navdemon_test_run(){
	page_header("Navigation Demon - Test");
	page_footer();
}
?>