Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a 'fix navs' module for LotGD 0.9.8.
This isn't for admin to fix user's navs, it's
for users to fix their own navs...
A demon will appear to allow users to fix
their own navs, if they have 0 nav's on the
bar, ignoring any navs like the backpack mod.
Also, users can optionally pay Gold to fix
their own navs, if you've enabled it, and they
are in the village/forest, with a specialinc
or specialmisc... so this won't fix nav bugs
in modules.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy all files within this zip into your modules
directory, except this one.

Login to the Superuser Grotto and Install / Activate them.