<?php
function specdisplay_getmoduleinfo(){
	$info = array(
		"name"=>"Specialty Display",
		"author"=>"Chris Vorndran",
		"version"=>"0.2",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/Sichae/specdisplay.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"This module will display the Specialty that a user is using, in their Vital Info area.",
		"settings"=>array(
			"title"=>"Title of Category that it goes under,text|Vital Info",
			"name"=>"Name of Stat Display,text|Specialty",
		),
		"user_prefs"=>array(
			"Specialty Display Preferences,title",
			"user_showspec"=>"Do you wish for Specialty to be displayed,bool|1",
			),
		"prefs"=>array(
			"Specialty Display Preferences,title",
			"user_showspec"=>"Do you wish for Specialty to be displayed,bool|1",
			)
		);
	return $info;
}
function specdisplay_install(){
	module_addhook("charstats");
	return true;
}
function specdisplay_uninstall(){
	return true;
}
function specdisplay_dohook($hookname,$args){
	global $session;
	$specialty = modulehook("specialtynames");
	switch ($hookname){
		case "charstats":
			if (get_module_pref("user_showspec") == 1){
			$title = get_module_setting("title");
			$name = get_module_setting("name");
			$spec = $specialty[$session['user']['specialty']];
			setcharstat ($title,$name,$spec);
		}
				break;
		}
	return $args;
}
function specdisplay_run(){
}
?>